<?php
// Script untuk mengupdate semua file PHP agar menggunakan unified.css
$files = [
    'index.php',
    'login.php',
    'register.php',
    'profile.php',
    'about.php',
    'terms.php',
    'privacy.php',
    'license.php',
    'forgot-password.php',
    'reset-password.php',
    'change-password.php',
    'notifications.php',
    'chat.php',
    'post-detail.php',
    'purchase.php'
];

foreach ($files as $file) {
    if (file_exists($file)) {
        $content = file_get_contents($file);
        
        // Replace style.css with unified.css
        $content = str_replace('assets/css/unified.css', 'assets/css/unified.css', $content);
        
        // Replace multiple CSS links with single unified.css
        $content = preg_replace(
            '/<link rel="stylesheet" href="assets\/css\/[^"]*">\s*<link rel="stylesheet" href="assets\/css\/[^"]*">/',
            '<link rel="stylesheet" href="assets/css/unified.css">',
            $content
        );
        
        file_put_contents($file, $content);
        echo "Updated: $file\n";
    } else {
        echo "Not found: $file\n";
    }
}

// Update admin files
$admin_files = [
    'admin/index.php',
    'admin/posts.php',
    'admin/users.php',
    'admin/revenue.php',
    'admin/notifications.php',
    'admin/settings.php'
];

foreach ($admin_files as $file) {
    if (file_exists($file)) {
        $content = file_get_contents($file);
        $content = str_replace('../assets/css/unified.css', '../assets/css/unified.css', $content);
        $content = str_replace('assets/css/admin.css', '../assets/css/unified.css', $content);
        file_put_contents($file, $content);
        echo "Updated: $file\n";
    } else {
        echo "Not found: $file\n";
    }
}

echo "CSS update completed!\n";
?>