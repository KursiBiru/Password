<?php
require_once 'config.php';
$isLoggedIn = isLoggedIn();
if ($isLoggedIn) {
    $user = getCurrentUser();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lisensi - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/unified.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php if ($isLoggedIn): ?>
        <?php include 'includes/header.php'; ?>
    <?php endif; ?>
    
    <div class="container">
        <div style="max-width: 800px; margin: 40px auto; background: white; padding: 40px; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
            <h1 style="color: #3498db; margin-bottom: 20px;">Lisensi</h1>
            
            <section style="margin-bottom: 30px;">
                <h2 style="color: #2c3e50; margin-bottom: 15px;">MIT License</h2>
                <p style="color: #7f8c8d; margin-bottom: 20px;">Copyright (c) <?php echo date('Y'); ?> <?php echo SITE_NAME; ?></p>
                
                <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; font-family: monospace; line-height: 1.8; color: #555;">
                    <p>Permission is hereby granted, free of charge, to any person obtaining a copy
                    of this software and associated documentation files (the "Software"), to deal
                    in the Software without restriction, including without limitation the rights
                    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
                    copies of the Software, and to permit persons to whom the Software is
                    furnished to do so, subject to the following conditions:</p>
                    
                    <p style="margin-top: 15px;">The above copyright notice and this permission notice shall be included in all
                    copies or substantial portions of the Software.</p>
                    
                    <p style="margin-top: 15px;">THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
                    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
                    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
                    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
                    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
                    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
                    SOFTWARE.</p>
                </div>
            </section>
            
            <section style="margin-bottom: 30px;">
                <h2 style="color: #2c3e50; margin-bottom: 15px;">Teknologi yang Digunakan</h2>
                <p style="line-height: 1.8; color: #555;">
                    Platform ini dibangun menggunakan teknologi open-source berikut:
                </p>
                <ul style="line-height: 2; color: #555; margin-top: 15px;">
                    <li><strong>PHP</strong> - Server-side scripting language</li>
                    <li><strong>MySQL</strong> - Database management system</li>
                    <li><strong>Font Awesome</strong> - Icon library (Free version)</li>
                    <li><strong>JavaScript</strong> - Client-side scripting</li>
                    <li><strong>CSS3</strong> - Styling and layout</li>
                </ul>
            </section>
            
            <section style="margin-bottom: 30px;">
                <h2 style="color: #2c3e50; margin-bottom: 15px;">Atribusi</h2>
                <p style="line-height: 1.8; color: #555;">
                    Jika Anda menggunakan atau memodifikasi kode ini, kami menghargai jika Anda memberikan atribusi dengan 
                    menyertakan link ke repository asli atau menyebutkan <?php echo SITE_NAME; ?> sebagai sumber.
                </p>
            </section>
            
            <section style="margin-bottom: 30px;">
                <h2 style="color: #2c3e50; margin-bottom: 15px;">Kontribusi</h2>
                <p style="line-height: 1.8; color: #555;">
                    Kami menyambut kontribusi dari komunitas. Jika Anda ingin berkontribusi, silakan:
                </p>
                <ul style="line-height: 2; color: #555; margin-top: 15px;">
                    <li>Fork repository</li>
                    <li>Buat branch untuk fitur baru</li>
                    <li>Commit perubahan Anda</li>
                    <li>Push ke branch</li>
                    <li>Buat Pull Request</li>
                </ul>
            </section>
            
            <section style="margin-bottom: 30px;">
                <h2 style="color: #2c3e50; margin-bottom: 15px;">Dukungan</h2>
                <p style="line-height: 1.8; color: #555;">
                    Untuk dukungan dan pertanyaan, silakan hubungi:<br>
                    <strong>Email:</strong> <?php echo SITE_EMAIL; ?>
                </p>
            </section>
            
            <section style="background: #fff3cd; padding: 20px; border-radius: 8px; text-align: center;">
                <h3 style="margin-bottom: 10px;">Belajar Lebih Banyak</h3>
                <p style="margin-bottom: 15px;">Ingin belajar cara membuat website seperti ini?</p>
                <a href="https://youtube.com/@kursibiru" target="_blank" class="btn btn-danger">
                    <i class="fab fa-youtube"></i> Subscribe kursibiru
                </a>
            </section>
        </div>
    </div>
    
    <?php if ($isLoggedIn): ?>
        <?php include 'includes/footer.php'; ?>
    <?php endif; ?>
</body>
</html>