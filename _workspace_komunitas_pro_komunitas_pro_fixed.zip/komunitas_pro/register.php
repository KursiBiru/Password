<?php
require_once 'config.php';

// Redirect if already logged in
if (isLoggedIn()) {
    redirect('index.php');
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid CSRF token';
    } elseif (!validateCaptcha($_POST['captcha'] ?? '')) {
        $error = 'Invalid captcha code';
    } else {
        $username = sanitizeInput($_POST['username']);
        $email = sanitizeInput($_POST['email']);
        $full_name = sanitizeInput($_POST['full_name']);
        $password = $_POST['password'];
        $confirm_password = $_POST['confirm_password'];
        
        // Validation
        if (strlen($username) < 3) {
            $error = 'Username minimal 3 karakter';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Email tidak valid';
        } elseif (strlen($password) < PASSWORD_MIN_LENGTH) {
            $error = 'Password minimal ' . PASSWORD_MIN_LENGTH . ' karakter';
        } elseif ($password !== $confirm_password) {
            $error = 'Password tidak cocok';
        } else {
            $conn = getDBConnection();
            
            // Check if username exists
            $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
            $stmt->execute([$username]);
            if ($stmt->fetch()) {
                $error = 'Username sudah digunakan';
            } else {
                // Check if email exists
                $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
                $stmt->execute([$email]);
                if ($stmt->fetch()) {
                    $error = 'Email sudah digunakan';
                } else {
                    // Create user
                    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                    $stmt = $conn->prepare("INSERT INTO users (username, email, password, full_name, email_verified) VALUES (?, ?, ?, ?, 1)");
                    
                    if ($stmt->execute([$username, $email, $hashedPassword, $full_name])) {
                        $success = 'Registrasi berhasil! Silakan login.';
                    } else {
                        $error = 'Terjadi kesalahan saat registrasi';
                    }
                }
            }
        }
    }
}

$csrfToken = generateCSRFToken();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/unified.css">
    <link rel="stylesheet" href="assets/css/dark-mode.css">
</head>
<body class="auth-page">
    <div class="auth-container">
        <div class="auth-box">
            <div class="auth-header">
                <h1><?php echo SITE_NAME; ?></h1>
                <p>Buat akun baru</p>
            </div>
            
            <?php if ($error): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <form method="POST" action="" class="auth-form">
                <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
                
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" required class="form-control" value="<?php echo $_POST['username'] ?? ''; ?>">
                </div>
                
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" required class="form-control" value="<?php echo $_POST['email'] ?? ''; ?>">
                </div>
                
                <div class="form-group">
                    <label for="full_name">Nama Lengkap</label>
                    <input type="text" id="full_name" name="full_name" required class="form-control" value="<?php echo $_POST['full_name'] ?? ''; ?>">
                </div>
                
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required class="form-control">
                </div>
                
                <div class="form-group">
                    <label for="confirm_password">Konfirmasi Password</label>
                    <input type="password" id="confirm_password" name="confirm_password" required class="form-control">
                </div>
                
                <div class="form-group">
                    <label for="captcha">Kode Captcha</label>
                    <div class="captcha-container">
                        <img src="captcha.php" alt="Captcha" id="captcha-image" class="captcha-image">
                        <button type="button" onclick="refreshCaptcha()" class="btn-refresh">↻</button>
                    </div>
                    <input type="text" id="captcha" name="captcha" required class="form-control" placeholder="Masukkan kode di atas">
                </div>
                
                <button type="submit" class="btn btn-primary btn-block">Daftar</button>
            </form>
            
            <div class="auth-footer">
                <p>Sudah punya akun? <a href="login.php">Login di sini</a></p>
            </div>
            
            <div class="youtube-suggestion">
                <p>💡 Ingin belajar lebih banyak? Subscribe YouTube <a href="https://youtube.com/@kursibiru" target="_blank"><strong>kursibiru</strong></a></p>
            </div>
        </div>
    </div>
    
    <script>
        function refreshCaptcha() {
            document.getElementById('captcha-image').src = 'captcha.php?' + Date.now();
        }
    </script>
    <script src="assets/js/dark-mode.js"></script>
</body>
</html>