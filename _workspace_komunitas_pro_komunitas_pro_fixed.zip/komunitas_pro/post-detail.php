<?php
require_once 'config.php';
requireLogin();

$currentUser = getCurrentUser();
$conn = getDBConnection();

// Get post ID
$postId = intval($_GET['id'] ?? 0);

if (!$postId) {
    setFlashMessage('danger', 'Postingan tidak ditemukan');
    redirect('index.php');
}

// Get post details
$stmt = $conn->prepare("
    SELECT p.*, u.username, u.full_name, u.profile_photo, u.id as author_id,
    (SELECT COUNT(*) FROM likes WHERE post_id = p.id) as like_count,
    (SELECT COUNT(*) FROM comments WHERE post_id = p.id) as comment_count,
    (SELECT COUNT(*) FROM shares WHERE post_id = p.id) as share_count,
    (SELECT COUNT(*) FROM likes WHERE post_id = p.id AND user_id = ?) as user_liked
    FROM posts p
    JOIN users u ON p.user_id = u.id
    WHERE p.id = ? AND p.status = 'active'
");
$stmt->execute([$currentUser['id'], $postId]);
$post = $stmt->fetch();

if (!$post) {
    setFlashMessage('danger', 'Postingan tidak ditemukan atau telah dihapus');
    redirect('index.php');
}

// Update views
$stmt = $conn->prepare("UPDATE posts SET views = views + 1 WHERE id = ?");
$stmt->execute([$postId]);

// Get comments
$stmt = $conn->prepare("
    SELECT c.*, u.username, u.full_name, u.profile_photo
    FROM comments c
    JOIN users u ON c.user_id = u.id
    WHERE c.post_id = ? AND c.parent_id IS NULL
    ORDER BY c.created_at DESC
");
$stmt->execute([$postId]);
$comments = $stmt->fetchAll();

// Check if user already purchased (for products)
$hasPurchased = false;
if ($post['post_type'] === 'product') {
    $stmt = $conn->prepare("SELECT id FROM purchases WHERE buyer_id = ? AND post_id = ? AND status = 'completed'");
    $stmt->execute([$currentUser['id'], $postId]);
    $hasPurchased = $stmt->fetch() ? true : false;
}

$flashMessage = getFlashMessage();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($post['title']); ?> - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/unified.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .post-detail-container {
            max-width: 900px;
            margin: 0 auto;
            padding: 20px;
        }
        .post-detail {
            background: white;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .post-header {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 20px;
            padding-bottom: 20px;
            border-bottom: 1px solid #eee;
        }
        .post-avatar {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            object-fit: cover;
        }
        .post-author-info {
            flex: 1;
        }
        .post-author-name {
            font-weight: bold;
            font-size: 18px;
            margin-bottom: 5px;
        }
        .post-author-name a {
            color: #333;
            text-decoration: none;
        }
        .post-author-name a:hover {
            color: #007bff;
        }
        .post-meta {
            display: flex;
            gap: 15px;
            font-size: 14px;
            color: #666;
        }
        .post-title {
            font-size: 32px;
            font-weight: bold;
            margin-bottom: 20px;
            color: #333;
        }
        .post-content {
            font-size: 16px;
            line-height: 1.8;
            color: #333;
            margin-bottom: 20px;
        }
        .post-images {
            margin: 20px 0;
        }
        .post-images img {
            width: 100%;
            border-radius: 10px;
            margin-bottom: 10px;
        }
        .product-info-box {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            margin: 20px 0;
        }
        .product-price {
            font-size: 32px;
            font-weight: bold;
            color: #28a745;
            margin-bottom: 15px;
        }
        .product-details {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
        }
        .product-detail-item {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .product-detail-item i {
            color: #007bff;
            font-size: 20px;
        }
        .post-stats {
            display: flex;
            gap: 30px;
            padding: 20px 0;
            border-top: 1px solid #eee;
            border-bottom: 1px solid #eee;
            margin: 20px 0;
        }
        .stat-item {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 16px;
            color: #666;
        }
        .stat-item i {
            color: #007bff;
        }
        .post-actions {
            display: flex;
            gap: 10px;
            margin: 20px 0;
        }
        .btn-action {
            flex: 1;
            padding: 12px;
            border: 1px solid #ddd;
            background: white;
            border-radius: 5px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            font-size: 16px;
            transition: all 0.3s;
        }
        .btn-action:hover {
            background: #f8f9fa;
        }
        .btn-action.active {
            color: #dc3545;
            border-color: #dc3545;
        }
        .btn-buy {
            background: #28a745;
            color: white;
            border-color: #28a745;
        }
        .btn-buy:hover {
            background: #218838;
        }
        .btn-purchased {
            background: #17a2b8;
            color: white;
            border-color: #17a2b8;
        }
        .comments-section {
            background: white;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .comments-section h3 {
            margin-bottom: 20px;
        }
        .comment-form {
            margin-bottom: 30px;
        }
        .comment-form textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            resize: vertical;
            min-height: 80px;
            font-family: inherit;
        }
        .comment-form button {
            margin-top: 10px;
            padding: 10px 20px;
            background: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .comment-item {
            display: flex;
            gap: 15px;
            padding: 15px 0;
            border-bottom: 1px solid #eee;
        }
        .comment-item:last-child {
            border-bottom: none;
        }
        .comment-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
        }
        .comment-content {
            flex: 1;
        }
        .comment-author {
            font-weight: bold;
            margin-bottom: 5px;
        }
        .comment-text {
            color: #333;
            margin-bottom: 5px;
        }
        .comment-time {
            font-size: 12px;
            color: #999;
        }
        .related-posts {
            background: white;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-top: 20px;
        }
        .related-posts h3 {
            margin-bottom: 20px;
        }
        .related-post-item {
            display: flex;
            gap: 15px;
            padding: 15px 0;
            border-bottom: 1px solid #eee;
        }
        .related-post-item:last-child {
            border-bottom: none;
        }
        .related-post-image {
            width: 100px;
            height: 100px;
            object-fit: cover;
            border-radius: 5px;
        }
        .related-post-info {
            flex: 1;
        }
        .related-post-title {
            font-weight: bold;
            margin-bottom: 5px;
        }
        .related-post-title a {
            color: #333;
            text-decoration: none;
        }
        .related-post-title a:hover {
            color: #007bff;
        }
        .dropdown {
            position: relative;
            display: inline-block;
        }
        .btn-icon {
            background: none;
            border: none;
            cursor: pointer;
            padding: 8px;
            font-size: 18px;
            color: #666;
        }
        .btn-icon:hover {
            color: #333;
        }
        .dropdown-menu {
            display: none;
            position: absolute;
            right: 0;
            background: white;
            min-width: 150px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border-radius: 5px;
            z-index: 1000;
        }
        .dropdown-menu a {
            display: block;
            padding: 10px 15px;
            color: #333;
            text-decoration: none;
        }
        .dropdown-menu a:hover {
            background: #f8f9fa;
        }
        .badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 3px;
            font-size: 12px;
            font-weight: bold;
        }
        .badge-success {
            background: #d4edda;
            color: #155724;
        }
        .badge-info {
            background: #d1ecf1;
            color: #0c5460;
        }
        @media (max-width: 768px) {
            .post-detail {
                padding: 20px;
            }
            .post-title {
                font-size: 24px;
            }
            .product-price {
                font-size: 24px;
            }
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <div class="container">
        <?php if ($flashMessage): ?>
            <div class="alert alert-<?php echo $flashMessage['type']; ?>">
                <?php echo $flashMessage['message']; ?>
            </div>
        <?php endif; ?>
        
        <div class="post-detail">
            <div class="post-header">
                <img src="uploads/profiles/<?php echo htmlspecialchars($post['profile_photo']); ?>" alt="Profile" class="post-avatar">
                <div class="post-author-info">
                    <div class="post-author-name">
                        <a href="profile.php?id=<?php echo $post['author_id']; ?>"><?php echo htmlspecialchars($post['full_name']); ?></a>
                    </div>
                    <div class="post-meta">
                        <span><i class="fas fa-clock"></i> <?php echo timeAgo($post['created_at']); ?></span>
                        <span><i class="fas fa-eye"></i> <?php echo $post['views']; ?> views</span>
                        <?php if ($post['post_type'] === 'product'): ?>
                            <span class="badge badge-success">Produk</span>
                        <?php else: ?>
                            <span class="badge badge-info">Komunitas</span>
                        <?php endif; ?>
                    </div>
                </div>
                <?php if ($post['author_id'] == $currentUser['id']): ?>
                    <div class="dropdown">
                        <button class="btn-icon" onclick="toggleDropdown(this)">
                            <i class="fas fa-ellipsis-v"></i>
                        </button>
                        <div class="dropdown-menu">
                            <a href="#" onclick="editPost(<?php echo $post['id']; ?>)">
                                <i class="fas fa-edit"></i> Edit
                            </a>
                            <a href="#" onclick="deletePost(<?php echo $post['id']; ?>)">
                                <i class="fas fa-trash"></i> Hapus
                            </a>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            
            <h1 class="post-title"><?php echo htmlspecialchars($post['title']); ?></h1>
            
            <div class="post-content">
                <?php echo nl2br(htmlspecialchars($post['content'])); ?>
            </div>
            
            <?php if (!empty($post['images'])): ?>
                <?php $images = json_decode($post['images'], true); ?>
                <?php if (is_array($images) && !empty($images)): ?>
                    <div class="post-images">
                        <?php foreach ($images as $image): ?>
                            <img src="uploads/posts/<?php echo htmlspecialchars($image); ?>" alt="Post image">
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
            
            <?php if ($post['post_type'] === 'product'): ?>
                <div class="product-info-box">
                    <div class="product-price">
                        Rp <?php echo number_format($post['product_price'], 0, ',', '.'); ?>
                    </div>
                    <div class="product-details">
                        <div class="product-detail-item">
                            <i class="fas fa-tag"></i>
                            <span><?php echo htmlspecialchars($post['product_category'] ?? 'Umum'); ?></span>
                        </div>
                        <div class="product-detail-item">
                            <i class="fas fa-box"></i>
                            <span><?php echo $post['product_type'] === 'digital' ? 'Produk Digital' : 'Produk Fisik'; ?></span>
                        </div>
                        <?php if ($hasPurchased): ?>
                            <div class="product-detail-item" style="color: #28a745;">
                                <i class="fas fa-check-circle"></i>
                                <span>Anda sudah membeli produk ini</span>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
            
            <div class="post-stats">
                <div class="stat-item">
                    <i class="fas fa-heart"></i>
                    <span><?php echo $post['like_count']; ?> Suka</span>
                </div>
                <div class="stat-item">
                    <i class="fas fa-comment"></i>
                    <span><?php echo $post['comment_count']; ?> Komentar</span>
                </div>
                <div class="stat-item">
                    <i class="fas fa-share"></i>
                    <span><?php echo $post['share_count']; ?> Bagikan</span>
                </div>
            </div>
            
            <div class="post-actions">
                <button class="btn-action <?php echo $post['user_liked'] ? 'active' : ''; ?>" onclick="toggleLike(<?php echo $post['id']; ?>)">
                    <i class="fas fa-heart"></i> Suka
                </button>
                <button class="btn-action" onclick="document.getElementById('comment-input').focus()">
                    <i class="fas fa-comment"></i> Komentar
                </button>
                <button class="btn-action" onclick="sharePost(<?php echo $post['id']; ?>)">
                    <i class="fas fa-share"></i> Bagikan
                </button>
                <?php if ($post['post_type'] === 'product'): ?>
                    <?php if ($hasPurchased): ?>
                        <button class="btn-action btn-purchased" onclick="window.location.href='purchase.php?id=<?php echo $post['id']; ?>'">
                            <i class="fas fa-download"></i> Download
                        </button>
                    <?php elseif ($post['author_id'] != $currentUser['id']): ?>
                        <button class="btn-action btn-buy" onclick="window.location.href='purchase.php?id=<?php echo $post['id']; ?>'">
                            <i class="fas fa-shopping-cart"></i> Beli
                        </button>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="comments-section">
            <h3>Komentar (<?php echo $post['comment_count']; ?>)</h3>
            
            <div class="comment-form">
                <form onsubmit="addComment(event, <?php echo $post['id']; ?>)">
                    <textarea id="comment-input" name="comment" placeholder="Tulis komentar..." required></textarea>
                    <button type="submit">Kirim Komentar</button>
                </form>
            </div>
            
            <div id="comments-list">
                <?php foreach ($comments as $comment): ?>
                    <div class="comment-item">
                        <img src="uploads/profiles/<?php echo htmlspecialchars($comment['profile_photo']); ?>" alt="Avatar" class="comment-avatar">
                        <div class="comment-content">
                            <div class="comment-author">
                                <a href="profile.php?id=<?php echo $comment['user_id']; ?>"><?php echo htmlspecialchars($comment['full_name']); ?></a>
                            </div>
                            <div class="comment-text"><?php echo nl2br(htmlspecialchars($comment['content'])); ?></div>
                            <div class="comment-time"><?php echo timeAgo($comment['created_at']); ?></div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        
        <?php
        // Get related posts
        $relatedSql = "SELECT p.*, u.username, u.full_name, u.profile_photo 
                      FROM posts p 
                      JOIN users u ON p.user_id = u.id 
                      WHERE p.status = 'active' AND p.id != ?";
        $relatedParams = [$postId];
        
        if ($post['post_type'] === 'product' && !empty($post['product_category'])) {
            $relatedSql .= " AND p.product_category = ?";
            $relatedParams[] = $post['product_category'];
        } else {
            $relatedSql .= " AND p.post_type = ?";
            $relatedParams[] = $post['post_type'];
        }
        
        $relatedSql .= " ORDER BY p.created_at DESC LIMIT 5";
        
        $stmt = $conn->prepare($relatedSql);
        $stmt->execute($relatedParams);
        $relatedPosts = $stmt->fetchAll();
        ?>
        
        <?php if (!empty($relatedPosts)): ?>
            <div class="related-posts">
                <h3>Postingan Terkait</h3>
                <?php foreach ($relatedPosts as $related): ?>
                    <div class="related-post-item">
                        <?php 
                        $relatedImages = !empty($related['images']) ? json_decode($related['images'], true) : [];
                        $relatedImage = !empty($relatedImages) ? $relatedImages[0] : 'default-post.png';
                        ?>
                        <img src="uploads/posts/<?php echo htmlspecialchars($relatedImage); ?>" alt="Post" class="related-post-image">
                        <div class="related-post-info">
                            <div class="related-post-title">
                                <a href="post-detail.php?id=<?php echo $related['id']; ?>"><?php echo htmlspecialchars($related['title']); ?></a>
                            </div>
                            <div style="font-size: 14px; color: #666; margin-bottom: 5px;">
                                <?php echo htmlspecialchars(substr($related['content'], 0, 100)); ?>...
                            </div>
                            <div style="font-size: 12px; color: #999;">
                                oleh <?php echo htmlspecialchars($related['full_name']); ?> • <?php echo timeAgo($related['created_at']); ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
    
    <?php include 'includes/footer.php'; ?>
    
    <script src="assets/js/main.js"></script>
    <script>
        function addComment(event, postId) {
            event.preventDefault();
            
            const form = event.target;
            const comment = form.comment.value;
            
            fetch('api/add-comment.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `post_id=${postId}&content=${encodeURIComponent(comment)}&csrf_token=<?php echo generateCSRFToken(); ?>`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                } else {
                    alert(data.message || 'Gagal menambahkan komentar');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Terjadi kesalahan');
            });
        }
        
        function toggleDropdown(button) {
            const dropdown = button.nextElementSibling;
            dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
        }
        
        // Close dropdown when clicking outside
        document.addEventListener('click', function(event) {
            if (!event.target.matches('.btn-icon') && !event.target.matches('.fa-ellipsis-v')) {
                const dropdowns = document.getElementsByClassName('dropdown-menu');
                for (let i = 0; i < dropdowns.length; i++) {
                    dropdowns[i].style.display = 'none';
                }
            }
        });
    </script>
</body>
</html>