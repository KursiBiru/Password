<?php
require_once 'config.php';

// Generate captcha code
$code = generateCaptcha();

// Create image
$width = 150;
$height = 50;
$image = imagecreatetruecolor($width, $height);

// Colors
$bgColor = imagecolorallocate($image, 255, 255, 255);
$textColor = imagecolorallocate($image, 0, 0, 0);
$lineColor = imagecolorallocate($image, 200, 200, 200);

// Fill background
imagefilledrectangle($image, 0, 0, $width, $height, $bgColor);

// Add noise lines
for ($i = 0; $i < 5; $i++) {
    imageline($image, rand(0, $width), rand(0, $height), rand(0, $width), rand(0, $height), $lineColor);
}

// Add text
$fontSize = 20;
$angle = rand(-10, 10);
$x = 20;
$y = 35;

// Use built-in font
imagestring($image, 5, $x, $y - 20, $code, $textColor);

// Output image
header('Content-Type: image/png');
imagepng($image);
imagedestroy($image);