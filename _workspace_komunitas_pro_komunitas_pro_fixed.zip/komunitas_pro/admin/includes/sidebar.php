<aside class="admin-sidebar">
    <div class="sidebar-header">
        <h2><i class="fas fa-shield-alt"></i> Admin Panel</h2>
    </div>
    
    <nav class="sidebar-nav">
        <a href="index.php" class="nav-item <?php echo basename($_SERVER['PHP_SELF']) === 'index.php' ? 'active' : ''; ?>">
            <i class="fas fa-home"></i>
            <span>Dashboard</span>
        </a>
        
        <a href="users.php" class="nav-item <?php echo basename($_SERVER['PHP_SELF']) === 'users.php' ? 'active' : ''; ?>">
            <i class="fas fa-users"></i>
            <span>Kelola Pengguna</span>
        </a>
        
        <a href="posts.php" class="nav-item <?php echo basename($_SERVER['PHP_SELF']) === 'posts.php' ? 'active' : ''; ?>">
            <i class="fas fa-file-alt"></i>
            <span>Kelola Postingan</span>
        </a>
        
        <a href="transactions.php" class="nav-item <?php echo basename($_SERVER['PHP_SELF']) === 'transactions.php' ? 'active' : ''; ?>">
            <i class="fas fa-exchange-alt"></i>
            <span>Kelola Transaksi</span>
        </a>
        
        <a href="revenue.php" class="nav-item <?php echo basename($_SERVER['PHP_SELF']) === 'revenue.php' ? 'active' : ''; ?>">
            <i class="fas fa-chart-line"></i>
            <span>Pendapatan</span>
        </a>
        
        <a href="settings.php" class="nav-item <?php echo basename($_SERVER['PHP_SELF']) === 'settings.php' ? 'active' : ''; ?>">
            <i class="fas fa-cog"></i>
            <span>Pengaturan</span>
        </a>
        
        <hr style="margin: 20px 0; border: none; border-top: 1px solid rgba(255,255,255,0.1);">
        
        <a href="../index.php" class="nav-item">
            <i class="fas fa-globe"></i>
            <span>Lihat Website</span>
        </a>
        
        <a href="../logout.php" class="nav-item">
            <i class="fas fa-sign-out-alt"></i>
            <span>Keluar</span>
        </a>
    </nav>
</aside>