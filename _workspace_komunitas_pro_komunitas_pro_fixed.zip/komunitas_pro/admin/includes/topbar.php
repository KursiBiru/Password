<header class="admin-topbar">
    <div class="topbar-left">
        <button class="btn-menu-toggle" onclick="toggleSidebar()">
            <i class="fas fa-bars"></i>
        </button>
        <h2><?php echo ucfirst(str_replace('.php', '', basename($_SERVER['PHP_SELF']))); ?></h2>
    </div>
    
    <div class="topbar-right">
        <div class="topbar-item">
            <a href="notifications.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) === 'notifications.php' ? 'active' : ''; ?>">
                <i class="fas fa-bell"></i>
            </a>
            <?php
            $pendingCount = 0;
            $stmt = $conn->query("SELECT COUNT(*) as count FROM transactions WHERE status = 'pending'");
            $pendingCount = $stmt->fetch()['count'];
            if ($pendingCount > 0):
            ?>
            <span class="badge"><?php echo $pendingCount; ?></span>
            <?php endif; ?>
        </div>
        
        <div class="topbar-user">
            <img src="../uploads/profiles/<?php echo htmlspecialchars($user['profile_photo']); ?>" alt="Profile" class="avatar-small">
            <span><?php echo htmlspecialchars($user['username']); ?></span>
        </div>
    </div>
</header>