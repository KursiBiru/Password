<?php
require_once '../config.php';
requireAdmin();

$user = getCurrentUser();
$conn = getDBConnection();

// Handle transaction actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        setFlashMessage('danger', 'Invalid CSRF token');
    } else {
        $action = $_POST['action'];
        $transactionId = $_POST['transaction_id'];
        
        if ($action === 'approve') {
            $stmt = $conn->prepare("SELECT * FROM transactions WHERE id = ?");
            $stmt->execute([$transactionId]);
            $transaction = $stmt->fetch();
            
            if ($transaction && $transaction['status'] === 'pending' && $transaction['transaction_type'] === 'deposit') {
                // Update transaction status
                $stmt = $conn->prepare("UPDATE transactions SET status = 'completed' WHERE id = ?");
                $stmt->execute([$transactionId]);
                
                // Add to user wallet
                $stmt = $conn->prepare("UPDATE users SET wallet_balance = wallet_balance + ? WHERE id = ?");
                $stmt->execute([$transaction['net_amount'], $transaction['user_id']]);
                
                // Create notification
                createNotification(
                    $transaction['user_id'],
                    'transaction',
                    'Deposit Disetujui',
                    'Deposit Anda sebesar ' . formatCurrency($transaction['net_amount']) . ' telah disetujui',
                    'wallet.php'
                );
                
                setFlashMessage('success', 'Deposit berhasil disetujui');
            }
            if ($transaction && $transaction['status'] === 'pending' && $transaction['transaction_type'] === 'withdrawal') {
                // Update transaction status
                $stmt = $conn->prepare("UPDATE transactions SET status = 'completed' WHERE id = ?");
                $stmt->execute([$transactionId]);
                
                // Add to user wallet
                $stmt = $conn->prepare("UPDATE users SET wallet_balance = wallet_balance - ? WHERE id = ?");
                $stmt->execute([$transaction['net_amount'], $transaction['user_id']]);
                
                // Create notification
                createNotification(
                    $transaction['user_id'],
                    'transaction',
                    'Withdrawal Disetujui',
                    'Withdrawal Anda sebesar ' . formatCurrency($transaction['net_amount']) . ' telah disetujui',
                    'wallet.php'
                );
                
                setFlashMessage('success', 'Withdrawal berhasil disetujui');
            }
        } elseif ($action === 'reject') {
            $stmt = $conn->prepare("SELECT * FROM transactions WHERE id = ?");
            $stmt->execute([$transactionId]);
            $transaction = $stmt->fetch();
            
            if ($transaction && $transaction['status'] === 'pending') {
                $stmt = $conn->prepare("UPDATE transactions SET status = 'rejected', admin_note = ? WHERE id = ?");
                $stmt->execute([$_POST['admin_note'] ?? 'Ditolak oleh admin', $transactionId]);
                
                createNotification(
                    $transaction['user_id'],
                    'transaction',
                    'Transaksi Ditolak',
                    'Transaksi Anda telah ditolak',
                    'wallet.php'
                );
                
                setFlashMessage('success', 'Transaksi berhasil ditolak');
            }
        }
        redirect('transactions.php');
    }
}

// Get transactions
$status = $_GET['status'] ?? 'all';
$type = $_GET['type'] ?? 'all';

$query = "SELECT t.*, u.username, u.full_name FROM transactions t JOIN users u ON t.user_id = u.id WHERE 1=1";
$params = [];

if ($status !== 'all') {
    $query .= " AND t.status = ?";
    $params[] = $status;
}

if ($type !== 'all') {
    $query .= " AND t.transaction_type = ?";
    $params[] = $type;
}

$query .= " ORDER BY t.created_at DESC LIMIT 100";

$stmt = $conn->prepare($query);
$stmt->execute($params);
$transactions = $stmt->fetchAll();

$flashMessage = getFlashMessage();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Transaksi - Admin</title>
    <link rel="stylesheet" href="../assets/css/unified.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/dark-mode.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include 'includes/sidebar.php'; ?>
    
    <div class="admin-main">
        <?php include 'includes/topbar.php'; ?>
        
        <div class="admin-content">
            <div class="page-header">
                <h1>Kelola Transaksi</h1>
                <p>Kelola semua transaksi pengguna</p>
            </div>
            
            <?php if ($flashMessage): ?>
                <div class="alert alert-<?php echo $flashMessage['type']; ?>">
                    <?php echo $flashMessage['message']; ?>
                </div>
            <?php endif; ?>
            
            <!-- Filter Bar -->
            <div class="filter-bar">
                <form method="GET" style="display: flex; gap: 15px; flex: 1;">
                    <select name="status" class="form-control">
                        <option value="all" <?php echo $status === 'all' ? 'selected' : ''; ?>>Semua Status</option>
                        <option value="pending" <?php echo $status === 'pending' ? 'selected' : ''; ?>>Pending</option>
                        <option value="completed" <?php echo $status === 'completed' ? 'selected' : ''; ?>>Completed</option>
                        <option value="rejected" <?php echo $status === 'rejected' ? 'selected' : ''; ?>>Rejected</option>
                    </select>
                    <select name="type" class="form-control">
                        <option value="all" <?php echo $type === 'all' ? 'selected' : ''; ?>>Semua Tipe</option>
                        <option value="deposit" <?php echo $type === 'deposit' ? 'selected' : ''; ?>>Deposit</option>
                        <option value="withdrawal" <?php echo $type === 'withdrawal' ? 'selected' : ''; ?>>Withdrawal</option>
                        <option value="purchase" <?php echo $type === 'purchase' ? 'selected' : ''; ?>>Purchase</option>
                        <option value="sale" <?php echo $type === 'sale' ? 'selected' : ''; ?>>Sale</option>
                    </select>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-filter"></i> Filter
                    </button>
                </form>
            </div>
            
            <!-- Transactions Table -->
            <div class="dashboard-card">
                <div class="card-body">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Pengguna</th>
                                <th>Tipe</th>
                                <th>Jumlah</th>
                                <th>Fee</th>
                                <th>Net</th>
                                <th>Status</th>
                                <th>Tanggal</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($transactions as $t): ?>
                            <tr>
                                <td><?php echo $t['id']; ?></td>
                                <td>
                                    <strong><?php echo htmlspecialchars($t['full_name']); ?></strong><br>
                                    <small>@<?php echo htmlspecialchars($t['username']); ?></small>
                                </td>
                                <td><?php echo ucfirst($t['transaction_type']); ?></td>
                                <td><?php echo formatCurrency($t['amount']); ?></td>
                                <td><?php echo formatCurrency($t['fee']); ?></td>
                                <td><?php echo formatCurrency($t['net_amount']); ?></td>
                                <td>
                                    <span class="status status-<?php echo $t['status']; ?>">
                                        <?php echo ucfirst($t['status']); ?>
                                    </span>
                                </td>
                                <td><?php echo date('d M Y H:i', strtotime($t['created_at'])); ?></td>
                                <td>
                                    <?php if ($t['status'] === 'pending'): ?>
                                        <div class="action-buttons">
                                            <?php if ($t['proof_image']): ?>
                                                <a href="../uploads/proofs/<?php echo $t['proof_image']; ?>" target="_blank" class="btn-icon btn-view" title="Lihat Bukti">
                                                    <i class="fas fa-image"></i>
                                                </a>
                                            <?php endif; ?>
                                            <form method="POST" style="display: inline;">
                                                <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                                                <input type="hidden" name="transaction_id" value="<?php echo $t['id']; ?>">
                                                <input type="hidden" name="action" value="approve">
                                                <button type="submit" class="btn-icon btn-edit" title="Setujui" onclick="return confirm('Setujui transaksi ini?')">
                                                    <i class="fas fa-check"></i>
                                                </button>
                                            </form>
                                            <button class="btn-icon btn-delete" title="Tolak" onclick="rejectTransaction(<?php echo $t['id']; ?>)">
                                                <i class="fas fa-times"></i>
                                            </button>
                                        </div>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Reject Modal -->
    <div id="rejectModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeRejectModal()">&times;</span>
            <h2>Tolak Transaksi</h2>
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                <input type="hidden" name="transaction_id" id="reject_transaction_id">
                <input type="hidden" name="action" value="reject">
                
                <div class="form-group">
                    <label for="admin_note">Alasan Penolakan</label>
                    <textarea name="admin_note" id="admin_note" class="form-control" rows="4" required></textarea>
                </div>
                
                <button type="submit" class="btn btn-danger">Tolak Transaksi</button>
            </form>
        </div>
    </div>
    
    <script src="../assets/js/main.js"></script>
    <script src="../assets/js/admin.js"></script>
    <script src="../assets/js/dark-mode.js"></script>
    <script>
        function rejectTransaction(transactionId) {
            document.getElementById('reject_transaction_id').value = transactionId;
            document.getElementById('rejectModal').style.display = 'block';
        }
        
        function closeRejectModal() {
            document.getElementById('rejectModal').style.display = 'none';
        }
    </script>
</body>
</html>