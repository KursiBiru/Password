<?php
require_once '../../config.php';
requireAdmin();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
}

$notification_id = intval($_POST['notification_id'] ?? 0);

if ($notification_id <= 0) {
    jsonResponse(['success' => false, 'message' => 'Invalid notification ID'], 400);
}

$conn = getDBConnection();

// Delete notification
$stmt = $conn->prepare("DELETE FROM notifications WHERE id = ?");
$result = $stmt->execute([$notification_id]);

if ($result) {
    jsonResponse(['success' => true, 'message' => 'Notification deleted successfully']);
} else {
    jsonResponse(['success' => false, 'message' => 'Failed to delete notification'], 500);
}
?>