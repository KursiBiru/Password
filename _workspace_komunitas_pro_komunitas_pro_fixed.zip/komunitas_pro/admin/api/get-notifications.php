<?php
require_once '../../config.php';
requireAdmin();

header('Content-Type: application/json');

$conn = getDBConnection();

// Get unread notifications count
$stmt = $conn->prepare("SELECT COUNT(*) as count 
                        FROM notifications n 
                        JOIN users u ON n.user_id = u.id 
                        WHERE u.is_admin = 1 AND n.is_read = 0");
$stmt->execute();
$unread_count = $stmt->fetch()['count'];

// Get recent notifications
$stmt = $conn->prepare("SELECT n.*, u.username, u.full_name 
                        FROM notifications n 
                        JOIN users u ON n.user_id = u.id 
                        WHERE u.is_admin = 1 
                        ORDER BY n.created_at DESC 
                        LIMIT 10");
$stmt->execute();
$notifications = $stmt->fetchAll();

jsonResponse([
    'success' => true,
    'notifications' => $notifications,
    'unread_count' => $unread_count
]);
?>