<?php
require_once '../config.php';
requireAdmin();

$user = getCurrentUser();
$conn = getDBConnection();

// Handle settings update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        setFlashMessage('danger', 'Invalid CSRF token');
    } else {
        foreach ($_POST as $key => $value) {
            if ($key !== 'csrf_token') {
                updateSetting($key, $value);
            }
        }
        setFlashMessage('success', 'Pengaturan berhasil disimpan');
        redirect('settings.php');
    }
}

$flashMessage = getFlashMessage();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pengaturan - Admin</title>
    <link rel="stylesheet" href="../assets/css/unified.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/dark-mode.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include 'includes/sidebar.php'; ?>
    
    <div class="admin-main">
        <?php include 'includes/topbar.php'; ?>
        
        <div class="admin-content">
            <div class="page-header">
                <h1>Pengaturan Website</h1>
                <p>Kelola pengaturan website</p>
            </div>
            
            <?php if ($flashMessage): ?>
                <div class="alert alert-<?php echo $flashMessage['type']; ?>">
                    <?php echo $flashMessage['message']; ?>
                </div>
            <?php endif; ?>
            
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                
                <!-- General Settings -->
                <div class="settings-section">
                    <h3>Pengaturan Umum</h3>
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="site_name">Nama Website</label>
                            <input type="text" id="site_name" name="site_name" class="form-control" 
                                   value="<?php echo htmlspecialchars(getSetting('site_name', 'Komunitas Marketplace')); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="site_email">Email Website</label>
                            <input type="email" id="site_email" name="site_email" class="form-control" 
                                   value="<?php echo htmlspecialchars(getSetting('site_email', 'info@komunitas.com')); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="youtube_channel">Channel YouTube</label>
                            <input type="text" id="youtube_channel" name="youtube_channel" class="form-control" 
                                   value="<?php echo htmlspecialchars(getSetting('youtube_channel', 'kursibiru')); ?>">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="site_description">Deskripsi Website</label>
                        <textarea id="site_description" name="site_description" class="form-control" rows="3"><?php echo htmlspecialchars(getSetting('site_description', '')); ?></textarea>
                    </div>
                </div>
                
                <!-- Transaction Settings -->
                <div class="settings-section">
                    <h3>Pengaturan Transaksi</h3>
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="withdrawal_fee_percent">Fee Penarikan (%)</label>
                            <input type="number" id="withdrawal_fee_percent" name="withdrawal_fee_percent" class="form-control" 
                                   value="<?php echo getSetting('withdrawal_fee_percent', '3'); ?>" min="0" max="100" step="0.1">
                        </div>
                        
                        <div class="form-group">
                            <label for="min_withdrawal">Minimum Penarikan (Rp)</label>
                            <input type="number" id="min_withdrawal" name="min_withdrawal" class="form-control" 
                                   value="<?php echo getSetting('min_withdrawal', '50000'); ?>" min="0" step="1000">
                        </div>
                    </div>
                </div>
                
                <!-- Midtrans Settings -->
                <div class="settings-section">
                    <h3>Pengaturan Midtrans</h3>
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="midtrans_server_key">Server Key</label>
                            <input type="text" id="midtrans_server_key" name="midtrans_server_key" class="form-control" 
                                   value="<?php echo htmlspecialchars(getSetting('midtrans_server_key', '')); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="midtrans_client_key">Client Key</label>
                            <input type="text" id="midtrans_client_key" name="midtrans_client_key" class="form-control" 
                                   value="<?php echo htmlspecialchars(getSetting('midtrans_client_key', '')); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="midtrans_is_production">Mode</label>
                            <select id="midtrans_is_production" name="midtrans_is_production" class="form-control">
                                <option value="0" <?php echo getSetting('midtrans_is_production', '0') == '0' ? 'selected' : ''; ?>>Sandbox</option>
                                <option value="1" <?php echo getSetting('midtrans_is_production', '0') == '1' ? 'selected' : ''; ?>>Production</option>
                            </select>
                        </div>
                    </div>
                </div>
                
                <!-- Upload Settings -->
                <div class="settings-section">
                    <h3>Pengaturan Upload</h3>
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="max_upload_size">Ukuran Upload Maksimal (MB)</label>
                            <input type="number" id="max_upload_size" name="max_upload_size" class="form-control" 
                                   value="<?php echo getSetting('max_upload_size', '10'); ?>" min="1" max="100">
                        </div>
                        
                        <div class="form-group">
                            <label for="allowed_file_types">Tipe File yang Diizinkan</label>
                            <input type="text" id="allowed_file_types" name="allowed_file_types" class="form-control" 
                                   value="<?php echo htmlspecialchars(getSetting('allowed_file_types', 'jpg,jpeg,png,gif,pdf,zip,rar')); ?>">
                            <small class="form-text">Pisahkan dengan koma</small>
                        </div>
                    </div>
                </div>
                
                <!-- Security Settings -->
                <div class="settings-section">
                    <h3>Pengaturan Keamanan</h3>
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="enable_registration">Aktifkan Registrasi</label>
                            <select id="enable_registration" name="enable_registration" class="form-control">
                                <option value="1" <?php echo getSetting('enable_registration', '1') == '1' ? 'selected' : ''; ?>>Ya</option>
                                <option value="0" <?php echo getSetting('enable_registration', '1') == '0' ? 'selected' : ''; ?>>Tidak</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="enable_captcha">Aktifkan CAPTCHA</label>
                            <select id="enable_captcha" name="enable_captcha" class="form-control">
                                <option value="1" <?php echo getSetting('enable_captcha', '1') == '1' ? 'selected' : ''; ?>>Ya</option>
                                <option value="0" <?php echo getSetting('enable_captcha', '1') == '0' ? 'selected' : ''; ?>>Tidak</option>
                            </select>
                        </div>
                    </div>
                </div>
                
                <button type="submit" class="btn btn-primary btn-lg">
                    <i class="fas fa-save"></i> Simpan Pengaturan
                </button>
            </form>
        </div>
    </div>
    
    <script src="../assets/js/main.js"></script>
    <script src="../assets/js/admin.js"></script>
    <script src="../assets/js/dark-mode.js"></script>
</body>
</html>