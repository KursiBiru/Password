<?php
require_once '../config.php';
requireAdmin();

$user = getCurrentUser();
$conn = getDBConnection();

// Handle user actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        setFlashMessage('danger', 'Invalid CSRF token');
    } else {
        $action = $_POST['action'];
        $userId = $_POST['user_id'];
        
        if ($action === 'ban') {
            $stmt = $conn->prepare("UPDATE users SET is_banned = 1 WHERE id = ?");
            $stmt->execute([$userId]);
            setFlashMessage('success', 'User berhasil dibanned');
        } elseif ($action === 'unban') {
            $stmt = $conn->prepare("UPDATE users SET is_banned = 0 WHERE id = ?");
            $stmt->execute([$userId]);
            setFlashMessage('success', 'User berhasil di-unban');
        } elseif ($action === 'delete') {
            $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
            $stmt->execute([$userId]);
            setFlashMessage('success', 'User berhasil dihapus');
        }
        redirect('users.php');
    }
}

// Get users
$search = $_GET['search'] ?? '';
$status = $_GET['status'] ?? 'all';

$query = "SELECT * FROM users WHERE is_admin = 0";
$params = [];

if (!empty($search)) {
    $query .= " AND (username LIKE ? OR email LIKE ? OR full_name LIKE ?)";
    $searchTerm = "%$search%";
    $params = [$searchTerm, $searchTerm, $searchTerm];
}

if ($status === 'banned') {
    $query .= " AND is_banned = 1";
} elseif ($status === 'active') {
    $query .= " AND is_banned = 0";
}

$query .= " ORDER BY created_at DESC";

$stmt = $conn->prepare($query);
$stmt->execute($params);
$users = $stmt->fetchAll();

$flashMessage = getFlashMessage();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Pengguna - Admin</title>
    <link rel="stylesheet" href="../assets/css/unified.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/dark-mode.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include 'includes/sidebar.php'; ?>
    
    <div class="admin-main">
        <?php include 'includes/topbar.php'; ?>
        
        <div class="admin-content">
            <div class="page-header">
                <h1>Kelola Pengguna</h1>
                <p>Kelola semua pengguna di platform</p>
            </div>
            
            <?php if ($flashMessage): ?>
                <div class="alert alert-<?php echo $flashMessage['type']; ?>">
                    <?php echo $flashMessage['message']; ?>
                </div>
            <?php endif; ?>
            
            <!-- Filter Bar -->
            <div class="filter-bar">
                <form method="GET" style="display: flex; gap: 15px; flex: 1;">
                    <input type="text" name="search" placeholder="Cari pengguna..." class="form-control" value="<?php echo htmlspecialchars($search); ?>">
                    <select name="status" class="form-control" style="max-width: 200px;">
                        <option value="all" <?php echo $status === 'all' ? 'selected' : ''; ?>>Semua Status</option>
                        <option value="active" <?php echo $status === 'active' ? 'selected' : ''; ?>>Aktif</option>
                        <option value="banned" <?php echo $status === 'banned' ? 'selected' : ''; ?>>Banned</option>
                    </select>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-search"></i> Cari
                    </button>
                </form>
            </div>
            
            <!-- Users Table -->
            <div class="dashboard-card">
                <div class="card-body">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Pengguna</th>
                                <th>Email</th>
                                <th>Saldo</th>
                                <th>Status</th>
                                <th>Bergabung</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users as $u): ?>
                            <tr>
                                <td><?php echo $u['id']; ?></td>
                                <td>
                                    <div style="display: flex; align-items: center; gap: 10px;">
                                        <img src="../uploads/profiles/<?php echo htmlspecialchars($u['profile_photo']); ?>" 
                                             alt="Profile" style="width: 40px; height: 40px; border-radius: 50%;">
                                        <div>
                                            <strong><?php echo htmlspecialchars($u['full_name']); ?></strong><br>
                                            <small>@<?php echo htmlspecialchars($u['username']); ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td><?php echo htmlspecialchars($u['email']); ?></td>
                                <td><?php echo formatCurrency($u['wallet_balance']); ?></td>
                                <td>
                                    <?php if ($u['is_banned']): ?>
                                        <span class="status status-rejected">Banned</span>
                                    <?php else: ?>
                                        <span class="status status-completed">Aktif</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo date('d M Y', strtotime($u['created_at'])); ?></td>
                                <td>
                                    <div class="action-buttons">
                                        <a href="../profile.php?id=<?php echo $u['id']; ?>" target="_blank" class="btn-icon btn-view" title="Lihat Profil">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <form method="POST" style="display: inline;">
                                            <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                                            <input type="hidden" name="user_id" value="<?php echo $u['id']; ?>">
                                            <?php if ($u['is_banned']): ?>
                                                <input type="hidden" name="action" value="unban">
                                                <button type="submit" class="btn-icon btn-edit" title="Unban" onclick="return confirm('Unban user ini?')">
                                                    <i class="fas fa-check"></i>
                                                </button>
                                            <?php else: ?>
                                                <input type="hidden" name="action" value="ban">
                                                <button type="submit" class="btn-icon btn-delete" title="Ban" onclick="return confirm('Ban user ini?')">
                                                    <i class="fas fa-ban"></i>
                                                </button>
                                            <?php endif; ?>
                                        </form>
                                        <form method="POST" style="display: inline;">
                                            <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                                            <input type="hidden" name="user_id" value="<?php echo $u['id']; ?>">
                                            <input type="hidden" name="action" value="delete">
                                            <button type="submit" class="btn-icon btn-delete" title="Hapus" onclick="return confirm('Hapus user ini? Semua data akan terhapus!')">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <script src="../assets/js/main.js"></script>
    <script src="../assets/js/admin.js"></script>
    <script src="../assets/js/dark-mode.js"></script>
</body>
</html>