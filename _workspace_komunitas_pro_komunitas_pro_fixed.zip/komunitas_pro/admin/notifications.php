<?php
require_once '../config.php';
requireAdmin();

$page_title = 'Kelola Notifikasi';
$user = getCurrentUser();
$conn = getDBConnection();

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    switch ($action) {
        case 'delete_all':
            $stmt = $conn->prepare("DELETE FROM notifications WHERE user_id IN (SELECT id FROM users WHERE is_admin = 1)");
            $stmt->execute();
            setFlashMessage('success', 'Semua notifikasi admin telah dihapus');
            break;
            
        case 'mark_all_read':
            $stmt = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE user_id IN (SELECT id FROM users WHERE is_admin = 1)");
            $stmt->execute();
            setFlashMessage('success', 'Semua notifikasi ditandai sebagai dibaca');
            break;
    }
    
    header('Location: notifications.php');
    exit;
}

// Get pagination
$page = max(1, intval($_GET['page'] ?? 1));
$per_page = 20;
$offset = ($page - 1) * $per_page;

// Get filters
$type_filter = $_GET['type'] ?? '';
$status_filter = $_GET['status'] ?? '';

// Build query
$where_conditions = ["u.is_admin = 1"];
$params = [];

if ($type_filter) {
    $where_conditions[] = "n.type = ?";
    $params[] = $type_filter;
}

if ($status_filter === 'read') {
    $where_conditions[] = "n.is_read = 1";
} elseif ($status_filter === 'unread') {
    $where_conditions[] = "n.is_read = 0";
}

$where_clause = "WHERE " . implode(" AND ", $where_conditions);

// Get total notifications
$count_sql = "SELECT COUNT(*) as total 
              FROM notifications n 
              JOIN users u ON n.user_id = u.id 
              $where_clause";
$stmt = $conn->prepare($count_sql);
$stmt->execute($params);
$total = $stmt->fetch()['total'];
$total_pages = ceil($total / $per_page);

// Get notifications
$sql = "SELECT n.*, u.username, u.full_name 
        FROM notifications n 
        JOIN users u ON n.user_id = u.id 
        $where_clause 
        ORDER BY n.created_at DESC 
        LIMIT $per_page OFFSET $offset";
$stmt = $conn->prepare($sql);
$stmt->execute($params);
$notifications = $stmt->fetchAll();

// Get statistics
$unread_count_sql = "SELECT COUNT(*) as count 
                     FROM notifications n 
                     JOIN users u ON n.user_id = u.id 
                     WHERE u.is_admin = 1 AND n.is_read = 0";
$stmt = $conn->prepare($unread_count_sql);
$stmt->execute();
$unread_count = $stmt->fetch()['count'];

$type_stats_sql = "SELECT type, COUNT(*) as count 
                   FROM notifications n 
                   JOIN users u ON n.user_id = u.id 
                   WHERE u.is_admin = 1 
                   GROUP BY type";
$stmt = $conn->prepare($type_stats_sql);
$stmt->execute();
$type_stats = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/unified.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/dark-mode.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="admin-layout">
        <?php include 'includes/sidebar.php'; ?>
        
        <main class="admin-main">
            <?php include 'includes/topbar.php'; ?>
            
            <div class="admin-content">
                <div class="content-header">
                    <h1><i class="fas fa-bell"></i> Kelola Notifikasi</h1>
                    <div class="header-actions">
                        <form method="POST" class="inline-form" onsubmit="return confirm('Hapus semua notifikasi?')">
                            <input type="hidden" name="action" value="delete_all">
                            <button type="submit" class="btn btn-danger btn-sm">
                                <i class="fas fa-trash"></i> Hapus Semua
                            </button>
                        </form>
                        <form method="POST" class="inline-form">
                            <input type="hidden" name="action" value="mark_all_read">
                            <button type="submit" class="btn btn-primary btn-sm">
                                <i class="fas fa-check"></i> Tandai Semua Dibaca
                            </button>
                        </form>
                    </div>
                </div>

                <?php $flash = getFlashMessage(); ?>
                <?php if ($flash): ?>
                    <div class="alert alert-<?php echo $flash['type']; ?>">
                        <?php echo $flash['message']; ?>
                    </div>
                <?php endif; ?>

                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-icon">
                            <i class="fas fa-bell"></i>
                        </div>
                        <div class="stat-content">
                            <div class="stat-number"><?php echo number_format($total); ?></div>
                            <div class="stat-label">Total Notifikasi</div>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon unread">
                            <i class="fas fa-envelope"></i>
                        </div>
                        <div class="stat-content">
                            <div class="stat-number"><?php echo number_format($unread_count); ?></div>
                            <div class="stat-label">Belum Dibaca</div>
                        </div>
                    </div>
                    <?php foreach ($type_stats as $stat): ?>
                        <div class="stat-card">
                            <div class="stat-icon">
                                <i class="fas fa-<?php echo getNotificationIcon($stat['type']); ?>"></i>
                            </div>
                            <div class="stat-content">
                                <div class="stat-number"><?php echo number_format($stat['count']); ?></div>
                                <div class="stat-label"><?php echo ucfirst($stat['type']); ?></div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3>Daftar Notifikasi</h3>
                        <div class="filters">
                            <form method="GET" class="filter-form">
                                <select name="type" onchange="this.form.submit()">
                                    <option value="">Semua Tipe</option>
                                    <option value="like" <?php echo $type_filter === 'like' ? 'selected' : ''; ?>>Like</option>
                                    <option value="comment" <?php echo $type_filter === 'comment' ? 'selected' : ''; ?>>Komentar</option>
                                    <option value="share" <?php echo $type_filter === 'share' ? 'selected' : ''; ?>>Share</option>
                                    <option value="message" <?php echo $type_filter === 'message' ? 'selected' : ''; ?>>Pesan</option>
                                    <option value="purchase" <?php echo $type_filter === 'purchase' ? 'selected' : ''; ?>>Pembelian</option>
                                    <option value="sale" <?php echo $type_filter === 'sale' ? 'selected' : ''; ?>>Penjualan</option>
                                    <option value="transaction" <?php echo $type_filter === 'transaction' ? 'selected' : ''; ?>>Transaksi</option>
                                    <option value="system" <?php echo $type_filter === 'system' ? 'selected' : ''; ?>>Sistem</option>
                                </select>
                                <select name="status" onchange="this.form.submit()">
                                    <option value="">Semua Status</option>
                                    <option value="read" <?php echo $status_filter === 'read' ? 'selected' : ''; ?>>Dibaca</option>
                                    <option value="unread" <?php echo $status_filter === 'unread' ? 'selected' : ''; ?>>Belum Dibaca</option>
                                </select>
                            </form>
                        </div>
                    </div>
                    <div class="card-content">
                        <?php if (empty($notifications)): ?>
                            <div class="empty-state">
                                <i class="fas fa-bell-slash"></i>
                                <h3>Tidak ada notifikasi</h3>
                                <p>Belum ada notifikasi yang tersedia</p>
                            </div>
                        <?php else: ?>
                            <div class="notifications-list">
                                <?php foreach ($notifications as $notif): ?>
                                    <div class="notification-item <?php echo $notif['is_read'] ? 'read' : 'unread'; ?>">
                                        <div class="notif-icon">
                                            <i class="fas fa-<?php echo getNotificationIcon($notif['type']); ?>"></i>
                                        </div>
                                        <div class="notif-content">
                                            <div class="notif-header">
                                                <h4><?php echo htmlspecialchars($notif['title']); ?></h4>
                                                <span class="notif-time"><?php echo timeAgo($notif['created_at']); ?></span>
                                            </div>
                                            <p><?php echo htmlspecialchars($notif['message']); ?></p>
                                            <div class="notif-meta">
                                                <span class="notif-type"><?php echo ucfirst($notif['type']); ?></span>
                                                <span class="notif-user">Oleh: <?php echo htmlspecialchars($notif['full_name']); ?></span>
                                            </div>
                                            <?php if ($notif['link']): ?>
                                                <div class="notif-action">
                                                    <a href="<?php echo htmlspecialchars($notif['link']); ?>" class="btn btn-sm btn-outline">
                                                        <i class="fas fa-external-link-alt"></i> Lihat
                                                    </a>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="notif-actions">
                                            <?php if (!$notif['is_read']): ?>
                                                <form method="POST" action="api/mark-notification-read.php" class="inline-form">
                                                    <input type="hidden" name="notification_id" value="<?php echo $notif['id']; ?>">
                                                    <button type="submit" class="btn btn-sm btn-outline" title="Tandai dibaca">
                                                        <i class="fas fa-check"></i>
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                            <form method="POST" action="api/delete-notification.php" class="inline-form" onsubmit="return confirm('Hapus notifikasi ini?')">
                                                <input type="hidden" name="notification_id" value="<?php echo $notif['id']; ?>">
                                                <button type="submit" class="btn btn-sm btn-danger" title="Hapus">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <?php if ($total_pages > 1): ?>
                                <div class="pagination">
                                    <?php
                                    $current_url = $_SERVER['REQUEST_URI'];
                                    $url_parts = parse_url($current_url);
                                    parse_str($url_parts['query'] ?? '', $query_params);
                                    unset($query_params['page']);
                                    $base_url = $url_parts['path'] . '?' . http_build_query($query_params);
                                    ?>
                                    
                                    <?php if ($page > 1): ?>
                                        <a href="<?php echo $base_url . '&page=' . ($page - 1); ?>" class="page-link">
                                            <i class="fas fa-chevron-left"></i>
                                        </a>
                                    <?php endif; ?>
                                    
                                    <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                                        <a href="<?php echo $base_url . '&page=' . $i; ?>" class="page-link <?php echo $i === $page ? 'active' : ''; ?>">
                                            <?php echo $i; ?>
                                        </a>
                                    <?php endfor; ?>
                                    
                                    <?php if ($page < $total_pages): ?>
                                        <a href="<?php echo $base_url . '&page=' . ($page + 1); ?>" class="page-link">
                                            <i class="fas fa-chevron-right"></i>
                                        </a>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script src="../assets/js/main.js"></script>
    <script src="../assets/js/admin.js"></script>
    <script src="../assets/js/dark-mode.js"></script>
</body>
</html>

<?php
function getNotificationIcon($type) {
    $icons = [
        'like' => 'heart',
        'comment' => 'comment',
        'share' => 'share',
        'message' => 'envelope',
        'purchase' => 'shopping-cart',
        'sale' => 'money-bill',
        'transaction' => 'exchange-alt',
        'system' => 'cog'
    ];
    return $icons[$type] ?? 'bell';
}
?>