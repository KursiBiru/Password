<?php
require_once '../config.php';
requireLogin();
requireAdmin();

$user = getCurrentUser();
$conn = getDBConnection();

// Handle post actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        setFlashMessage('danger', 'Invalid CSRF token');
    } else {
        $action = $_POST['action'] ?? '';
        $postId = intval($_POST['post_id'] ?? 0);
        
        if ($postId > 0) {
            switch ($action) {
                case 'approve':
                    $stmt = $conn->prepare("UPDATE posts SET status = 'active' WHERE id = ?");
                    if ($stmt->execute([$postId])) {
                        setFlashMessage('success', 'Post berhasil disetujui');
                    }
                    break;
                    
                case 'reject':
                    $stmt = $conn->prepare("UPDATE posts SET status = 'deleted' WHERE id = ?");
                    if ($stmt->execute([$postId])) {
                        setFlashMessage('success', 'Post berhasil ditolak');
                    }
                    break;
                    
                case 'delete':
                    $stmt = $conn->prepare("UPDATE posts SET status = 'deleted' WHERE id = ?");
                    if ($stmt->execute([$postId])) {
                        setFlashMessage('success', 'Post berhasil dihapus');
                    }
                    break;
            }
        }
        redirect('posts.php');
    }
}

// Get filter parameters
$status = $_GET['status'] ?? 'all';
$type = $_GET['type'] ?? 'all';
$search = $_GET['search'] ?? '';
$page = max(1, intval($_GET['page'] ?? 1));
$perPage = 20;
$offset = ($page - 1) * $perPage;

// Build query
$sql = "SELECT p.*, u.username, u.full_name, u.profile_photo,
        (SELECT COUNT(*) FROM likes WHERE post_id = p.id) as like_count,
        (SELECT COUNT(*) FROM comments WHERE post_id = p.id) as comment_count,
        (SELECT COUNT(*) FROM purchases WHERE post_id = p.id) as purchase_count
        FROM posts p
        JOIN users u ON p.user_id = u.id
        WHERE 1=1";

$params = [];

if ($status !== 'all') {
    $sql .= " AND p.status = ?";
    $params[] = $status;
}

if ($type !== 'all') {
    $sql .= " AND p.post_type = ?";
    $params[] = $type;
}

if (!empty($search)) {
    $sql .= " AND (p.title LIKE ? OR p.content LIKE ? OR u.username LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

$sql .= " ORDER BY p.created_at DESC LIMIT ? OFFSET ?";
$params[] = $perPage;
$params[] = $offset;

$stmt = $conn->prepare($sql);
$stmt->execute($params);
$posts = $stmt->fetchAll();

// Get total count
$countSql = "SELECT COUNT(*) as total FROM posts p JOIN users u ON p.user_id = u.id WHERE 1=1";
$countParams = [];

if ($status !== 'all') {
    $countSql .= " AND p.status = ?";
    $countParams[] = $status;
}

if ($type !== 'all') {
    $countSql .= " AND p.post_type = ?";
    $countParams[] = $type;
}

if (!empty($search)) {
    $countSql .= " AND (p.title LIKE ? OR p.content LIKE ? OR u.username LIKE ?)";
    $countParams[] = "%$search%";
    $countParams[] = "%$search%";
    $countParams[] = "%$search%";
}

$stmt = $conn->prepare($countSql);
$stmt->execute($countParams);
$totalPosts = $stmt->fetch()['total'];
$totalPages = ceil($totalPosts / $perPage);

// Get statistics
$stmt = $conn->query("
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active,
        SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
        SUM(CASE WHEN status = 'deleted' THEN 1 ELSE 0 END) as deleted,
        SUM(CASE WHEN post_type = 'community' THEN 1 ELSE 0 END) as community,
        SUM(CASE WHEN post_type = 'product' THEN 1 ELSE 0 END) as product
    FROM posts
");
$stats = $stmt->fetch();

$flashMessage = getFlashMessage();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Post - Admin</title>
    <link rel="stylesheet" href="../assets/css/unified.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/dark-mode.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .admin-container {
            display: flex;
            min-height: 100vh;
        }
        .admin-content {
            flex: 1;
            padding: 20px;
            background: #f8f9fa;
        }
        .page-header {
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .page-header h1 {
            margin: 0 0 10px 0;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .stat-card h3 {
            margin: 0 0 10px 0;
            font-size: 14px;
            color: #666;
        }
        .stat-card .stat-value {
            font-size: 32px;
            font-weight: bold;
            color: #333;
        }
        .filters {
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .filter-row {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        .filter-row input,
        .filter-row select {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .filter-row input[type="text"] {
            flex: 1;
            min-width: 200px;
        }
        .filter-row button {
            padding: 10px 20px;
            background: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .posts-table {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th {
            background: #f8f9fa;
            padding: 15px;
            text-align: left;
            font-weight: bold;
            border-bottom: 2px solid #dee2e6;
        }
        td {
            padding: 15px;
            border-bottom: 1px solid #dee2e6;
        }
        tr:hover {
            background: #f8f9fa;
        }
        .post-preview {
            display: flex;
            gap: 10px;
            align-items: center;
        }
        .post-thumbnail {
            width: 60px;
            height: 60px;
            object-fit: cover;
            border-radius: 5px;
        }
        .post-info {
            flex: 1;
        }
        .post-title {
            font-weight: bold;
            margin-bottom: 5px;
        }
        .post-meta {
            font-size: 12px;
            color: #666;
        }
        .badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 3px;
            font-size: 12px;
            font-weight: bold;
        }
        .badge-active {
            background: #d4edda;
            color: #155724;
        }
        .badge-pending {
            background: #fff3cd;
            color: #856404;
        }
        .badge-deleted {
            background: #f8d7da;
            color: #721c24;
        }
        .badge-community {
            background: #d1ecf1;
            color: #0c5460;
        }
        .badge-product {
            background: #d4edda;
            color: #155724;
        }
        .action-buttons {
            display: flex;
            gap: 5px;
        }
        .btn-sm {
            padding: 5px 10px;
            font-size: 12px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }
        .btn-success {
            background: #28a745;
            color: white;
        }
        .btn-danger {
            background: #dc3545;
            color: white;
        }
        .btn-info {
            background: #17a2b8;
            color: white;
        }
        .pagination {
            display: flex;
            justify-content: center;
            gap: 5px;
            margin-top: 20px;
        }
        .pagination a, .pagination span {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            text-decoration: none;
            color: #333;
        }
        .pagination .active {
            background: #007bff;
            color: white;
            border-color: #007bff;
        }
    </style>
</head>
<body>
    <?php include 'includes/sidebar.php'; ?>
    
    <div class="admin-main">
        <?php include 'includes/topbar.php'; ?>
        
        <div class="admin-content">
            
            <?php if ($flashMessage): ?>
                <div class="alert alert-<?php echo $flashMessage['type']; ?>">
                    <?php echo $flashMessage['message']; ?>
                </div>
            <?php endif; ?>
            
            <div class="page-header">
                <h1>Manajemen Post</h1>
                <p>Kelola semua postingan di platform</p>
            </div>
            
            <div class="stats-grid">
                <div class="stat-card">
                    <h3>Total Post</h3>
                    <div class="stat-value"><?php echo number_format($stats['total']); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Post Aktif</h3>
                    <div class="stat-value" style="color: #28a745;"><?php echo number_format($stats['active']); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Post Pending</h3>
                    <div class="stat-value" style="color: #ffc107;"><?php echo number_format($stats['pending']); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Post Komunitas</h3>
                    <div class="stat-value" style="color: #17a2b8;"><?php echo number_format($stats['community']); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Post Produk</h3>
                    <div class="stat-value" style="color: #28a745;"><?php echo number_format($stats['product']); ?></div>
                </div>
            </div>
            
            <div class="filters">
                <form method="GET" class="filter-row">
                    <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Cari post...">
                    
                    <select name="status">
                        <option value="all" <?php echo $status === 'all' ? 'selected' : ''; ?>>Semua Status</option>
                        <option value="active" <?php echo $status === 'active' ? 'selected' : ''; ?>>Aktif</option>
                        <option value="pending" <?php echo $status === 'pending' ? 'selected' : ''; ?>>Pending</option>
                        <option value="deleted" <?php echo $status === 'deleted' ? 'selected' : ''; ?>>Dihapus</option>
                    </select>
                    
                    <select name="type">
                        <option value="all" <?php echo $type === 'all' ? 'selected' : ''; ?>>Semua Tipe</option>
                        <option value="community" <?php echo $type === 'community' ? 'selected' : ''; ?>>Komunitas</option>
                        <option value="product" <?php echo $type === 'product' ? 'selected' : ''; ?>>Produk</option>
                    </select>
                    
                    <button type="submit"><i class="fas fa-search"></i> Filter</button>
                </form>
            </div>
            
            <div class="posts-table">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Post</th>
                            <th>Penulis</th>
                            <th>Tipe</th>
                            <th>Status</th>
                            <th>Statistik</th>
                            <th>Tanggal</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($posts as $post): ?>
                            <tr>
                                <td><?php echo $post['id']; ?></td>
                                <td>
                                    <div class="post-preview">
                                        <?php 
                                        $images = !empty($post['images']) ? json_decode($post['images'], true) : [];
                                        $thumbnail = !empty($images) ? $images[0] : 'default-post.png';
                                        ?>
                                        <img src="../uploads/posts/<?php echo htmlspecialchars($thumbnail); ?>" alt="Thumbnail" class="post-thumbnail">
                                        <div class="post-info">
                                            <div class="post-title"><?php echo htmlspecialchars(substr($post['title'], 0, 50)); ?></div>
                                            <div class="post-meta"><?php echo htmlspecialchars(substr($post['content'], 0, 80)); ?>...</div>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <a href="../profile.php?id=<?php echo $post['user_id']; ?>" target="_blank">
                                        <?php echo htmlspecialchars($post['full_name']); ?>
                                    </a>
                                    <div style="font-size: 12px; color: #666;">@<?php echo htmlspecialchars($post['username']); ?></div>
                                </td>
                                <td>
                                    <span class="badge badge-<?php echo $post['post_type']; ?>">
                                        <?php echo $post['post_type'] === 'community' ? 'Komunitas' : 'Produk'; ?>
                                    </span>
                                    <?php if ($post['post_type'] === 'product'): ?>
                                        <div style="font-size: 12px; margin-top: 5px;">
                                            Rp <?php echo number_format($post['product_price'], 0, ',', '.'); ?>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="badge badge-<?php echo $post['status']; ?>">
                                        <?php 
                                        $statusLabels = [
                                            'active' => 'Aktif',
                                            'pending' => 'Pending',
                                            'deleted' => 'Dihapus'
                                        ];
                                        echo $statusLabels[$post['status']] ?? $post['status'];
                                        ?>
                                    </span>
                                </td>
                                <td>
                                    <div style="font-size: 12px;">
                                        <i class="fas fa-heart"></i> <?php echo $post['like_count']; ?><br>
                                        <i class="fas fa-comment"></i> <?php echo $post['comment_count']; ?><br>
                                        <?php if ($post['post_type'] === 'product'): ?>
                                            <i class="fas fa-shopping-cart"></i> <?php echo $post['purchase_count']; ?>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td style="font-size: 12px;">
                                    <?php echo date('d/m/Y H:i', strtotime($post['created_at'])); ?>
                                </td>
                                <td>
                                    <div class="action-buttons">
                                        <a href="../post-detail.php?id=<?php echo $post['id']; ?>" target="_blank" class="btn-sm btn-info" title="Lihat">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        
                                        <?php if ($post['status'] === 'pending'): ?>
                                            <form method="POST" style="display: inline;">
                                                <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                                                <input type="hidden" name="post_id" value="<?php echo $post['id']; ?>">
                                                <input type="hidden" name="action" value="approve">
                                                <button type="submit" class="btn-sm btn-success" title="Setujui">
                                                    <i class="fas fa-check"></i>
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                        
                                        <?php if ($post['status'] !== 'deleted'): ?>
                                            <form method="POST" style="display: inline;" onsubmit="return confirm('Yakin ingin menghapus post ini?')">
                                                <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                                                <input type="hidden" name="post_id" value="<?php echo $post['id']; ?>">
                                                <input type="hidden" name="action" value="delete">
                                                <button type="submit" class="btn-sm btn-danger" title="Hapus">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                
                <?php if ($totalPages > 1): ?>
                    <div class="pagination">
                        <?php if ($page > 1): ?>
                            <a href="?status=<?php echo $status; ?>&type=<?php echo $type; ?>&search=<?php echo urlencode($search); ?>&page=<?php echo $page - 1; ?>">
                                <i class="fas fa-chevron-left"></i>
                            </a>
                        <?php endif; ?>
                        
                        <?php for ($i = max(1, $page - 2); $i <= min($totalPages, $page + 2); $i++): ?>
                            <?php if ($i === $page): ?>
                                <span class="active"><?php echo $i; ?></span>
                            <?php else: ?>
                                <a href="?status=<?php echo $status; ?>&type=<?php echo $type; ?>&search=<?php echo urlencode($search); ?>&page=<?php echo $i; ?>">
                                    <?php echo $i; ?>
                                </a>
                            <?php endif; ?>
                        <?php endfor; ?>
                        
                        <?php if ($page < $totalPages): ?>
                            <a href="?status=<?php echo $status; ?>&type=<?php echo $type; ?>&search=<?php echo urlencode($search); ?>&page=<?php echo $page + 1; ?>">
                                <i class="fas fa-chevron-right"></i>
                            </a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <script src="../assets/js/main.js"></script>
    <script src="../assets/js/admin.js"></script>
    <script src="../assets/js/dark-mode.js"></script>
</body>
</html>