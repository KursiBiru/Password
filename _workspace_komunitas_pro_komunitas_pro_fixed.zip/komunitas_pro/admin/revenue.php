<?php
require_once '../config.php';
requireLogin();
requireAdmin();

$user = getCurrentUser();
$conn = getDBConnection();

// Get filter parameters
$period = $_GET['period'] ?? 'month'; // day, week, month, year, custom
$startDate = $_GET['start_date'] ?? date('Y-m-01');
$endDate = $_GET['end_date'] ?? date('Y-m-d');

// Set date range based on period
switch ($period) {
    case 'day':
        $startDate = date('Y-m-d');
        $endDate = date('Y-m-d');
        break;
    case 'week':
        $startDate = date('Y-m-d', strtotime('-7 days'));
        $endDate = date('Y-m-d');
        break;
    case 'month':
        $startDate = date('Y-m-01');
        $endDate = date('Y-m-d');
        break;
    case 'year':
        $startDate = date('Y-01-01');
        $endDate = date('Y-m-d');
        break;
}

// Get revenue statistics
$stmt = $conn->prepare("
    SELECT 
        COUNT(*) as total_transactions,
        SUM(CASE WHEN transaction_type = 'purchase' THEN amount ELSE 0 END) as total_purchases,
        SUM(CASE WHEN transaction_type = 'sale' THEN amount ELSE 0 END) as total_sales,
        SUM(CASE WHEN transaction_type = 'deposit' THEN amount ELSE 0 END) as total_deposits,
        SUM(CASE WHEN transaction_type = 'withdrawal' THEN amount ELSE 0 END) as total_withdrawals,
        SUM(fee) as total_fees
    FROM transactions
    WHERE status = 'completed'
    AND DATE(created_at) BETWEEN ? AND ?
");
$stmt->execute([$startDate, $endDate]);
$stats = $stmt->fetch();

// Get daily revenue chart data
$stmt = $conn->prepare("
    SELECT 
        DATE(created_at) as date,
        SUM(CASE WHEN transaction_type IN ('purchase', 'sale') THEN amount ELSE 0 END) as revenue,
        SUM(fee) as fees,
        COUNT(*) as transactions
    FROM transactions
    WHERE status = 'completed'
    AND DATE(created_at) BETWEEN ? AND ?
    GROUP BY DATE(created_at)
    ORDER BY date ASC
");
$stmt->execute([$startDate, $endDate]);
$chartData = $stmt->fetchAll();

// Get top selling products
$stmt = $conn->prepare("
    SELECT 
        p.id,
        p.title,
        p.product_price,
        u.full_name as seller_name,
        COUNT(pu.id) as sales_count,
        SUM(pu.amount) as total_revenue
    FROM posts p
    JOIN users u ON p.user_id = u.id
    JOIN purchases pu ON p.id = pu.post_id
    WHERE pu.status = 'completed'
    AND DATE(pu.created_at) BETWEEN ? AND ?
    GROUP BY p.id
    ORDER BY sales_count DESC
    LIMIT 10
");
$stmt->execute([$startDate, $endDate]);
$topProducts = $stmt->fetchAll();

// Get top sellers
$stmt = $conn->prepare("
    SELECT 
        u.id,
        u.username,
        u.full_name,
        u.profile_photo,
        COUNT(pu.id) as sales_count,
        SUM(pu.amount) as total_revenue
    FROM users u
    JOIN purchases pu ON u.id = pu.seller_id
    WHERE pu.status = 'completed'
    AND DATE(pu.created_at) BETWEEN ? AND ?
    GROUP BY u.id
    ORDER BY total_revenue DESC
    LIMIT 10
");
$stmt->execute([$startDate, $endDate]);
$topSellers = $stmt->fetchAll();

// Get recent transactions
$stmt = $conn->prepare("
    SELECT 
        t.*,
        u.username,
        u.full_name,
        p.title as post_title
    FROM transactions t
    JOIN users u ON t.user_id = u.id
    LEFT JOIN posts p ON t.related_post_id = p.id
    WHERE DATE(t.created_at) BETWEEN ? AND ?
    ORDER BY t.created_at DESC
    LIMIT 20
");
$stmt->execute([$startDate, $endDate]);
$recentTransactions = $stmt->fetchAll();

$flashMessage = getFlashMessage();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Pendapatan - Admin</title>
    <link rel="stylesheet" href="../assets/css/unified.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/dark-mode.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .admin-container {
            display: flex;
            min-height: 100vh;
        }
        .admin-content {
            flex: 1;
            padding: 20px;
            background: #f8f9fa;
        }
        .page-header {
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .page-header h1 {
            margin: 0 0 10px 0;
        }
        .filters {
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .filter-row {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            align-items: center;
        }
        .filter-row select,
        .filter-row input {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .filter-row button {
            padding: 10px 20px;
            background: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .stat-card h3 {
            margin: 0 0 10px 0;
            font-size: 14px;
            color: #666;
        }
        .stat-card .stat-value {
            font-size: 28px;
            font-weight: bold;
            color: #333;
        }
        .stat-card .stat-change {
            font-size: 12px;
            margin-top: 5px;
        }
        .stat-card .stat-change.positive {
            color: #28a745;
        }
        .stat-card .stat-change.negative {
            color: #dc3545;
        }
        .chart-container {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .chart-container h2 {
            margin: 0 0 20px 0;
        }
        .two-columns {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 20px;
        }
        .data-table {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .data-table h2 {
            margin: 0 0 20px 0;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th {
            background: #f8f9fa;
            padding: 12px;
            text-align: left;
            font-weight: bold;
            border-bottom: 2px solid #dee2e6;
        }
        td {
            padding: 12px;
            border-bottom: 1px solid #dee2e6;
        }
        tr:hover {
            background: #f8f9fa;
        }
        .badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 3px;
            font-size: 12px;
            font-weight: bold;
        }
        .badge-success {
            background: #d4edda;
            color: #155724;
        }
        .badge-warning {
            background: #fff3cd;
            color: #856404;
        }
        .badge-danger {
            background: #f8d7da;
            color: #721c24;
        }
        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .user-avatar {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            object-fit: cover;
        }
        @media (max-width: 768px) {
            .two-columns {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <?php include 'includes/sidebar.php'; ?>
    
    <div class="admin-main">
        <?php include 'includes/topbar.php'; ?>
        
        <div class="admin-content">
            
            <?php if ($flashMessage): ?>
                <div class="alert alert-<?php echo $flashMessage['type']; ?>">
                    <?php echo $flashMessage['message']; ?>
                </div>
            <?php endif; ?>
            
            <div class="page-header">
                <h1>Laporan Pendapatan</h1>
                <p>Analisis pendapatan dan transaksi platform</p>
            </div>
            
            <div class="filters">
                <form method="GET" class="filter-row">
                    <label>Periode:</label>
                    <select name="period" onchange="toggleCustomDate(this.value)">
                        <option value="day" <?php echo $period === 'day' ? 'selected' : ''; ?>>Hari Ini</option>
                        <option value="week" <?php echo $period === 'week' ? 'selected' : ''; ?>>7 Hari Terakhir</option>
                        <option value="month" <?php echo $period === 'month' ? 'selected' : ''; ?>>Bulan Ini</option>
                        <option value="year" <?php echo $period === 'year' ? 'selected' : ''; ?>>Tahun Ini</option>
                        <option value="custom" <?php echo $period === 'custom' ? 'selected' : ''; ?>>Custom</option>
                    </select>
                    
                    <div id="customDateRange" style="display: <?php echo $period === 'custom' ? 'flex' : 'none'; ?>; gap: 10px;">
                        <input type="date" name="start_date" value="<?php echo $startDate; ?>">
                        <input type="date" name="end_date" value="<?php echo $endDate; ?>">
                    </div>
                    
                    <button type="submit"><i class="fas fa-filter"></i> Filter</button>
                    <button type="button" onclick="window.print()" style="background: #28a745;">
                        <i class="fas fa-print"></i> Print
                    </button>
                </form>
            </div>
            
            <div class="stats-grid">
                <div class="stat-card">
                    <h3>Total Transaksi</h3>
                    <div class="stat-value"><?php echo number_format($stats['total_transactions']); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Total Pembelian</h3>
                    <div class="stat-value" style="color: #dc3545;">
                        Rp <?php echo number_format($stats['total_purchases'], 0, ',', '.'); ?>
                    </div>
                </div>
                <div class="stat-card">
                    <h3>Total Penjualan</h3>
                    <div class="stat-value" style="color: #28a745;">
                        Rp <?php echo number_format($stats['total_sales'], 0, ',', '.'); ?>
                    </div>
                </div>
                <div class="stat-card">
                    <h3>Total Deposit</h3>
                    <div class="stat-value" style="color: #007bff;">
                        Rp <?php echo number_format($stats['total_deposits'], 0, ',', '.'); ?>
                    </div>
                </div>
                <div class="stat-card">
                    <h3>Total Withdrawal</h3>
                    <div class="stat-value" style="color: #ffc107;">
                        Rp <?php echo number_format($stats['total_withdrawals'], 0, ',', '.'); ?>
                    </div>
                </div>
                <div class="stat-card">
                    <h3>Total Fee</h3>
                    <div class="stat-value" style="color: #17a2b8;">
                        Rp <?php echo number_format($stats['total_fees'], 0, ',', '.'); ?>
                    </div>
                </div>
            </div>
            
            <div class="chart-container">
                <h2>Grafik Pendapatan</h2>
                <canvas id="revenueChart"></canvas>
            </div>
            
            <div class="two-columns">
                <div class="data-table">
                    <h2>Top 10 Produk Terlaris</h2>
                    <table>
                        <thead>
                            <tr>
                                <th>Produk</th>
                                <th>Penjual</th>
                                <th>Terjual</th>
                                <th>Revenue</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($topProducts as $product): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($product['title']); ?></td>
                                    <td><?php echo htmlspecialchars($product['seller_name']); ?></td>
                                    <td><?php echo $product['sales_count']; ?>x</td>
                                    <td>Rp <?php echo number_format($product['total_revenue'], 0, ',', '.'); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <div class="data-table">
                    <h2>Top 10 Penjual</h2>
                    <table>
                        <thead>
                            <tr>
                                <th>Penjual</th>
                                <th>Penjualan</th>
                                <th>Revenue</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($topSellers as $seller): ?>
                                <tr>
                                    <td>
                                        <div class="user-info">
                                            <img src="../uploads/profiles/<?php echo htmlspecialchars($seller['profile_photo']); ?>" alt="Avatar" class="user-avatar">
                                            <div>
                                                <div><?php echo htmlspecialchars($seller['full_name']); ?></div>
                                                <div style="font-size: 12px; color: #666;">@<?php echo htmlspecialchars($seller['username']); ?></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td><?php echo $seller['sales_count']; ?>x</td>
                                    <td>Rp <?php echo number_format($seller['total_revenue'], 0, ',', '.'); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="data-table">
                <h2>Transaksi Terbaru</h2>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>User</th>
                            <th>Tipe</th>
                            <th>Jumlah</th>
                            <th>Fee</th>
                            <th>Status</th>
                            <th>Tanggal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recentTransactions as $transaction): ?>
                            <tr>
                                <td>#<?php echo $transaction['id']; ?></td>
                                <td>
                                    <div><?php echo htmlspecialchars($transaction['full_name']); ?></div>
                                    <div style="font-size: 12px; color: #666;">@<?php echo htmlspecialchars($transaction['username']); ?></div>
                                </td>
                                <td>
                                    <?php 
                                    $typeLabels = [
                                        'deposit' => 'Deposit',
                                        'withdrawal' => 'Withdrawal',
                                        'purchase' => 'Pembelian',
                                        'sale' => 'Penjualan',
                                        'refund' => 'Refund'
                                    ];
                                    echo $typeLabels[$transaction['transaction_type']] ?? $transaction['transaction_type'];
                                    ?>
                                    <?php if (!empty($transaction['post_title'])): ?>
                                        <div style="font-size: 12px; color: #666;"><?php echo htmlspecialchars(substr($transaction['post_title'], 0, 30)); ?></div>
                                    <?php endif; ?>
                                </td>
                                <td>Rp <?php echo number_format($transaction['amount'], 0, ',', '.'); ?></td>
                                <td>Rp <?php echo number_format($transaction['fee'], 0, ',', '.'); ?></td>
                                <td>
                                    <?php
                                    $statusClass = [
                                        'completed' => 'success',
                                        'pending' => 'warning',
                                        'rejected' => 'danger',
                                        'cancelled' => 'danger'
                                    ];
                                    $statusLabel = [
                                        'completed' => 'Selesai',
                                        'pending' => 'Pending',
                                        'rejected' => 'Ditolak',
                                        'cancelled' => 'Dibatalkan'
                                    ];
                                    ?>
                                    <span class="badge badge-<?php echo $statusClass[$transaction['status']] ?? 'secondary'; ?>">
                                        <?php echo $statusLabel[$transaction['status']] ?? $transaction['status']; ?>
                                    </span>
                                </td>
                                <td style="font-size: 12px;">
                                    <?php echo date('d/m/Y H:i', strtotime($transaction['created_at'])); ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <script>
        function toggleCustomDate(value) {
            document.getElementById('customDateRange').style.display = value === 'custom' ? 'flex' : 'none';
        }
        
        // Revenue Chart
        const ctx = document.getElementById('revenueChart').getContext('2d');
        const chartData = <?php echo json_encode($chartData); ?>;
        
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: chartData.map(d => d.date),
                datasets: [{
                    label: 'Revenue',
                    data: chartData.map(d => d.revenue),
                    borderColor: '#28a745',
                    backgroundColor: 'rgba(40, 167, 69, 0.1)',
                    tension: 0.4
                }, {
                    label: 'Fees',
                    data: chartData.map(d => d.fees),
                    borderColor: '#17a2b8',
                    backgroundColor: 'rgba(23, 162, 184, 0.1)',
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    title: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return 'Rp ' + value.toLocaleString('id-ID');
                            }
                        }
                    }
                }
            }
        });
    </script>
    <script src="../assets/js/main.js"></script>
    <script src="../assets/js/admin.js"></script>
    <script src="../assets/js/dark-mode.js"></script>
</body>
</html>