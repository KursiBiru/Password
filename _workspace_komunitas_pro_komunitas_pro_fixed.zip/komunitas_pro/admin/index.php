<?php
require_once '../config.php';
requireAdmin();

$user = getCurrentUser();
$conn = getDBConnection();

// Get statistics
$stats = [];

// Total users
$stmt = $conn->query("SELECT COUNT(*) as count FROM users WHERE is_admin = 0");
$stats['total_users'] = $stmt->fetch()['count'];

// Total posts
$stmt = $conn->query("SELECT COUNT(*) as count FROM posts WHERE status = 'active'");
$stats['total_posts'] = $stmt->fetch()['count'];

// Total transactions
$stmt = $conn->query("SELECT COUNT(*) as count FROM transactions WHERE status = 'completed'");
$stats['total_transactions'] = $stmt->fetch()['count'];

// Total revenue
$stmt = $conn->query("SELECT SUM(fee) as total FROM transactions WHERE status = 'completed'");
$stats['total_revenue'] = $stmt->fetch()['total'] ?? 0;

// Pending deposits
$stmt = $conn->query("SELECT COUNT(*) as count FROM transactions WHERE transaction_type = 'deposit' AND status = 'pending'");
$stats['pending_deposits'] = $stmt->fetch()['count'];

// Recent users
$stmt = $conn->query("SELECT * FROM users WHERE is_admin = 0 ORDER BY created_at DESC LIMIT 5");
$recent_users = $stmt->fetchAll();

// Recent transactions
$stmt = $conn->query("SELECT t.*, u.username, u.full_name FROM transactions t JOIN users u ON t.user_id = u.id ORDER BY t.created_at DESC LIMIT 10");
$recent_transactions = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/unified.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/dark-mode.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include 'includes/sidebar.php'; ?>
    
    <div class="admin-main">
        <?php include 'includes/topbar.php'; ?>
        
        <div class="admin-content">
            <div class="page-header">
                <h1>Dashboard</h1>
                <p>Selamat datang di Admin Panel</p>
            </div>
            
            <!-- Statistics Cards -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon" style="background: #3498db;">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="stat-details">
                        <span class="stat-label">Total Pengguna</span>
                        <span class="stat-value"><?php echo number_format($stats['total_users']); ?></span>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon" style="background: #2ecc71;">
                        <i class="fas fa-file-alt"></i>
                    </div>
                    <div class="stat-details">
                        <span class="stat-label">Total Postingan</span>
                        <span class="stat-value"><?php echo number_format($stats['total_posts']); ?></span>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon" style="background: #f39c12;">
                        <i class="fas fa-exchange-alt"></i>
                    </div>
                    <div class="stat-details">
                        <span class="stat-label">Total Transaksi</span>
                        <span class="stat-value"><?php echo number_format($stats['total_transactions']); ?></span>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon" style="background: #e74c3c;">
                        <i class="fas fa-dollar-sign"></i>
                    </div>
                    <div class="stat-details">
                        <span class="stat-label">Total Pendapatan</span>
                        <span class="stat-value"><?php echo formatCurrency($stats['total_revenue']); ?></span>
                    </div>
                </div>
            </div>
            
            <!-- Pending Actions -->
            <?php if ($stats['pending_deposits'] > 0): ?>
            <div class="alert alert-warning">
                <i class="fas fa-exclamation-triangle"></i>
                Ada <strong><?php echo $stats['pending_deposits']; ?></strong> deposit yang menunggu konfirmasi.
                <a href="transactions.php?status=pending" class="btn btn-sm btn-primary" style="margin-left: 15px;">Lihat Sekarang</a>
            </div>
            <?php endif; ?>
            
            <div class="dashboard-grid">
                <!-- Recent Users -->
                <div class="dashboard-card">
                    <div class="card-header">
                        <h3>Pengguna Terbaru</h3>
                        <a href="users.php" class="btn btn-sm">Lihat Semua</a>
                    </div>
                    <div class="card-body">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Pengguna</th>
                                    <th>Email</th>
                                    <th>Bergabung</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recent_users as $u): ?>
                                <tr>
                                    <td>
                                        <div style="display: flex; align-items: center; gap: 10px;">
                                            <img src="../uploads/profiles/<?php echo htmlspecialchars($u['profile_photo']); ?>" 
                                                 alt="Profile" style="width: 32px; height: 32px; border-radius: 50%;">
                                            <div>
                                                <strong><?php echo htmlspecialchars($u['full_name']); ?></strong><br>
                                                <small>@<?php echo htmlspecialchars($u['username']); ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <td><?php echo htmlspecialchars($u['email']); ?></td>
                                    <td><?php echo date('d M Y', strtotime($u['created_at'])); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                
                <!-- Recent Transactions -->
                <div class="dashboard-card">
                    <div class="card-header">
                        <h3>Transaksi Terbaru</h3>
                        <a href="transactions.php" class="btn btn-sm">Lihat Semua</a>
                    </div>
                    <div class="card-body">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Pengguna</th>
                                    <th>Tipe</th>
                                    <th>Jumlah</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recent_transactions as $t): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($t['full_name']); ?></td>
                                    <td><?php echo ucfirst($t['transaction_type']); ?></td>
                                    <td><?php echo formatCurrency($t['amount']); ?></td>
                                    <td>
                                        <span class="status status-<?php echo $t['status']; ?>">
                                            <?php echo ucfirst($t['status']); ?>
                                        </span>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="../assets/js/main.js"></script>
    <script src="../assets/js/admin.js"></script>
    <script src="../assets/js/dark-mode.js"></script>
</body>
</html>