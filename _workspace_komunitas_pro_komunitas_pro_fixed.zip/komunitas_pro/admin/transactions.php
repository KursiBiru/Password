<?php
require_once '../config.php';
requireAdmin();

$user = getCurrentUser();
$conn = getDBConnection();

// Get all transactions
$stmt = $conn->prepare("
    SELECT t.*, u.username 
    FROM transactions t 
    JOIN users u ON t.user_id = u.id 
    ORDER BY t.created_at DESC 
    LIMIT 100
");
$stmt->execute();
$transactions = $stmt->fetchAll();

// Get all purchases for sellers
$stmt = $conn->prepare("
    SELECT p.*, po.title as product_title, u.username as buyer_name, s.username as seller_name 
    FROM purchases p 
    JOIN posts po ON p.post_id = po.id 
    JOIN users u ON p.buyer_id = u.id 
    JOIN users s ON p.seller_id = s.id 
    ORDER BY p.created_at DESC 
    LIMIT 50
");
$stmt->execute();
$purchases = $stmt->fetchAll();

$page_title = 'Kelola Transaksi';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/unified.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="admin-container">
    <?php include 'includes/sidebar.php'; ?>
    
    <div class="admin-main">
        <?php include 'includes/topbar.php'; ?>
        
        <div class="admin-content">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1>Transaksi & Penjualan</h1>
                <div>
                    <span class="badge bg-primary">Total: <?php echo count($transactions); ?> transaksi</span>
                    <span class="badge bg-success ms-2">Penjualan: <?php echo count($purchases); ?></span>
                </div>
            </div>

            <!-- Purchase/Sales Section -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">
                        <i class="fas fa-shopping-cart"></i> Penjualan Produk
                    </h5>
                </div>
                <div class="card-body">
                    <?php if (empty($purchases)): ?>
                        <div class="text-center py-4">
                            <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                            <p class="text-muted">Belum ada penjualan</p>
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Produk</th>
                                        <th>Pembeli</th>
                                        <th>Penjual</th>
                                        <th>Jumlah</th>
                                        <th>Status</th>
                                        <th>Tanggal</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($purchases as $purchase): ?>
                                        <tr>
                                            <td>#<?php echo $purchase['id']; ?></td>
                                            <td>
                                                <strong><?php echo htmlspecialchars($purchase['product_title']); ?></strong>
                                            </td>
                                            <td><?php echo htmlspecialchars($purchase['buyer_name']); ?></td>
                                            <td><?php echo htmlspecialchars($purchase['seller_name']); ?></td>
                                            <td class="text-success fw-bold">
                                                Rp <?php echo number_format($purchase['amount'], 0, ',', '.'); ?>
                                            </td>
                                            <td>
                                                <span class="status-badge status-<?php echo $purchase['confirmation_status']; ?>">
                                                    <?php 
                                                    $status_labels = [
                                                        'pending' => 'Menunggu Konfirmasi',
                                                        'buyer_confirmed' => 'Menunggu Penjual',
                                                        'seller_confirmed' => 'Menunggu Admin',
                                                        'admin_confirmed' => 'Selesai',
                                                        'completed' => 'Selesai'
                                                    ];
                                                    echo $status_labels[$purchase['confirmation_status']] ?? $purchase['confirmation_status'];
                                                    ?>
                                                </span>
                                            </td>
                                            <td><?php echo date('d M Y H:i', strtotime($purchase['created_at'])); ?></td>
                                            <td>
                                                <?php if ($purchase['confirmation_status'] === 'buyer_confirmed'): ?>
                                                    <a href="../seller-confirm-purchase.php?id=<?php echo $purchase['id']; ?>" 
                                                       class="btn btn-success btn-sm"
                                                       title="Konfirmasi sebagai penjual">
                                                        <i class="fas fa-check"></i> Konfirmasi
                                                    </a>
                                                <?php elseif ($purchase['confirmation_status'] === 'seller_confirmed'): ?>
                                                    <button class="btn btn-warning btn-sm" disabled>
                                                        <i class="fas fa-clock"></i> Menunggu Admin
                                                    </button>
                                                <?php elseif ($purchase['confirmation_status'] === 'pending'): ?>
                                                    <button class="btn btn-secondary btn-sm" disabled>
                                                        <i class="fas fa-hourglass-half"></i> Menunggu Pembeli
                                                    </button>
                                                <?php else: ?>
                                                    <span class="text-success">
                                                        <i class="fas fa-check-circle"></i> Selesai
                                                    </span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Wallet Transactions Section -->
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">
                        <i class="fas fa-wallet"></i> Transaksi Dompet
                    </h5>
                </div>
                <div class="card-body">
                    <?php if (empty($transactions)): ?>
                        <div class="text-center py-4">
                            <i class="fas fa-receipt fa-3x text-muted mb-3"></i>
                            <p class="text-muted">Belum ada transaksi</p>
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>User</th>
                                        <th>Tipe</th>
                                        <th>Jumlah</th>
                                        <th>Metode</th>
                                        <th>Status</th>
                                        <th>Tanggal</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($transactions as $transaction): ?>
                                        <tr>
                                            <td>#<?php echo $transaction['id']; ?></td>
                                            <td><?php echo htmlspecialchars($transaction['username']); ?></td>
                                            <td>
                                                <span class="badge bg-<?php 
                                                    echo $transaction['transaction_type'] === 'deposit' ? 'success' : 
                                                         ($transaction['transaction_type'] === 'withdrawal' ? 'danger' : 'primary'); 
                                                ?>">
                                                    <?php echo ucfirst($transaction['transaction_type']); ?>
                                                </span>
                                            </td>
                                            <td class="fw-bold">
                                                <?php 
                                                $prefix = '';
                                                $color = '';
                                                if ($transaction['transaction_type'] === 'deposit') {
                                                    $prefix = '+';
                                                    $color = 'text-success';
                                                } elseif ($transaction['transaction_type'] === 'withdrawal') {
                                                    $prefix = '-';
                                                    $color = 'text-danger';
                                                }
                                                ?>
                                                <span class="<?php echo $color; ?>">
                                                    <?php echo $prefix . formatCurrency($transaction['amount']); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <?php 
                                                if ($transaction['payment_method']) {
                                                    echo ucfirst($transaction['payment_method']);
                                                    if ($transaction['unique_code']) {
                                                        echo ' (Kode: ' . $transaction['unique_code'] . ')';
                                                    }
                                                } else {
                                                    echo '-';
                                                }
                                                ?>
                                            </td>
                                            <td>
                                                <span class="status-badge status-<?php echo $transaction['status']; ?>">
                                                    <?php echo ucfirst($transaction['status']); ?>
                                                </span>
                                            </td>
                                            <td><?php echo date('d M Y H:i', strtotime($transaction['created_at'])); ?></td>
                                            <td>
                                                <?php if ($transaction['status'] === 'pending'): ?>
                                                    <form method="POST" style="display: inline;">
                                                        <?php echo generateCSRFToken(); ?>
                                                        <input type="hidden" name="transaction_id" value="<?php echo $transaction['id']; ?>">
                                                        <?php if ($transaction['transaction_type'] === 'deposit'): ?>
                                                            <button type="submit" name="action" value="approve" 
                                                                    class="btn btn-success btn-sm"
                                                                    onclick="return confirm('Setujui deposit ini?')">
                                                                <i class="fas fa-check"></i> Setujui
                                                            </button>
                                                        <?php elseif ($transaction['transaction_type'] === 'withdrawal'): ?>
                                                            <button type="submit" name="action" value="approve" 
                                                                    class="btn btn-success btn-sm"
                                                                    onclick="return confirm('Proses penarikan ini?')">
                                                                <i class="fas fa-check"></i> Proses
                                                            </button>
                                                        <?php endif; ?>
                                                        <button type="submit" name="action" value="reject" 
                                                                class="btn btn-danger btn-sm ms-1"
                                                                onclick="return confirm('Tolak transaksi ini?')">
                                                            <i class="fas fa-times"></i> Tolak
                                                        </button>
                                                    </form>
                                                <?php else: ?>
                                                    <span class="text-muted">
                                                        <i class="fas fa-check-circle"></i> Selesai
                                                    </span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
<script src="../assets/js/main.js"></script>
</body>
</html>

<?php
// Handle transaction actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        setFlashMessage('danger', 'Invalid CSRF token');
    } else {
        $action = $_POST['action'];
        $transactionId = $_POST['transaction_id'];
        
        if ($action === 'approve') {
            $stmt = $conn->prepare("SELECT * FROM transactions WHERE id = ?");
            $stmt->execute([$transactionId]);
            $transaction = $stmt->fetch();
            
            if ($transaction && $transaction['status'] === 'pending') {
                if ($transaction['transaction_type'] === 'deposit') {
                    // Update transaction status
                    $stmt = $conn->prepare("UPDATE transactions SET status = 'completed' WHERE id = ?");
                    $stmt->execute([$transactionId]);
                    
                    // Add to user wallet
                    $stmt = $conn->prepare("UPDATE users SET wallet_balance = wallet_balance + ? WHERE id = ?");
                    $stmt->execute([$transaction['net_amount'], $transaction['user_id']]);
                    
                    // Create notification
                    createNotification(
                        $transaction['user_id'],
                        'transaction',
                        'Deposit Disetujui',
                        'Deposit Anda sebesar ' . formatCurrency($transaction['net_amount']) . ' telah disetujui',
                        'wallet.php'
                    );
                    
                    setFlashMessage('success', 'Deposit berhasil disetujui');
                } elseif ($transaction['transaction_type'] === 'withdrawal') {
                    // Update transaction status
                    $stmt = $conn->prepare("UPDATE transactions SET status = 'completed' WHERE id = ?");
                    $stmt->execute([$transactionId]);
                    
                    // Create notification
                    createNotification(
                        $transaction['user_id'],
                        'transaction',
                        'Penarikan Diproses',
                        'Penarikan Anda sebesar ' . formatCurrency($transaction['net_amount']) . ' telah diproses',
                        'wallet.php'
                    );
                    
                    setFlashMessage('success', 'Penarikan berhasil diproses');
                }
            }
        } elseif ($action === 'reject') {
            $stmt = $conn->prepare("UPDATE transactions SET status = 'rejected' WHERE id = ?");
            $stmt->execute([$transactionId]);
            
            createNotification(
                $transaction['user_id'],
                'transaction',
                'Transaksi Ditolak',
                'Transaksi Anda telah ditolak. Silakan hubungi admin.',
                'wallet.php'
            );
            
            setFlashMessage('success', 'Transaksi telah ditolak');
        }
    }
    redirect('transactions.php');
}
?>