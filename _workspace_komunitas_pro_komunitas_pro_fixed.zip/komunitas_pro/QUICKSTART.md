# Quick Start Guide - Komunitas Marketplace

Panduan cepat untuk memulai menggunakan Komunitas Marketplace dalam 5 menit!

## 🚀 Instalasi Cepat (5 Menit)

### Langkah 1: Download & Extract (30 detik)
```bash
# Download source code
# Extract ke folder web server Anda
# Contoh: C:\xampp\htdocs\komunitas (Windows)
# Contoh: /var/www/html/komunitas (Linux)
```

### Langkah 2: Buat Database (1 menit)
```sql
-- Buka phpMyAdmin (http://localhost/phpmyadmin)
-- Buat database baru:
CREATE DATABASE komunitas_marketplace;

-- Import database.sql melalui tab Import
```

### Langkah 3: Konfigurasi (1 menit)
Edit file `config.php`:
```php
// Update baris berikut:
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', ''); // Kosongkan untuk XAMPP
define('DB_NAME', 'komunitas_marketplace');
define('SITE_URL', 'http://localhost/komunitas');
```

### Langkah 4: Setup Folder (30 detik)
```bash
# Jalankan setup script
php setup.php

# Atau buat folder manual:
mkdir uploads/profiles uploads/posts uploads/products uploads/proofs
```

### Langkah 5: Akses Website (30 detik)
```
Buka browser: http://localhost/komunitas
Login dengan:
- Username: admin
- Password: admin123
```

**Selesai! Website sudah siap digunakan! 🎉**

---

## 📱 Panduan Penggunaan Cepat

### Untuk Pengguna Biasa

#### 1. Registrasi & Login
1. Klik "Daftar sekarang"
2. Isi form registrasi
3. Masukkan kode CAPTCHA
4. Klik "Daftar"
5. Login dengan akun baru

#### 2. Membuat Postingan
1. Di halaman beranda, klik input "Apa yang ingin Anda bagikan?"
2. Pilih "Posting" untuk postingan biasa
3. Isi judul dan konten
4. Upload gambar (opsional)
5. Pilih bahasa
6. Klik "Posting"

#### 3. Menjual Produk
1. Di halaman beranda, klik "Jual Produk"
2. Isi detail produk:
   - Judul
   - Deskripsi
   - Harga
   - Kategori
   - Tipe (Fisik/Digital)
3. Upload gambar produk
4. Untuk produk digital, upload file
5. Klik "Posting"

#### 4. Deposit Saldo
1. Klik menu "Wallet"
2. Klik "Deposit"
3. Pilih "Transfer Manual"
4. Masukkan jumlah deposit
5. Transfer ke rekening yang ditampilkan
6. Upload bukti transfer
7. Tunggu konfirmasi admin

#### 5. Chat dengan Pengguna
1. Klik menu "Chat"
2. Klik icon "+" untuk chat baru
3. Cari pengguna
4. Klik "Chat"
5. Ketik pesan dan kirim

#### 6. Edit Profil
1. Klik foto profil di kanan atas
2. Pilih "Profil Saya"
3. Klik "Edit Profil"
4. Update informasi
5. Klik "Simpan Perubahan"

### Untuk Admin

#### 1. Akses Admin Panel
1. Login sebagai admin
2. Klik "Admin Panel" di menu user
3. Atau akses: http://localhost/komunitas/admin

#### 2. Approve Deposit
1. Di dashboard, lihat notifikasi deposit pending
2. Klik "Lihat Sekarang" atau buka menu "Kelola Transaksi"
3. Filter status "Pending"
4. Klik icon gambar untuk lihat bukti transfer
5. Klik icon centang untuk approve
6. Atau klik icon X untuk reject

#### 3. Kelola Pengguna
1. Buka menu "Kelola Pengguna"
2. Cari pengguna (opsional)
3. Klik icon mata untuk lihat profil
4. Klik icon ban untuk ban/unban
5. Klik icon trash untuk hapus

#### 4. Ubah Pengaturan
1. Buka menu "Pengaturan"
2. Update pengaturan yang diinginkan:
   - Nama website
   - Email
   - Fee withdrawal
   - Midtrans keys
   - dll
3. Klik "Simpan Pengaturan"

---

## 🎯 Tips & Trik

### Untuk Pengguna

**Meningkatkan Penjualan:**
- Upload foto produk berkualitas tinggi
- Tulis deskripsi lengkap dan jelas
- Set harga kompetitif
- Respon cepat terhadap pertanyaan
- Gunakan kategori yang tepat

**Keamanan Akun:**
- Gunakan password yang kuat
- Jangan share password
- Logout setelah selesai
- Ganti password secara berkala
- Waspada terhadap penipuan

**Interaksi Komunitas:**
- Like postingan yang menarik
- Berikan komentar konstruktif
- Share konten berkualitas
- Bangun network
- Aktif berpartisipasi

### Untuk Admin

**Moderasi Efektif:**
- Cek deposit pending setiap hari
- Review postingan yang dilaporkan
- Monitor aktivitas mencurigakan
- Backup database rutin
- Update pengaturan sesuai kebutuhan

**Keamanan:**
- Ganti password admin default
- Enable HTTPS di production
- Monitor error logs
- Update software rutin
- Batasi akses admin

**Performance:**
- Optimize database rutin
- Clean old data
- Monitor server resources
- Enable caching
- Compress images

---

## 🔧 Troubleshooting Cepat

### Error: "Database connection failed"
```bash
# Cek apakah MySQL running
# Cek kredensial di config.php
# Pastikan database sudah dibuat
```

### CAPTCHA tidak muncul
```bash
# Cek apakah GD Library terinstall
php -m | grep gd
# Restart web server
```

### Upload file gagal
```bash
# Cek permission folder uploads
chmod -R 755 uploads/
# Cek php.ini untuk upload_max_filesize
```

### Session tidak tersimpan
```bash
# Cek permission folder session
# Restart web server
# Clear browser cookies
```

---

## 📚 Dokumentasi Lengkap

Untuk informasi lebih detail, lihat:
- **README.md** - Dokumentasi lengkap
- **INSTALL.md** - Panduan instalasi detail
- **FEATURES.md** - Daftar fitur lengkap
- **API_DOCUMENTATION.md** - Dokumentasi API
- **DEPLOYMENT.md** - Panduan deployment

---

## 🎓 Tutorial Video

Ingin belajar lebih dalam?

**Subscribe YouTube Channel:** [@kursibiru](https://youtube.com/@kursibiru)

Tutorial yang tersedia:
- Instalasi lengkap
- Cara menggunakan fitur
- Tips & trik
- Troubleshooting
- Customization
- Dan banyak lagi!

---

## 💬 Butuh Bantuan?

**Email:** info@komunitas.com

**Forum:** Coming soon

**GitHub Issues:** https://github.com/yourusername/komunitas-marketplace/issues

---

## ✅ Checklist Setelah Instalasi

- [ ] Database berhasil diimport
- [ ] Config.php sudah diupdate
- [ ] Folder uploads sudah dibuat
- [ ] Website bisa diakses
- [ ] Login admin berhasil
- [ ] Password admin sudah diganti
- [ ] Test buat postingan
- [ ] Test upload gambar
- [ ] Test chat
- [ ] Test notifikasi
- [ ] Test deposit (opsional)
- [ ] Test admin panel

---

**Selamat menggunakan Komunitas Marketplace! 🚀**

Jangan lupa subscribe [@kursibiru](https://youtube.com/@kursibiru) untuk tutorial dan update terbaru!