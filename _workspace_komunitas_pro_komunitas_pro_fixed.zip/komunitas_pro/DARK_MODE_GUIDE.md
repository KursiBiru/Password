# 🌙 Dark Mode Guide - Neon Purple Theme

## Overview

Website Komunitas Marketplace sekarang dilengkapi dengan **Dark Mode** yang menakjubkan dengan tema **Neon Purple**! Dark mode ini memberikan pengalaman visual yang lebih nyaman di malam hari dan tampilan yang futuristik dengan efek neon yang memukau.

## ✨ Fitur Dark Mode

### 1. **Warna Neon Purple**
- Primary: `#b24bf3` (Neon Purple)
- Secondary: `#ff2e97` (Neon Pink)
- Accent: `#00d9ff` (Neon Blue)
- Success: `#39ff14` (Neon Green)

### 2. **Efek Visual**
- ✅ Neon glow effects
- ✅ Smooth transitions
- ✅ Pulsing animations
- ✅ Glowing text shadows
- ✅ Custom scrollbar
- ✅ Gradient backgrounds

### 3. **Komponen yang Didukung**
- ✅ Header & Navigation
- ✅ Sidebar & Feed
- ✅ Posts & Comments
- ✅ Profile Pages
- ✅ Wallet Interface
- ✅ Chat System
- ✅ Notifications
- ✅ Admin Panel
- ✅ Forms & Buttons
- ✅ Modals & Alerts
- ✅ Footer

## 🎮 Cara Menggunakan

### Metode 1: Toggle Button
Klik tombol floating di kanan bawah layar:
- 🌙 **Moon Icon** = Aktifkan Dark Mode
- ☀️ **Sun Icon** = Nonaktifkan Dark Mode

### Metode 2: Keyboard Shortcut
Tekan `Ctrl + D` (Windows/Linux) atau `Cmd + D` (Mac)

### Metode 3: JavaScript API
```javascript
// Enable dark mode
window.darkMode.enable();

// Disable dark mode
window.darkMode.disable();

// Toggle dark mode
window.darkMode.toggle();

// Check if dark mode is enabled
if (window.darkMode.isEnabled()) {
    console.log('Dark mode is active!');
}
```

## 🎨 Customization

### Mengubah Warna Neon

Edit file `assets/css/dark-mode.css`:

```css
:root {
    /* Ganti warna neon purple */
    --neon-purple: #b24bf3;        /* Warna utama */
    --neon-purple-light: #d896ff;  /* Warna terang */
    --neon-purple-dark: #8b2fc9;   /* Warna gelap */
    
    /* Ganti warna accent */
    --neon-pink: #ff2e97;
    --neon-blue: #00d9ff;
    --neon-green: #39ff14;
}
```

### Mengubah Background

```css
:root {
    --dark-bg: #0a0a0f;           /* Background utama */
    --dark-bg-secondary: #13131a; /* Background secondary */
    --dark-bg-tertiary: #1a1a24;  /* Background tertiary */
}
```

### Menambah Efek Neon Custom

```css
.your-element {
    box-shadow: 0 0 20px var(--neon-purple-glow);
    text-shadow: 0 0 10px var(--neon-purple-glow);
}
```

## 💡 Tips & Tricks

### 1. Efek Pulse
Tambahkan class `neon-pulse` untuk efek berkedip:
```html
<button class="btn btn-primary neon-pulse">Click Me</button>
```

### 2. Glowing Text
Tambahkan class `glow-text` untuk teks bercahaya:
```html
<h1 class="glow-text">Neon Title</h1>
```

### 3. Custom Glow
```css
.custom-glow {
    box-shadow: 0 0 20px rgba(178, 75, 243, 0.5),
                0 0 40px rgba(178, 75, 243, 0.3),
                0 0 60px rgba(178, 75, 243, 0.1);
}
```

## 🔧 Technical Details

### File Structure
```
assets/
├── css/
│   └── dark-mode.css      # Dark mode styles
└── js/
    └── dark-mode.js       # Dark mode logic
```

### Local Storage
Dark mode preference disimpan di `localStorage`:
- Key: `darkMode`
- Value: `enabled` atau `disabled`

### Browser Support
- ✅ Chrome 90+
- ✅ Firefox 88+
- ✅ Safari 14+
- ✅ Edge 90+
- ✅ Opera 76+

## 🎯 Best Practices

### 1. Konsistensi Warna
Gunakan CSS variables untuk konsistensi:
```css
color: var(--neon-purple);
background: var(--dark-bg);
border-color: var(--dark-border);
```

### 2. Transitions
Semua elemen memiliki smooth transition:
```css
transition: background-color 0.3s ease,
            color 0.3s ease,
            border-color 0.3s ease;
```

### 3. Accessibility
- Kontras warna yang baik
- Readable text colors
- Clear focus states
- Keyboard navigation support

## 🐛 Troubleshooting

### Dark Mode Tidak Aktif
1. Clear browser cache
2. Check console for errors
3. Verify files loaded correctly
4. Check localStorage

### Warna Tidak Sesuai
1. Clear CSS cache
2. Hard refresh (Ctrl + F5)
3. Check CSS file loaded
4. Verify CSS variables

### Toggle Button Tidak Muncul
1. Check JavaScript loaded
2. Verify dark-mode.js included
3. Check console for errors
4. Ensure DOM loaded

## 📱 Mobile Support

Dark mode fully responsive:
- ✅ Touch-friendly toggle button
- ✅ Optimized for small screens
- ✅ Smooth animations
- ✅ Battery-friendly

## ⚡ Performance

### Optimizations
- CSS variables for instant switching
- Hardware-accelerated animations
- Minimal repaints
- Efficient transitions

### Load Time
- CSS: ~15KB (minified)
- JS: ~3KB (minified)
- Total: ~18KB

## 🎨 Color Palette

### Dark Backgrounds
```
#0a0a0f - Main background
#13131a - Secondary background
#1a1a24 - Tertiary background
#1f1f2e - Surface
#252538 - Surface hover
```

### Neon Colors
```
#b24bf3 - Neon Purple
#d896ff - Neon Purple Light
#8b2fc9 - Neon Purple Dark
#ff2e97 - Neon Pink
#00d9ff - Neon Blue
#39ff14 - Neon Green
```

### Text Colors
```
#e8e8f0 - Primary text
#b8b8c8 - Secondary text
#7a7a8a - Muted text
```

## 🚀 Advanced Features

### Auto Dark Mode (Future)
```javascript
// Detect system preference
if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
    window.darkMode.enable();
}
```

### Time-based Dark Mode (Future)
```javascript
// Auto enable at night
const hour = new Date().getHours();
if (hour >= 18 || hour <= 6) {
    window.darkMode.enable();
}
```

## 📊 Statistics

- **Total CSS Lines:** 1000+
- **Color Variables:** 20+
- **Animated Elements:** 50+
- **Supported Components:** 100%

## 🎓 Examples

### Example 1: Custom Neon Button
```html
<button class="btn-neon">
    Click Me
</button>

<style>
.btn-neon {
    background: linear-gradient(135deg, var(--neon-purple), var(--neon-pink));
    color: white;
    border: none;
    padding: 15px 30px;
    border-radius: 8px;
    box-shadow: 0 0 20px var(--neon-purple-glow);
    transition: all 0.3s;
}

.btn-neon:hover {
    box-shadow: 0 0 40px var(--neon-purple-glow);
    transform: translateY(-2px);
}
</style>
```

### Example 2: Neon Card
```html
<div class="neon-card">
    <h3>Neon Card</h3>
    <p>Content here</p>
</div>

<style>
.neon-card {
    background: var(--dark-bg-secondary);
    border: 1px solid var(--neon-purple);
    border-radius: 12px;
    padding: 20px;
    box-shadow: 0 0 20px var(--neon-purple-glow);
}
</style>
```

## 🔮 Future Enhancements

- [ ] Multiple theme options
- [ ] Custom color picker
- [ ] Theme presets
- [ ] Scheduled dark mode
- [ ] System preference sync
- [ ] Theme sharing

## 📞 Support

Jika ada pertanyaan tentang dark mode:
- Email: info@komunitas.com
- YouTube: [@kursibiru](https://youtube.com/@kursibiru)

## 📝 Credits

- **Design:** NinjaTech AI
- **Inspiration:** Cyberpunk aesthetics
- **Color Scheme:** Neon Purple theme

---

**Enjoy the Neon Purple Dark Mode! 🌙✨**

Made with 💜 by NinjaTech AI