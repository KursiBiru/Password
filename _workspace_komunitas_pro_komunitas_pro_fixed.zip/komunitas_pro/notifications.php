<?php
require_once 'config.php';
requireLogin();

$user = getCurrentUser();
$conn = getDBConnection();

// Mark all as read if requested
if (isset($_GET['mark_all_read'])) {
    $stmt = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?");
    $stmt->execute([$user['id']]);
    redirect('notifications.php');
}

// Get notifications
$stmt = $conn->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 50");
$stmt->execute([$user['id']]);
$notifications = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notifikasi - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/unified.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <div class="container">
        <div class="notifications-container">
            <div class="notifications-header">
                <h1><i class="fas fa-bell"></i> Notifikasi</h1>
                <?php if (!empty($notifications)): ?>
                    <a href="?mark_all_read=1" class="btn btn-sm">
                        <i class="fas fa-check-double"></i> Tandai Semua Dibaca
                    </a>
                <?php endif; ?>
            </div>
            
            <?php if (empty($notifications)): ?>
                <div class="empty-state">
                    <i class="fas fa-bell-slash"></i>
                    <p>Belum ada notifikasi</p>
                </div>
            <?php else: ?>
                <div class="notifications-list">
                    <?php foreach ($notifications as $notif): ?>
                        <div class="notification-item <?php echo $notif['is_read'] ? 'read' : 'unread'; ?>" 
                             onclick="markAsRead(<?php echo $notif['id']; ?>, '<?php echo $notif['link'] ?? '#'; ?>')">
                            <div class="notification-icon">
                                <?php
                                $iconClass = '';
                                $iconColor = '';
                                switch ($notif['type']) {
                                    case 'like':
                                        $iconClass = 'fa-heart';
                                        $iconColor = 'text-danger';
                                        break;
                                    case 'comment':
                                        $iconClass = 'fa-comment';
                                        $iconColor = 'text-primary';
                                        break;
                                    case 'share':
                                        $iconClass = 'fa-share';
                                        $iconColor = 'text-success';
                                        break;
                                    case 'message':
                                        $iconClass = 'fa-envelope';
                                        $iconColor = 'text-info';
                                        break;
                                    case 'purchase':
                                    case 'sale':
                                        $iconClass = 'fa-shopping-cart';
                                        $iconColor = 'text-warning';
                                        break;
                                    case 'transaction':
                                        $iconClass = 'fa-dollar-sign';
                                        $iconColor = 'text-success';
                                        break;
                                    default:
                                        $iconClass = 'fa-bell';
                                        $iconColor = 'text-secondary';
                                }
                                ?>
                                <i class="fas <?php echo $iconClass; ?> <?php echo $iconColor; ?>"></i>
                            </div>
                            <div class="notification-content">
                                <h4><?php echo htmlspecialchars($notif['title']); ?></h4>
                                <p><?php echo htmlspecialchars($notif['message']); ?></p>
                                <span class="notification-time"><?php echo timeAgo($notif['created_at']); ?></span>
                            </div>
                            <?php if (!$notif['is_read']): ?>
                                <div class="notification-badge"></div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <?php include 'includes/footer.php'; ?>
    
    <script src="assets/js/main.js"></script>
    <script>
        function markAsRead(notifId, link) {
            fetch('api/mark-notification-read.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ notification_id: notifId })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success && link && link !== '#') {
                    window.location.href = link;
                } else if (data.success) {
                    location.reload();
                }
            });
        }
    </script>
</body>
</html>