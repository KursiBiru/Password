<footer class="main-footer">
    <div class="container">
        <div class="footer-content">
            <div class="footer-section">
                <h3><?php echo SITE_NAME; ?></h3>
                <p>Platform komunitas dan marketplace untuk berbagi dan berjualan</p>
                <div class="social-links">
                    <a href="https://youtube.com/@kursibiru" target="_blank" title="YouTube">
                        <i class="fab fa-youtube"></i>
                    </a>
                    <a href="#" target="_blank" title="Facebook">
                        <i class="fab fa-facebook"></i>
                    </a>
                    <a href="#" target="_blank" title="Instagram">
                        <i class="fab fa-instagram"></i>
                    </a>
                    <a href="#" target="_blank" title="Twitter">
                        <i class="fab fa-twitter"></i>
                    </a>
                </div>
            </div>
            
            <div class="footer-section">
                <h4>Tentang</h4>
                <ul>
                    <li><a href="about.php">Tentang Kami</a></li>
                    <li><a href="terms.php">Syarat & Ketentuan</a></li>
                    <li><a href="privacy.php">Kebijakan Privasi</a></li>
                    <li><a href="license.php">Lisensi</a></li>
                </ul>
            </div>
            
            <div class="footer-section">
                <h4>Bantuan</h4>
                <ul>
                    <li><a href="faq.php">FAQ</a></li>
                    <li><a href="contact.php">Kontak</a></li>
                    <li><a href="help.php">Pusat Bantuan</a></li>
                </ul>
            </div>
            
            <div class="footer-section">
                <h4>Belajar Lebih Banyak</h4>
                <p>Subscribe channel YouTube kami untuk tutorial dan tips menarik!</p>
                <a href="https://youtube.com/@kursibiru" target="_blank" class="btn btn-danger btn-sm">
                    <i class="fab fa-youtube"></i> Subscribe kursibiru
                </a>
            </div>
        </div>
        
        <div class="footer-bottom">
            <p>&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?>. All rights reserved.</p>
            <p>Made with <i class="fas fa-heart" style="color: #e74c3c;"></i> by NinjaTech AI</p>
        </div>
    </div>
</footer>

<!-- Dark Mode JavaScript -->
<script src="assets/js/dark-mode.js"></script>