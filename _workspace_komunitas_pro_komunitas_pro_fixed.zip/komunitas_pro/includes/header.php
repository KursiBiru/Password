<?php
if (!isset($user)) {
    $user = getCurrentUser();
}
$unreadNotifications = getUnreadNotificationCount($user['id']);
$unreadMessages = getUnreadMessageCount($user['id']);
?>
<!-- Dark Mode CSS -->
<link rel="stylesheet" href="assets/css/dark-mode.css">

<header class="main-header">
    <div class="container">
        <div class="header-content">
            <div class="header-left">
                <a href="index.php" class="logo">
                    <i class="fas fa-users"></i>
                    <?php echo SITE_NAME; ?>
                </a>
                
                <form action="search.php" method="GET" class="search-form">
                    <input type="text" name="q" placeholder="Cari..." class="search-input">
                    <button type="submit" class="search-btn"><i class="fas fa-search"></i></button>
                </form>
            </div>
            
            <nav class="header-nav">
                <a href="index.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) === 'index.php' ? 'active' : ''; ?>">
                    <i class="fas fa-home"></i>
                    <span>Beranda</span>
                </a>
                <a href="wallet.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) === 'wallet.php' ? 'active' : ''; ?>">
                    <i class="fas fa-wallet"></i>
                    <span>Wallet</span>
                </a>
                <a href="chat.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) === 'chat.php' ? 'active' : ''; ?>">
                    <i class="fas fa-comments"></i>
                    <span>Chat</span>
                    <?php if ($unreadMessages > 0): ?>
                        <span class="badge"><?php echo $unreadMessages; ?></span>
                    <?php endif; ?>
                </a>
                <a href="notifications.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) === 'notifications.php' ? 'active' : ''; ?>">
                    <i class="fas fa-bell"></i>
                    <span>Notifikasi</span>
                    <?php if ($unreadNotifications > 0): ?>
                        <span class="badge"><?php echo $unreadNotifications; ?></span>
                    <?php endif; ?>
                </a>
            </nav>
            
            <div class="header-right">
                <div class="user-menu">
                    <button class="user-menu-btn" onclick="toggleUserMenu()">
                        <img src="uploads/profiles/<?php echo htmlspecialchars($user['profile_photo']); ?>" alt="Profile" class="avatar-small">
                        <span><?php echo htmlspecialchars($user['username']); ?></span>
                        <i class="fas fa-chevron-down"></i>
                    </button>
                    <div class="user-menu-dropdown" id="userMenuDropdown">
                        <a href="profile.php?id=<?php echo $user['id']; ?>">
                            <i class="fas fa-user"></i> Profil Saya
                        </a>
                        <a href="wallet.php">
                            <i class="fas fa-wallet"></i> Wallet (<?php echo formatCurrency($user['wallet_balance']); ?>)
                        </a>
                        <a href="settings.php">
                            <i class="fas fa-cog"></i> Pengaturan
                        </a>
                        <?php if ($user['is_admin']): ?>
                            <a href="admin/index.php">
                                <i class="fas fa-shield-alt"></i> Admin Panel
                            </a>
                        <?php endif; ?>
                        <hr>
                        <a href="logout.php">
                            <i class="fas fa-sign-out-alt"></i> Keluar
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>

<!-- Notification Toast Container -->
<div id="notificationToast" class="notification-toast"></div>

<!-- Audio for notification sound -->
<audio id="notificationSound" preload="auto">
    <source src="assets/sounds/notification.mp3" type="audio/mpeg">
</audio>

<script>
function toggleUserMenu() {
    const dropdown = document.getElementById('userMenuDropdown');
    dropdown.classList.toggle('show');
}

// Close dropdown when clicking outside
window.onclick = function(event) {
    if (!event.target.matches('.user-menu-btn') && !event.target.closest('.user-menu-btn')) {
        const dropdowns = document.getElementsByClassName('user-menu-dropdown');
        for (let i = 0; i < dropdowns.length; i++) {
            const openDropdown = dropdowns[i];
            if (openDropdown.classList.contains('show')) {
                openDropdown.classList.remove('show');
            }
        }
    }
}
</script>