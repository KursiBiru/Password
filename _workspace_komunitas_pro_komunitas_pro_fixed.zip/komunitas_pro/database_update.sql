-- Update untuk sistem konfirmasi produk

-- Tambah kolom confirmation_status ke tabel purchases
ALTER TABLE purchases 
ADD COLUMN confirmation_status ENUM('pending', 'buyer_confirmed', 'seller_confirmed', 'admin_confirmed', 'completed') DEFAULT 'pending' AFTER status,
ADD COLUMN buyer_confirmed_at TIMESTAMP NULL AFTER confirmation_status,
ADD COLUMN seller_confirmed_at TIMESTAMP NULL AFTER buyer_confirmed_at,
ADD COLUMN admin_confirmed_at TIMESTAMP NULL AFTER seller_confirmed_at,
ADD COLUMN confirmation_notes TEXT AFTER admin_confirmed_at;

-- Buat tabel product_confirmations
CREATE TABLE IF NOT EXISTS product_confirmations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    purchase_id INT NOT NULL,
    confirmed_by INT NOT NULL, -- user_id yang melakukan konfirmasi
    confirmation_type ENUM('buyer', 'seller', 'admin') NOT NULL,
    status ENUM('received', 'delivered', 'issue', 'cancel') NOT NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (purchase_id) REFERENCES purchases(id) ON DELETE CASCADE,
    FOREIGN KEY (confirmed_by) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_purchase_id (purchase_id),
    INDEX idx_confirmed_by (confirmed_by)
);

-- Update notifikasi untuk konfirmasi produk
INSERT INTO notifications (user_id, type, title, message, related_post_id, created_at)
SELECT 
    seller_id,
    'purchase_confirmation',
    'Penjualan Baru Menunggu Konfirmasi',
    CONCAT('Pembelian produk #', p.id, ' menunggu konfirmasi dari pembeli. Segera konfirmasi setelah pembeli menerima produk.'),
    p.post_id,
    NOW()
FROM purchases p
WHERE p.confirmation_status = 'pending';

-- Trigger untuk otomatis menyelesaikan pembelian jika pembeli dan penjual sudah konfirmasi
DELIMITER //
CREATE TRIGGER auto_complete_purchase
AFTER INSERT ON product_confirmations
FOR EACH ROW
BEGIN
    DECLARE buyer_confirmed INT DEFAULT 0;
    DECLARE seller_confirmed INT DEFAULT 0;
    
    -- Cek apakah pembeli dan penjual sudah konfirmasi
    SELECT COUNT(*) INTO buyer_confirmed 
    FROM product_confirmations pc 
    JOIN purchases p ON pc.purchase_id = p.id 
    WHERE pc.purchase_id = NEW.purchase_id 
    AND pc.confirmation_type = 'buyer' 
    AND pc.status IN ('received', 'delivered');
    
    SELECT COUNT(*) INTO seller_confirmed 
    FROM product_confirmations pc 
    JOIN purchases p ON pc.purchase_id = p.id 
    WHERE pc.purchase_id = NEW.purchase_id 
    AND pc.confirmation_type = 'seller' 
    AND pc.status IN ('received', 'delivered');
    
    -- Jika kedua belah pihak sudah konfirmasi, update status pembelian
    IF buyer_confirmed > 0 AND seller_confirmed > 0 THEN
        UPDATE purchases 
        SET confirmation_status = 'completed',
            status = 'completed',
            admin_confirmed_at = NOW()
        WHERE id = NEW.purchase_id;
        
        -- Tambah notifikasi ke penjual bahwa uang telah masuk
        INSERT INTO notifications (user_id, type, title, message, related_post_id, created_at)
        SELECT 
            p.seller_id,
            'payment_received',
            'Pembayaran Diterima',
            CONCAT('Pembayaran untuk produk #', p.id, ' telah diterima. Uang telah ditambahkan ke saldo Anda.'),
            p.post_id,
            NOW()
        FROM purchases p 
        WHERE p.id = NEW.purchase_id;
    END IF;
END//
DELIMITER ;