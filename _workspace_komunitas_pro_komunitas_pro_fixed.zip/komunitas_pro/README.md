# Komunitas Marketplace - Platform Komunitas & Marketplace

Platform komunitas dan marketplace lengkap yang dibangun dengan PHP dan MySQL. Menggabungkan fitur media sosial dengan kemampuan jual beli produk digital dan fisik.

## 🚀 Fitur Utama

### Fitur Pengguna
- ✅ **Sistem Autentikasi Lengkap**
  - Login & Register dengan CSRF Token
  - CAPTCHA untuk keamanan
  - Password hashing dengan bcrypt
  
- ✅ **Halaman Komunitas**
  - Posting konten (teks, gambar)
  - Komentar pada postingan
  - Like & Share postingan
  - Filter berdasarkan bahasa dan kategori
  
- ✅ **Marketplace**
  - Posting produk (fisik & digital)
  - Filter produk berdasarkan kategori
  - Sistem pembelian terintegrasi
  
- ✅ **Wallet System**
  - Deposit otomatis (Midtrans) & manual
  - Withdrawal dengan fee 3%
  - Riwayat transaksi lengkap
  - Kode unik untuk deposit manual
  
- ✅ **Chat Real-time**
  - Chat 1-on-1 antar pengguna
  - Pencarian pengguna
  - Notifikasi pesan baru
  
- ✅ **Notifikasi Real-time**
  - Toast notification dengan sound
  - Notifikasi untuk like, comment, share
  - Notifikasi transaksi
  - Badge counter

- ✅ **Profil Pengguna**
  - Edit profil & foto
  - Statistik pengguna
  - Daftar postingan & produk

### Fitur Admin
- ✅ **Dashboard Admin**
  - Statistik lengkap
  - Grafik pendapatan
  - Monitoring aktivitas
  
- ✅ **Kelola Pengguna**
  - Lihat semua pengguna
  - Ban/Unban pengguna
  - Hapus pengguna
  
- ✅ **Kelola Transaksi**
  - Approve/Reject deposit
  - Lihat riwayat transaksi
  - Kelola withdrawal
  
- ✅ **Kelola Postingan**
  - Moderasi konten
  - Hapus postingan
  
- ✅ **Pengaturan Website**
  - Konfigurasi umum
  - Pengaturan Midtrans
  - Pengaturan keamanan

### Keamanan
- ✅ CSRF Token protection
- ✅ CAPTCHA verification
- ✅ Password hashing
- ✅ SQL injection prevention (PDO)
- ✅ XSS protection
- ✅ Session management

## 📋 Persyaratan Sistem

- PHP 7.4 atau lebih tinggi
- MySQL 5.7 atau lebih tinggi
- Apache/Nginx web server
- GD Library (untuk CAPTCHA)
- PDO Extension
- JSON Extension

## 🛠️ Instalasi

### 1. Clone atau Download Repository

```bash
git clone https://github.com/yourusername/komunitas-marketplace.git
cd komunitas-marketplace
```

### 2. Buat Database

```sql
CREATE DATABASE komunitas_marketplace;
```

### 3. Import Database

```bash
mysql -u root -p komunitas_marketplace < database.sql
```

Atau import melalui phpMyAdmin:
1. Buka phpMyAdmin
2. Pilih database `komunitas_marketplace`
3. Klik tab "Import"
4. Pilih file `database.sql`
5. Klik "Go"

### 4. Konfigurasi Database

Edit file `config.php` dan sesuaikan pengaturan database:

```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'komunitas_marketplace');
```

### 5. Konfigurasi URL

Edit `config.php` dan sesuaikan URL website:

```php
define('SITE_URL', 'http://localhost/komunitas'); // Ganti dengan URL Anda
```

### 6. Buat Folder Upload

Pastikan folder berikut ada dan memiliki permission write (755 atau 777):

```bash
mkdir -p uploads/profiles
mkdir -p uploads/posts
mkdir -p uploads/products
mkdir -p uploads/proofs
chmod -R 755 uploads/
```

### 7. Copy Default Avatar

Copy file `default-avatar.png` ke folder `uploads/profiles/`

### 8. Akses Website

Buka browser dan akses:
```
http://localhost/komunitas
```

## 👤 Akun Default

### Admin
- **Username:** admin
- **Email:** admin@komunitas.com
- **Password:** admin123

**PENTING:** Segera ganti password default setelah login pertama kali!

## 📁 Struktur Folder

```
komunitas-marketplace/
├── admin/                  # Admin panel
│   ├── includes/          # Admin includes
│   ├── index.php          # Admin dashboard
│   ├── users.php          # User management
│   ├── transactions.php   # Transaction management
│   └── settings.php       # Website settings
├── api/                   # API endpoints
│   ├── get-messages.php
│   ├── send-message.php
│   ├── create-post.php
│   └── ...
├── assets/                # Static assets
│   ├── css/
│   │   ├── style.css      # Main stylesheet
│   │   └── admin.css      # Admin stylesheet
│   ├── js/
│   │   ├── main.js        # Main JavaScript
│   │   ├── posts.js       # Posts JavaScript
│   │   └── admin.js       # Admin JavaScript
│   └── sounds/
│       └── notification.mp3
├── includes/              # Shared includes
│   ├── header.php
│   └── footer.php
├── uploads/               # Upload directory
│   ├── profiles/
│   ├── posts/
│   ├── products/
│   └── proofs/
├── config.php             # Configuration file
├── database.sql           # Database schema
├── index.php              # Homepage
├── login.php              # Login page
├── register.php           # Registration page
├── profile.php            # User profile
├── wallet.php             # Wallet page
├── chat.php               # Chat page
├── notifications.php      # Notifications page
├── about.php              # About page
├── terms.php              # Terms of service
├── privacy.php            # Privacy policy
├── license.php            # License page
└── README.md              # This file
```

## 🔧 Konfigurasi Midtrans (Opsional)

Untuk mengaktifkan deposit otomatis dengan Midtrans:

1. Daftar di [Midtrans](https://midtrans.com)
2. Dapatkan Server Key dan Client Key
3. Masuk ke Admin Panel → Settings
4. Isi Midtrans Server Key dan Client Key
5. Pilih mode (Sandbox/Production)

## 🎨 Kustomisasi

### Mengubah Warna Tema

Edit file `assets/css/style.css` dan ubah variabel CSS:

```css
:root {
    --primary-color: #3498db;
    --secondary-color: #2ecc71;
    --danger-color: #e74c3c;
    /* ... */
}
```

### Mengubah Logo

Ganti logo di file `includes/header.php`

### Mengubah Nama Website

Edit `config.php`:

```php
define('SITE_NAME', 'Nama Website Anda');
```

## 📱 Responsive Design

Website ini fully responsive dan dapat diakses dengan baik di:
- Desktop (1920px+)
- Laptop (1024px - 1920px)
- Tablet (768px - 1024px)
- Mobile (320px - 768px)

## 🔒 Keamanan

### Best Practices yang Diterapkan:

1. **CSRF Protection:** Semua form menggunakan CSRF token
2. **CAPTCHA:** Login dan register dilindungi CAPTCHA
3. **Password Hashing:** Password di-hash dengan bcrypt
4. **Prepared Statements:** Semua query menggunakan PDO prepared statements
5. **Input Sanitization:** Semua input user di-sanitize
6. **XSS Prevention:** Output di-escape dengan htmlspecialchars
7. **Session Security:** Session management yang aman

### Rekomendasi Tambahan:

1. Gunakan HTTPS di production
2. Aktifkan firewall
3. Update PHP dan MySQL secara berkala
4. Backup database secara rutin
5. Monitor log secara berkala

## 🐛 Troubleshooting

### Error: "Database connection failed"
- Pastikan MySQL service berjalan
- Cek kredensial database di `config.php`
- Pastikan database sudah dibuat

### Error: "Permission denied" saat upload
- Cek permission folder `uploads/`
- Jalankan: `chmod -R 755 uploads/`

### CAPTCHA tidak muncul
- Pastikan GD Library terinstall
- Cek: `php -m | grep gd`

### Notifikasi tidak muncul
- Cek browser console untuk error JavaScript
- Pastikan file `notification.mp3` ada di `assets/sounds/`

## 📚 Dokumentasi API

### Endpoints Tersedia:

#### Posts
- `POST /api/create-post.php` - Buat postingan baru
- `GET /api/get-posts.php` - Ambil daftar postingan
- `POST /api/toggle-like.php` - Like/Unlike postingan
- `POST /api/add-comment.php` - Tambah komentar
- `GET /api/get-comments.php` - Ambil komentar

#### Messages
- `GET /api/get-messages.php` - Ambil pesan
- `POST /api/send-message.php` - Kirim pesan
- `GET /api/search-users.php` - Cari pengguna

#### Notifications
- `GET /api/get-notifications.php` - Ambil notifikasi
- `POST /api/mark-notification-read.php` - Tandai dibaca

## 🤝 Kontribusi

Kontribusi sangat diterima! Silakan:

1. Fork repository
2. Buat branch fitur (`git checkout -b feature/AmazingFeature`)
3. Commit perubahan (`git commit -m 'Add some AmazingFeature'`)
4. Push ke branch (`git push origin feature/AmazingFeature`)
5. Buat Pull Request

## 📺 Tutorial

Ingin belajar cara membuat website seperti ini?

**Subscribe YouTube Channel:** [kursibiru](https://youtube.com/@kursibiru)

## 📄 Lisensi

Project ini menggunakan [MIT License](LICENSE)

## 👨‍💻 Developer

Dibuat dengan ❤️ oleh NinjaTech AI

## 📞 Support

Jika ada pertanyaan atau butuh bantuan:
- Email: info@komunitas.com
- YouTube: [@kursibiru](https://youtube.com/@kursibiru)

## 🎯 Roadmap

- [ ] Integrasi payment gateway lainnya
- [ ] Sistem rating & review
- [ ] Fitur live streaming
- [ ] Mobile app (React Native)
- [ ] Advanced analytics
- [ ] Multi-language support
- [ ] Dark mode

## ⚠️ Disclaimer

Website ini dibuat untuk tujuan edukasi. Pastikan untuk melakukan security audit sebelum menggunakan di production environment.

---

**Made with ❤️ by NinjaTech AI**

**Don't forget to subscribe:** [kursibiru YouTube Channel](https://youtube.com/@kursibiru)