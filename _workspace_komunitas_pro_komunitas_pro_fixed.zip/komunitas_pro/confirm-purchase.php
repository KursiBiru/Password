<?php
session_start();
require_once 'config.php';
requireLogin();

$currentUser = getCurrentUser();
$conn = getDBConnection();

$purchase_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (!$purchase_id) {
    redirect('wallet.php');
}

// Ambil data pembelian
$stmt = $conn->prepare("
    SELECT p.*, po.title as product_title, po.user_id as seller_id, u.username as seller_name 
    FROM purchases p 
    JOIN posts po ON p.post_id = po.id 
    JOIN users u ON p.seller_id = u.id 
    WHERE p.id = ? AND p.buyer_id = ?
");
$stmt->execute([$purchase_id, $currentUser['id']]);
$purchase = $stmt->fetch();

if (!$purchase) {
    $_SESSION['error'] = 'Pembelian tidak ditemukan!';
    redirect('wallet.php');
}

$error = '';
$success = '';

// Proses konfirmasi
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $confirmation_type = sanitizeInput($_POST['confirmation_type']);
    $notes = sanitizeInput($_POST['notes']);
    
    if (empty($confirmation_type)) {
        $error = 'Pilih jenis konfirmasi!';
    } else {
        try {
            $conn->beginTransaction();
            
            // Simpan konfirmasi
            $stmt = $conn->prepare("
                INSERT INTO product_confirmations (purchase_id, confirmed_by, confirmation_type, status, notes) 
                VALUES (?, ?, ?, 'received', ?)
            ");
            $stmt->execute([$purchase_id, $currentUser['id'], 'buyer', $notes]);
            
            // Update status pembelian
            if ($confirmation_type === 'received') {
                $stmt = $conn->prepare("
                    UPDATE purchases 
                    SET confirmation_status = 'buyer_confirmed', 
                        buyer_confirmed_at = NOW() 
                    WHERE id = ?
                ");
                $stmt->execute([$purchase_id]);
                
                // Notifikasi ke penjual
                createNotification(
                    $purchase['seller_id'],
                    'purchase_confirmed',
                    'Produk Telah Diterima Pembeli',
                    "Pembeli telah mengkonfirmasi penerimaan produk: {$purchase['product_title']}",
                    $purchase['post_id']
                );
            }
            
            $conn->commit();
            $success = 'Konfirmasi berhasil dikirim!';
            
            // Refresh data
            $stmt = $conn->prepare("
                SELECT p.*, po.title as product_title, po.user_id as seller_id, u.username as seller_name 
                FROM purchases p 
                JOIN posts po ON p.post_id = po.id 
                JOIN users u ON p.seller_id = u.id 
                WHERE p.id = ? AND p.buyer_id = ?
            ");
            $stmt->execute([$purchase_id, $currentUser['id']]);
            $purchase = $stmt->fetch();
            
        } catch (Exception $e) {
            $conn->rollback();
            $error = 'Gagal menyimpan konfirmasi: ' . $e->getMessage();
        }
    }
}

$page_title = 'Konfirmasi Pembelian';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/unified.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<?php include 'includes/header.php'; ?>
<div class="container mt-4">
    <div class="row">
        <div class="col-md-8 offset-md-2">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1>Konfirmasi Pembelian</h1>
                <a href="wallet.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Kembali
                </a>
            </div>
            
            <?php if ($error): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <!-- Detail Pembelian -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Detail Pembelian</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-8">
                            <h6>Produk</h6>
                            <p class="mb-2"><strong><?php echo htmlspecialchars($purchase['product_title']); ?></strong></p>
                            
                            <h6>Penjual</h6>
                            <p class="mb-2"><?php echo htmlspecialchars($purchase['seller_name']); ?></p>
                            
                            <h6>Tanggal Pembelian</h6>
                            <p class="mb-2"><?php echo date('d M Y H:i', strtotime($purchase['created_at'])); ?></p>
                        </div>
                        <div class="col-md-4 text-md-end">
                            <h6>Total Pembayaran</h6>
                            <h3 class="text-success">Rp <?php echo number_format($purchase['amount'], 0, ',', '.'); ?></h3>
                            
                            <h6>Status</h6>
                            <span class="status-badge status-<?php echo $purchase['confirmation_status']; ?>">
                                <?php 
                                $status_labels = [
                                    'pending' => 'Menunggu Konfirmasi',
                                    'buyer_confirmed' => 'Menunggu Konfirmasi Penjual',
                                    'seller_confirmed' => 'Menunggu Konfirmasi Admin',
                                    'admin_confirmed' => 'Selesai',
                                    'completed' => 'Selesai'
                                ];
                                echo $status_labels[$purchase['confirmation_status']] ?? $purchase['confirmation_status'];
                                ?>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Form Konfirmasi -->
            <?php if ($purchase['confirmation_status'] === 'pending' || $purchase['confirmation_status'] === 'buyer_confirmed'): ?>
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Konfirmasi Penerimaan Produk</h5>
                    </div>
                    <div class="card-body">
                        <?php if ($purchase['confirmation_status'] === 'pending'): ?>
                            <form method="POST">
                                <div class="mb-3">
                                    <label class="form-label">Apakah Anda telah menerima produk ini?</label>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="confirmation_type" id="received" value="received" required>
                                        <label class="form-check-label" for="received">
                                            <i class="fas fa-check-circle text-success"></i> Ya, saya sudah menerima produk
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="confirmation_type" id="issue" value="issue" required>
                                        <label class="form-check-label" for="issue">
                                            <i class="fas fa-exclamation-triangle text-warning"></i> Ada masalah dengan produk
                                        </label>
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="notes" class="form-label">Catatan (opsional)</label>
                                    <textarea class="form-control" id="notes" name="notes" rows="3" 
                                              placeholder="Berikan catatan jika ada masalah atau informasi tambahan..."></textarea>
                                </div>
                                
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-paper-plane"></i> Kirim Konfirmasi
                                </button>
                            </form>
                        <?php else: ?>
                            <div class="alert alert-info">
                                <i class="fas fa-info-circle"></i> 
                                Anda sudah mengkonfirmasi penerimaan produk. Menunggu konfirmasi dari penjual.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php else: ?>
                <div class="card">
                    <div class="card-body text-center">
                        <i class="fas fa-check-circle text-success fa-3x mb-3"></i>
                        <h5>Pembelian Telah Selesai</h5>
                        <p class="text-muted">Terima kasih telah melakukan konfirmasi. Transaksi ini telah selesai.</p>
                    </div>
                </div>
            <?php endif; ?>
            
            <!-- Riwayat Konfirmasi -->
            <?php
            $stmt = $conn->prepare("
                SELECT pc.*, u.username 
                FROM product_confirmations pc 
                JOIN users u ON pc.confirmed_by = u.id 
                WHERE pc.purchase_id = ? 
                ORDER BY pc.created_at DESC
            ");
            $stmt->execute([$purchase_id]);
            $confirmations = $stmt->fetchAll();
            
            if (!empty($confirmations)):
            ?>
                <div class="card mt-4">
                    <div class="card-header">
                        <h5 class="mb-0">Riwayat Konfirmasi</h5>
                    </div>
                    <div class="card-body">
                        <?php foreach ($confirmations as $conf): ?>
                            <div class="d-flex justify-content-between align-items-start mb-3 pb-3 border-bottom">
                                <div>
                                    <strong><?php echo htmlspecialchars($conf['username']); ?></strong>
                                    <span class="badge bg-<?php echo $conf['confirmation_type'] === 'buyer' ? 'primary' : ($conf['confirmation_type'] === 'seller' ? 'success' : 'warning'); ?> ms-2">
                                        <?php echo $conf['confirmation_type'] === 'buyer' ? 'Pembeli' : ($conf['confirmation_type'] === 'seller' ? 'Penjual' : 'Admin'); ?>
                                    </span>
                                    <br>
                                    <small class="text-muted">
                                        <?php echo date('d M Y H:i', strtotime($conf['created_at'])); ?>
                                    </small>
                                    <?php if ($conf['notes']): ?>
                                        <br>
                                        <span class="text-muted"><?php echo htmlspecialchars($conf['notes']); ?></span>
                                    <?php endif; ?>
                                </div>
                                <span class="badge bg-<?php echo $conf['status'] === 'received' ? 'success' : ($conf['status'] === 'delivered' ? 'info' : 'warning'); ?>">
                                    <?php 
                                    $status_labels = [
                                        'received' => 'Diterima',
                                        'delivered' => 'Terkirim',
                                        'issue' => 'Ada Masalah',
                                        'cancel' => 'Dibatalkan'
                                    ];
                                    echo $status_labels[$conf['status']] ?? $conf['status'];
                                    ?>
                                </span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
<script src="assets/js/main.js"></script>
</body>
</html>