// ============================================
// Dark Mode JavaScript
// ============================================

// Check for saved dark mode preference
const darkModeEnabled = localStorage.getItem('darkMode') === 'enabled';

// Apply dark mode on page load
if (darkModeEnabled) {
    enableDarkMode();
}

// Dark mode toggle function
function toggleDarkMode() {
    const isDarkMode = document.body.classList.contains('dark-mode');
    
    if (isDarkMode) {
        disableDarkMode();
    } else {
        enableDarkMode();
    }
}

// Enable dark mode
function enableDarkMode() {
    document.body.classList.add('dark-mode');
    localStorage.setItem('darkMode', 'enabled');
    updateToggleIcon(true);
    
    // Add neon effects
    addNeonEffects();
}

// Disable dark mode
function disableDarkMode() {
    document.body.classList.remove('dark-mode');
    localStorage.setItem('darkMode', 'disabled');
    updateToggleIcon(false);
    
    // Remove neon effects
    removeNeonEffects();
}

// Update toggle button icon
function updateToggleIcon(isDarkMode) {
    const toggleBtn = document.querySelector('.dark-mode-toggle');
    if (toggleBtn) {
        toggleBtn.innerHTML = isDarkMode ? '<i class="fas fa-sun"></i>' : '<i class="fas fa-moon"></i>';
    }
}

// Add neon effects to certain elements
function addNeonEffects() {
    // Add pulse effect to important buttons
    const primaryButtons = document.querySelectorAll('.btn-primary');
    primaryButtons.forEach(btn => {
        btn.classList.add('neon-pulse');
    });
    
    // Add glow to headings
    const headings = document.querySelectorAll('h1, h2');
    headings.forEach(heading => {
        if (heading.classList.contains('logo') || heading.closest('.auth-header')) {
            heading.classList.add('glow-text');
        }
    });
}

// Remove neon effects
function removeNeonEffects() {
    const pulsing = document.querySelectorAll('.neon-pulse');
    pulsing.forEach(el => el.classList.remove('neon-pulse'));
    
    const glowing = document.querySelectorAll('.glow-text');
    glowing.forEach(el => el.classList.remove('glow-text'));
}

// Create dark mode toggle button
function createDarkModeToggle() {
    const toggleBtn = document.createElement('button');
    toggleBtn.className = 'dark-mode-toggle';
    toggleBtn.setAttribute('aria-label', 'Toggle Dark Mode');
    toggleBtn.setAttribute('title', 'Toggle Dark Mode');
    toggleBtn.innerHTML = darkModeEnabled ? '<i class="fas fa-sun"></i>' : '<i class="fas fa-moon"></i>';
    toggleBtn.onclick = toggleDarkMode;
    
    document.body.appendChild(toggleBtn);
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    // Create toggle button
    createDarkModeToggle();
    
    // Apply neon effects if dark mode is enabled
    if (darkModeEnabled) {
        addNeonEffects();
    }
    
    // Add keyboard shortcut (Ctrl/Cmd + D)
    document.addEventListener('keydown', function(e) {
        if ((e.ctrlKey || e.metaKey) && e.key === 'd') {
            e.preventDefault();
            toggleDarkMode();
        }
    });
});

// Smooth transition when toggling
document.body.style.transition = 'background-color 0.3s ease, color 0.3s ease';

// Add transition to all elements
const style = document.createElement('style');
style.textContent = `
    * {
        transition: background-color 0.3s ease, 
                    color 0.3s ease, 
                    border-color 0.3s ease,
                    box-shadow 0.3s ease !important;
    }
    
    img, video, iframe {
        transition: none !important;
    }
`;
document.head.appendChild(style);

// Export functions for use in other scripts
window.darkMode = {
    toggle: toggleDarkMode,
    enable: enableDarkMode,
    disable: disableDarkMode,
    isEnabled: () => document.body.classList.contains('dark-mode')
};

// Console message
console.log('%c🌙 Dark Mode Ready!', 'color: #b24bf3; font-size: 16px; font-weight: bold;');
console.log('%cPress Ctrl+D (or Cmd+D on Mac) to toggle dark mode', 'color: #b24bf3; font-size: 12px;');