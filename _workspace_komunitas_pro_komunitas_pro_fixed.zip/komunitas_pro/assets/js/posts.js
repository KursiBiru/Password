// ============================================
// Posts JavaScript
// ============================================

// Load more posts (infinite scroll)
let isLoading = false;
let currentPage = 1;

function loadMorePosts() {
    if (isLoading) return;
    
    const scrollPosition = window.innerHeight + window.scrollY;
    const threshold = document.body.offsetHeight - 500;
    
    if (scrollPosition >= threshold) {
        isLoading = true;
        currentPage++;
        
        // Fetch more posts
        fetch(`api/get-posts.php?page=${currentPage}`)
            .then(response => response.json())
            .then(data => {
                if (data.success && data.posts.length > 0) {
                    appendPosts(data.posts);
                }
                isLoading = false;
            })
            .catch(error => {
                console.error('Error loading posts:', error);
                isLoading = false;
            });
    }
}

function appendPosts(posts) {
    const feed = document.querySelector('.feed');
    
    posts.forEach(post => {
        const postCard = createPostCard(post);
        feed.appendChild(postCard);
    });
}

function createPostCard(post) {
    const div = document.createElement('div');
    div.className = 'post-card';
    div.setAttribute('data-post-id', post.id);
    
    let imagesHtml = '';
    if (post.images) {
        const images = JSON.parse(post.images);
        if (images && images.length > 0) {
            imagesHtml = '<div class="post-images">';
            images.forEach(img => {
                imagesHtml += `<img src="uploads/posts/${img}" alt="Post image">`;
            });
            imagesHtml += '</div>';
        }
    }
    
    let productInfoHtml = '';
    if (post.post_type === 'product') {
        productInfoHtml = `
            <div class="product-info">
                <span class="product-price">${formatCurrency(post.product_price)}</span>
                <span class="product-category">${post.product_category}</span>
                <span class="product-type">${post.product_type === 'digital' ? 'Digital' : 'Fisik'}</span>
            </div>
        `;
    }
    
    div.innerHTML = `
        <div class="post-header">
            <img src="uploads/profiles/${post.profile_photo}" alt="Profile" class="avatar">
            <div class="post-info">
                <h4><a href="profile.php?id=${post.user_id}">${post.full_name}</a></h4>
                <span class="post-time">${formatTime(post.created_at)}</span>
            </div>
        </div>
        
        <div class="post-content">
            <h3>${post.title}</h3>
            <p>${post.content}</p>
            ${productInfoHtml}
            ${imagesHtml}
        </div>
        
        <div class="post-stats">
            <span>${post.like_count} suka</span>
            <span>${post.comment_count} komentar</span>
            <span>${post.share_count} bagikan</span>
        </div>
        
        <div class="post-actions">
            <button class="btn-action ${post.user_liked ? 'active' : ''}" onclick="toggleLike(${post.id})">
                <i class="fas fa-heart"></i> Suka
            </button>
            <button class="btn-action" onclick="showComments(${post.id})">
                <i class="fas fa-comment"></i> Komentar
            </button>
            <button class="btn-action" onclick="sharePost(${post.id})">
                <i class="fas fa-share"></i> Bagikan
            </button>
            ${post.post_type === 'product' ? `
                <button class="btn-action btn-buy" onclick="buyProduct(${post.id})">
                    <i class="fas fa-shopping-cart"></i> Beli
                </button>
            ` : ''}
        </div>
        
        <div class="post-comments" id="comments-${post.id}" style="display: none;">
        </div>
    `;
    
    return div;
}

function formatCurrency(amount) {
    return 'Rp ' + parseFloat(amount).toLocaleString('id-ID');
}

// Enable infinite scroll
if (document.querySelector('.feed')) {
    window.addEventListener('scroll', loadMorePosts);
}