// ============================================
// Main JavaScript File
// ============================================

// CSRF Token
function getCSRFToken() {
    return document.querySelector('input[name="csrf_token"]')?.value || '';
}

// Toast Notification System
function showToast(title, message, type = 'info') {
    const container = document.getElementById('notificationToast');
    if (!container) return;
    
    const toast = document.createElement('div');
    toast.className = `toast-item toast-${type}`;
    toast.innerHTML = `
        <div style="display: flex; align-items: center; gap: 10px;">
            <i class="fas fa-${getToastIcon(type)}" style="font-size: 24px;"></i>
            <div>
                <strong>${title}</strong>
                <p style="margin: 5px 0 0 0; font-size: 14px;">${message}</p>
            </div>
        </div>
    `;
    
    container.appendChild(toast);
    
    // Play notification sound
    playNotificationSound();
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        toast.style.animation = 'slideOut 0.3s ease-out';
        setTimeout(() => toast.remove(), 300);
    }, 5000);
}

function getToastIcon(type) {
    const icons = {
        'success': 'check-circle',
        'error': 'exclamation-circle',
        'warning': 'exclamation-triangle',
        'info': 'info-circle'
    };
    return icons[type] || 'bell';
}

function playNotificationSound() {
    const audio = document.getElementById('notificationSound');
    if (audio) {
        audio.play().catch(e => console.log('Audio play failed:', e));
    }
}

// Real-time Notification Polling
let notificationInterval;

function startNotificationPolling() {
    // Check for new notifications every 10 seconds
    notificationInterval = setInterval(checkNewNotifications, 10000);
}

function stopNotificationPolling() {
    if (notificationInterval) {
        clearInterval(notificationInterval);
    }
}

async function checkNewNotifications() {
    try {
        const response = await fetch('api/get-notifications.php');
        const data = await response.json();
        
        if (data.success && data.notifications.length > 0) {
            // Update notification badge
            updateNotificationBadge(data.count);
            
            // Show toast for new notifications
            data.notifications.forEach(notif => {
                if (!isNotificationShown(notif.id)) {
                    showToast(notif.title, notif.message, 'info');
                    markNotificationAsShown(notif.id);
                }
            });
        }
    } catch (error) {
        console.error('Error checking notifications:', error);
    }
}

function updateNotificationBadge(count) {
    const badge = document.querySelector('.nav-link[href="notifications.php"] .badge');
    if (badge) {
        badge.textContent = count;
        badge.style.display = count > 0 ? 'block' : 'none';
    }
}

// Track shown notifications in session storage
function isNotificationShown(notifId) {
    const shown = JSON.parse(sessionStorage.getItem('shownNotifications') || '[]');
    return shown.includes(notifId);
}

function markNotificationAsShown(notifId) {
    const shown = JSON.parse(sessionStorage.getItem('shownNotifications') || '[]');
    shown.push(notifId);
    sessionStorage.setItem('shownNotifications', JSON.stringify(shown));
}

// Modal Functions
function openCreatePostModal(type = 'community') {
    const modal = document.getElementById('createPostModal');
    const postTypeInput = document.getElementById('post_type');
    const productFields = document.getElementById('productFields');
    const modalTitle = document.getElementById('modalTitle');
    
    if (modal) {
        modal.style.display = 'block';
        postTypeInput.value = type;
        
        if (type === 'product') {
            productFields.style.display = 'block';
            modalTitle.textContent = 'Jual Produk';
        } else {
            productFields.style.display = 'none';
            modalTitle.textContent = 'Buat Postingan';
        }
    }
}

function closeCreatePostModal() {
    const modal = document.getElementById('createPostModal');
    if (modal) {
        modal.style.display = 'none';
    }
}

// Product type change handler
document.getElementById('product_type')?.addEventListener('change', function() {
    const digitalFileGroup = document.getElementById('digitalFileGroup');
    if (digitalFileGroup) {
        digitalFileGroup.style.display = this.value === 'digital' ? 'block' : 'none';
    }
});

// Create Post Form Handler
document.getElementById('createPostForm')?.addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    
    try {
        const response = await fetch('api/create-post.php', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        if (data.success) {
            showToast('Berhasil', 'Postingan berhasil dibuat', 'success');
            closeCreatePostModal();
            setTimeout(() => location.reload(), 1000);
        } else {
            showToast('Error', data.message, 'error');
        }
    } catch (error) {
        showToast('Error', 'Terjadi kesalahan', 'error');
    }
});

// Toggle Like
async function toggleLike(postId) {
    try {
        const response = await fetch('api/toggle-like.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ post_id: postId })
        });
        
        const data = await response.json();
        
        if (data.success) {
            const postCard = document.querySelector(`[data-post-id="${postId}"]`);
            const likeBtn = postCard.querySelector('.btn-action');
            const likeCount = postCard.querySelector('.post-stats span:first-child');
            
            if (data.liked) {
                likeBtn.classList.add('active');
            } else {
                likeBtn.classList.remove('active');
            }
            
            likeCount.textContent = `${data.like_count} suka`;
        }
    } catch (error) {
        console.error('Error toggling like:', error);
    }
}

// Show Comments
async function showComments(postId) {
    const commentsDiv = document.getElementById(`comments-${postId}`);
    
    if (commentsDiv.style.display === 'block') {
        commentsDiv.style.display = 'none';
        return;
    }
    
    try {
        const response = await fetch(`api/get-comments.php?post_id=${postId}`);
        const data = await response.json();
        
        if (data.success) {
            let html = '<div class="comments-section">';
            html += '<div class="comment-form">';
            html += '<textarea class="form-control" id="comment-input-' + postId + '" placeholder="Tulis komentar..."></textarea>';
            html += '<button class="btn btn-primary btn-sm" onclick="addComment(' + postId + ')">Kirim</button>';
            html += '</div>';
            html += '<div class="comments-list">';
            
            data.comments.forEach(comment => {
                html += `
                    <div class="comment-item">
                        <img src="uploads/profiles/${comment.profile_photo}" alt="Profile" class="avatar-small">
                        <div class="comment-content">
                            <strong>${comment.full_name}</strong>
                            <p>${comment.content}</p>
                            <span class="comment-time">${formatTime(comment.created_at)}</span>
                        </div>
                    </div>
                `;
            });
            
            html += '</div></div>';
            commentsDiv.innerHTML = html;
            commentsDiv.style.display = 'block';
        }
    } catch (error) {
        console.error('Error loading comments:', error);
    }
}

// Add Comment
async function addComment(postId) {
    const input = document.getElementById(`comment-input-${postId}`);
    const content = input.value.trim();
    
    if (!content) return;
    
    try {
        const response = await fetch('api/add-comment.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                post_id: postId,
                content: content
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            input.value = '';
            showComments(postId); // Reload comments
            showToast('Berhasil', 'Komentar berhasil ditambahkan', 'success');
        }
    } catch (error) {
        console.error('Error adding comment:', error);
    }
}

// Share Post
function sharePost(postId) {
    const url = `${window.location.origin}/post.php?id=${postId}`;
    
    if (navigator.share) {
        navigator.share({
            title: 'Bagikan Postingan',
            url: url
        }).catch(err => console.log('Error sharing:', err));
    } else {
        // Fallback: copy to clipboard
        navigator.clipboard.writeText(url).then(() => {
            showToast('Berhasil', 'Link berhasil disalin', 'success');
        });
    }
}

// Buy Product
function buyProduct(postId) {
    if (confirm('Apakah Anda yakin ingin membeli produk ini?')) {
        window.location.href = `purchase.php?post_id=${postId}`;
    }
}

// Delete Post
async function deletePost(postId) {
    if (!confirm('Apakah Anda yakin ingin menghapus postingan ini?')) {
        return;
    }
    
    try {
        const response = await fetch('api/delete-post.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ post_id: postId })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showToast('Berhasil', 'Postingan berhasil dihapus', 'success');
            setTimeout(() => location.reload(), 1000);
        } else {
            showToast('Error', data.message, 'error');
        }
    } catch (error) {
        showToast('Error', 'Terjadi kesalahan', 'error');
    }
}

// Toggle Post Menu
function togglePostMenu(postId) {
    const menu = document.getElementById(`menu-${postId}`);
    if (menu) {
        menu.classList.toggle('show');
    }
}

// Format Time
function formatTime(datetime) {
    const date = new Date(datetime);
    const now = new Date();
    const diff = now - date;
    
    if (diff < 60000) return 'Baru saja';
    if (diff < 3600000) return Math.floor(diff / 60000) + ' menit lalu';
    if (diff < 86400000) return Math.floor(diff / 3600000) + ' jam lalu';
    if (diff < 604800000) return Math.floor(diff / 86400000) + ' hari yang lalu';
    
    return date.toLocaleDateString('id-ID', { 
        day: 'numeric', 
        month: 'short', 
        year: 'numeric' 
    });
}

// Close modal when clicking outside
window.onclick = function(event) {
    const modals = document.querySelectorAll('.modal');
    modals.forEach(modal => {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    // Start notification polling if user is logged in
    if (document.querySelector('.main-header')) {
        startNotificationPolling();
    }
    
    // Close dropdowns when clicking outside
    document.addEventListener('click', function(e) {
        if (!e.target.closest('.post-menu')) {
            document.querySelectorAll('.post-menu-dropdown').forEach(menu => {
                menu.classList.remove('show');
            });
        }
    });
});

// Clean up on page unload
window.addEventListener('beforeunload', function() {
    stopNotificationPolling();
});