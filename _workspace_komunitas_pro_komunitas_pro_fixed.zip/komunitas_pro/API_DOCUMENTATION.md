# API Documentation - Komunitas Marketplace

## Base URL
```
http://yourdomain.com/api/
```

## Authentication
All API endpoints require user authentication via session. Include session cookie in requests.

## Response Format
All responses are in JSON format:
```json
{
    "success": true|false,
    "message": "Response message",
    "data": {}
}
```

## Error Codes
- `200` - Success
- `400` - Bad Request
- `403` - Forbidden
- `404` - Not Found
- `405` - Method Not Allowed
- `500` - Internal Server Error

---

## Posts API

### Create Post
Create a new post (community or product).

**Endpoint:** `POST /api/create-post.php`

**Parameters:**
```json
{
    "csrf_token": "string (required)",
    "title": "string (required)",
    "content": "string (required)",
    "post_type": "community|product (required)",
    "language": "id|en (optional, default: id)",
    "product_price": "number (required if post_type=product)",
    "product_category": "string (required if post_type=product)",
    "product_type": "physical|digital (required if post_type=product)",
    "images[]": "file (optional, multiple)",
    "product_file": "file (optional, for digital products)"
}
```

**Response:**
```json
{
    "success": true,
    "message": "Post created successfully"
}
```

### Get Posts
Retrieve posts with pagination and filters.

**Endpoint:** `GET /api/get-posts.php`

**Parameters:**
- `page` - Page number (default: 1)
- `type` - Post type: all|community|product (default: all)
- `lang` - Language: all|id|en (default: all)
- `category` - Product category (optional)

**Response:**
```json
{
    "success": true,
    "posts": [
        {
            "id": 1,
            "user_id": 1,
            "username": "john_doe",
            "full_name": "John Doe",
            "profile_photo": "avatar.jpg",
            "title": "Post Title",
            "content": "Post content...",
            "post_type": "community",
            "images": "[&quot;image1.jpg&quot;, &quot;image2.jpg&quot;]",
            "like_count": 10,
            "comment_count": 5,
            "share_count": 2,
            "user_liked": 1,
            "created_at": "2025-01-19 10:00:00"
        }
    ]
}
```

### Delete Post
Delete a post (owner or admin only).

**Endpoint:** `POST /api/delete-post.php`

**Parameters:**
```json
{
    "post_id": "number (required)"
}
```

**Response:**
```json
{
    "success": true,
    "message": "Post deleted successfully"
}
```

---

## Likes API

### Toggle Like
Like or unlike a post.

**Endpoint:** `POST /api/toggle-like.php`

**Parameters:**
```json
{
    "post_id": "number (required)"
}
```

**Response:**
```json
{
    "success": true,
    "liked": true,
    "like_count": 11
}
```

---

## Comments API

### Get Comments
Get all comments for a post.

**Endpoint:** `GET /api/get-comments.php`

**Parameters:**
- `post_id` - Post ID (required)

**Response:**
```json
{
    "success": true,
    "comments": [
        {
            "id": 1,
            "post_id": 1,
            "user_id": 2,
            "username": "jane_doe",
            "full_name": "Jane Doe",
            "profile_photo": "avatar.jpg",
            "content": "Great post!",
            "parent_id": null,
            "created_at": "2025-01-19 10:05:00"
        }
    ]
}
```

### Add Comment
Add a comment to a post.

**Endpoint:** `POST /api/add-comment.php`

**Parameters:**
```json
{
    "post_id": "number (required)",
    "content": "string (required)",
    "parent_id": "number (optional, for replies)"
}
```

**Response:**
```json
{
    "success": true,
    "message": "Comment added"
}
```

---

## Messages API

### Get Messages
Get messages with a specific user.

**Endpoint:** `GET /api/get-messages.php`

**Parameters:**
- `partner_id` - User ID to chat with (required)

**Response:**
```json
{
    "success": true,
    "messages": [
        {
            "id": 1,
            "sender_id": 1,
            "receiver_id": 2,
            "message": "Hello!",
            "is_read": 1,
            "username": "john_doe",
            "full_name": "John Doe",
            "profile_photo": "avatar.jpg",
            "created_at": "2025-01-19 10:00:00"
        }
    ]
}
```

### Send Message
Send a message to a user.

**Endpoint:** `POST /api/send-message.php`

**Parameters:**
```json
{
    "csrf_token": "string (required)",
    "receiver_id": "number (required)",
    "message": "string (required)"
}
```

**Response:**
```json
{
    "success": true,
    "message": "Message sent"
}
```

### Search Users
Search for users to chat with.

**Endpoint:** `GET /api/search-users.php`

**Parameters:**
- `q` - Search query (required, min 2 characters)

**Response:**
```json
{
    "success": true,
    "users": [
        {
            "id": 1,
            "username": "john_doe",
            "full_name": "John Doe",
            "profile_photo": "avatar.jpg"
        }
    ]
}
```

---

## Notifications API

### Get Notifications
Get unread notifications for current user.

**Endpoint:** `GET /api/get-notifications.php`

**Response:**
```json
{
    "success": true,
    "notifications": [
        {
            "id": 1,
            "user_id": 1,
            "type": "like",
            "title": "New Like",
            "message": "John liked your post",
            "link": "post.php?id=1",
            "is_read": 0,
            "created_at": "2025-01-19 10:00:00"
        }
    ],
    "count": 5
}
```

### Mark Notification as Read
Mark a notification as read.

**Endpoint:** `POST /api/mark-notification-read.php`

**Parameters:**
```json
{
    "notification_id": "number (required)"
}
```

**Response:**
```json
{
    "success": true
}
```

---

## Data Provider API

### Get Data Provider Endpoints
Get available endpoints for a data provider.

**Endpoint:** `GET /api/get-data-provider-endpoints.php`

**Parameters:**
- `service_name` - Provider name: linkedin|twitter|zillow|amazon|yahoo_finance|active_jobs

**Response:**
```json
{
    "success": true,
    "endpoints": {
        "person": "Get person profile",
        "company": "Get company profile"
    }
}
```

### Execute Data Provider Call
Execute a call to a data provider endpoint.

**Endpoint:** `POST /api/execute-data-provider-call.php`

**Parameters:**
```json
{
    "service_name": "string (required)",
    "route": "string (required)",
    "params": "object (required)"
}
```

**Example:**
```json
{
    "service_name": "linkedin",
    "route": "person",
    "params": {
        "link": "https://www.linkedin.com/in/johndoe/"
    }
}
```

**Response:**
```json
{
    "success": true,
    "data": {
        // Provider-specific response
    }
}
```

---

## Rate Limiting

Currently, there is no rate limiting implemented. However, it's recommended to:
- Limit requests to 100 per minute per user
- Implement exponential backoff for failed requests
- Cache responses when possible

## Best Practices

1. **Always include CSRF token** in POST requests
2. **Handle errors gracefully** - check success field
3. **Validate input** before sending requests
4. **Use pagination** for large datasets
5. **Cache responses** when appropriate
6. **Implement retry logic** for failed requests
7. **Monitor API usage** to detect issues

## Example Usage

### JavaScript (Fetch API)
```javascript
// Get posts
fetch('/api/get-posts.php?page=1&type=all')
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            console.log(data.posts);
        }
    });

// Create post
const formData = new FormData();
formData.append('csrf_token', csrfToken);
formData.append('title', 'My Post');
formData.append('content', 'Post content');
formData.append('post_type', 'community');

fetch('/api/create-post.php', {
    method: 'POST',
    body: formData
})
.then(response => response.json())
.then(data => {
    if (data.success) {
        console.log('Post created!');
    }
});

// Toggle like
fetch('/api/toggle-like.php', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
    },
    body: JSON.stringify({
        post_id: 1
    })
})
.then(response => response.json())
.then(data => {
    if (data.success) {
        console.log('Liked:', data.liked);
        console.log('Like count:', data.like_count);
    }
});
```

### PHP (cURL)
```php
// Get posts
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'http://yourdomain.com/api/get-posts.php?page=1');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);
$data = json_decode($response, true);

// Create post
$postData = [
    'csrf_token' => $csrfToken,
    'title' => 'My Post',
    'content' => 'Post content',
    'post_type' => 'community'
];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'http://yourdomain.com/api/create-post.php');
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);
$data = json_decode($response, true);
```

## Webhooks (Future)

Planned webhook support for:
- New post created
- New comment added
- New transaction
- Payment received
- User registered

## Versioning

Current version: v1.0

Future versions will be accessible via:
```
/api/v2/endpoint.php
```

## Support

For API support:
- Email: api@komunitas.com
- Documentation: This file
- GitHub Issues: https://github.com/yourusername/komunitas-marketplace/issues

---

**Last Updated:** 2025-01-19

**API Version:** 1.0.0