<?php
require_once 'config.php';
requireLogin();

$currentUser = getCurrentUser();
$userId = $_GET['id'] ?? $currentUser['id'];

$conn = getDBConnection();
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$userId]);
$user = $stmt->fetch();

if (!$user) {
    redirect('index.php');
}

$isOwnProfile = ($userId == $currentUser['id']);

// Get user's posts
$stmt = $conn->prepare("SELECT p.*, 
    (SELECT COUNT(*) FROM likes WHERE post_id = p.id) as like_count,
    (SELECT COUNT(*) FROM comments WHERE post_id = p.id) as comment_count,
    (SELECT COUNT(*) FROM shares WHERE post_id = p.id) as share_count
    FROM posts p 
    WHERE p.user_id = ? AND p.status = 'active' 
    ORDER BY p.created_at DESC");
$stmt->execute([$userId]);
$posts = $stmt->fetchAll();

// Get statistics
$stmt = $conn->prepare("SELECT 
    (SELECT COUNT(*) FROM posts WHERE user_id = ? AND status = 'active') as total_posts,
    (SELECT COUNT(*) FROM likes l JOIN posts p ON l.post_id = p.id WHERE p.user_id = ?) as total_likes,
    (SELECT COUNT(*) FROM purchases WHERE seller_id = ?) as total_sales");
$stmt->execute([$userId, $userId, $userId]);
$stats = $stmt->fetch();

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $isOwnProfile) {
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        setFlashMessage('danger', 'Invalid CSRF token');
    } else {
        $full_name = sanitizeInput($_POST['full_name']);
        $bio = sanitizeInput($_POST['bio']);
        $phone = sanitizeInput($_POST['phone']);
        $language = sanitizeInput($_POST['language']);
        
        $updateQuery = "UPDATE users SET full_name = ?, bio = ?, phone = ?, language = ? WHERE id = ?";
        $updateParams = [$full_name, $bio, $phone, $language, $currentUser['id']];
        
        // Handle profile photo upload
        if (isset($_FILES['profile_photo']) && $_FILES['profile_photo']['error'] === UPLOAD_ERR_OK) {
            $upload = uploadFile($_FILES['profile_photo'], 'profile');
            if ($upload['success']) {
                // Delete old photo if not default
                if ($currentUser['profile_photo'] !== 'default-avatar.png') {
                    deleteFile('profiles/' . $currentUser['profile_photo']);
                }
                $updateQuery = "UPDATE users SET full_name = ?, bio = ?, phone = ?, language = ?, profile_photo = ? WHERE id = ?";
                $updateParams = [$full_name, $bio, $phone, $language, $upload['filename'], $currentUser['id']];
            }
        }
        
        $stmt = $conn->prepare($updateQuery);
        if ($stmt->execute($updateParams)) {
            setFlashMessage('success', 'Profil berhasil diperbarui');
            redirect('profile.php?id=' . $currentUser['id']);
        } else {
            setFlashMessage('danger', 'Gagal memperbarui profil');
        }
    }
}

$flashMessage = getFlashMessage();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($user['full_name']); ?> - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/unified.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <div class="container">
        <?php if ($flashMessage): ?>
            <div class="alert alert-<?php echo $flashMessage['type']; ?>">
                <?php echo $flashMessage['message']; ?>
            </div>
        <?php endif; ?>
        
        <div class="profile-container">
            <!-- Profile Header -->
            <div class="profile-header">
                <div class="profile-cover"></div>
                <div class="profile-info">
                    <img src="uploads/profiles/<?php echo htmlspecialchars($user['profile_photo']); ?>" alt="Profile" class="profile-avatar">
                    <div class="profile-details">
                        <h1><?php echo htmlspecialchars($user['full_name']); ?></h1>
                        <p class="username">@<?php echo htmlspecialchars($user['username']); ?></p>
                        <?php if (!empty($user['bio'])): ?>
                            <p class="bio"><?php echo nl2br(htmlspecialchars($user['bio'])); ?></p>
                        <?php endif; ?>
                        <div class="profile-meta">
                            <span><i class="fas fa-calendar"></i> Bergabung <?php echo date('M Y', strtotime($user['created_at'])); ?></span>
                            <?php if (!empty($user['phone'])): ?>
                                <span><i class="fas fa-phone"></i> <?php echo htmlspecialchars($user['phone']); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php if ($isOwnProfile): ?>
                        <button class="btn btn-primary" onclick="openEditProfileModal()">
                            <i class="fas fa-edit"></i> Edit Profil
                        </button>
                    <?php else: ?>
                        <button class="btn btn-primary" onclick="startChat(<?php echo $userId; ?>)">
                            <i class="fas fa-comment"></i> Kirim Pesan
                        </button>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Profile Stats -->
            <div class="profile-stats">
                <div class="stat-item">
                    <span class="stat-value"><?php echo $stats['total_posts']; ?></span>
                    <span class="stat-label">Postingan</span>
                </div>
                <div class="stat-item">
                    <span class="stat-value"><?php echo $stats['total_likes']; ?></span>
                    <span class="stat-label">Suka</span>
                </div>
                <div class="stat-item">
                    <span class="stat-value"><?php echo $stats['total_sales']; ?></span>
                    <span class="stat-label">Penjualan</span>
                </div>
                <?php if ($isOwnProfile): ?>
                <div class="stat-item">
                    <span class="stat-value"><?php echo formatCurrency($user['wallet_balance']); ?></span>
                    <span class="stat-label">Saldo</span>
                </div>
                <?php endif; ?>
            </div>
            
            <!-- Profile Content -->
            <div class="profile-content">
                <div class="profile-tabs">
                    <button class="tab-btn active" onclick="showTab('posts')">Postingan</button>
                    <button class="tab-btn" onclick="showTab('products')">Produk</button>
                </div>
                
                <div id="posts-tab" class="tab-content active">
                    <?php if (empty($posts)): ?>
                        <div class="empty-state">
                            <i class="fas fa-inbox"></i>
                            <p>Belum ada postingan</p>
                        </div>
                    <?php else: ?>
                        <div class="posts-grid">
                            <?php foreach ($posts as $post): ?>
                                <div class="post-card-mini">
                                    <a href="post.php?id=<?php echo $post['id']; ?>">
                                        <?php if (!empty($post['images'])): ?>
                                            <?php $images = json_decode($post['images'], true); ?>
                                            <?php if (is_array($images) && count($images) > 0): ?>
                                                <img src="uploads/posts/<?php echo htmlspecialchars($images[0]); ?>" alt="Post">
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        <div class="post-card-content">
                                            <h4><?php echo htmlspecialchars($post['title']); ?></h4>
                                            <div class="post-card-stats">
                                                <span><i class="fas fa-heart"></i> <?php echo $post['like_count']; ?></span>
                                                <span><i class="fas fa-comment"></i> <?php echo $post['comment_count']; ?></span>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
                
                <div id="products-tab" class="tab-content">
                    <?php
                    $productPosts = array_filter($posts, function($post) {
                        return $post['post_type'] === 'product';
                    });
                    ?>
                    <?php if (empty($productPosts)): ?>
                        <div class="empty-state">
                            <i class="fas fa-shopping-bag"></i>
                            <p>Belum ada produk</p>
                        </div>
                    <?php else: ?>
                        <div class="products-grid">
                            <?php foreach ($productPosts as $product): ?>
                                <div class="product-card">
                                    <a href="post.php?id=<?php echo $product['id']; ?>">
                                        <?php if (!empty($product['images'])): ?>
                                            <?php $images = json_decode($product['images'], true); ?>
                                            <?php if (is_array($images) && count($images) > 0): ?>
                                                <img src="uploads/posts/<?php echo htmlspecialchars($images[0]); ?>" alt="Product">
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        <div class="product-card-content">
                                            <h4><?php echo htmlspecialchars($product['title']); ?></h4>
                                            <p class="product-price"><?php echo formatCurrency($product['product_price']); ?></p>
                                            <span class="product-category"><?php echo htmlspecialchars($product['product_category']); ?></span>
                                        </div>
                                    </a>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Edit Profile Modal -->
    <?php if ($isOwnProfile): ?>
    <div id="editProfileModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeEditProfileModal()">&times;</span>
            <h2>Edit Profil</h2>
            <form method="POST" action="" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                
                <div class="form-group">
                    <label for="profile_photo">Foto Profil</label>
                    <input type="file" id="profile_photo" name="profile_photo" class="form-control" accept="image/*">
                </div>
                
                <div class="form-group">
                    <label for="full_name">Nama Lengkap</label>
                    <input type="text" id="full_name" name="full_name" class="form-control" value="<?php echo htmlspecialchars($user['full_name']); ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="bio">Bio</label>
                    <textarea id="bio" name="bio" class="form-control" rows="3"><?php echo htmlspecialchars($user['bio'] ?? ''); ?></textarea>
                </div>
                
                <div class="form-group">
                    <label for="phone">Nomor Telepon</label>
                    <input type="tel" id="phone" name="phone" class="form-control" value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>">
                </div>
                
                <div class="form-group">
                    <label for="language">Bahasa</label>
                    <select id="language" name="language" class="form-control">
                        <option value="id" <?php echo $user['language'] === 'id' ? 'selected' : ''; ?>>Indonesia</option>
                        <option value="en" <?php echo $user['language'] === 'en' ? 'selected' : ''; ?>>English</option>
                    </select>
                </div>
                
                <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
            </form>
        </div>
    </div>
    <?php endif; ?>
    
    <?php include 'includes/footer.php'; ?>
    
    <script src="assets/js/main.js"></script>
    <script>
        function showTab(tabName) {
            const tabs = document.querySelectorAll('.tab-content');
            const buttons = document.querySelectorAll('.tab-btn');
            
            tabs.forEach(tab => tab.classList.remove('active'));
            buttons.forEach(btn => btn.classList.remove('active'));
            
            document.getElementById(tabName + '-tab').classList.add('active');
            event.target.classList.add('active');
        }
        
        function openEditProfileModal() {
            document.getElementById('editProfileModal').style.display = 'block';
        }
        
        function closeEditProfileModal() {
            document.getElementById('editProfileModal').style.display = 'none';
        }
        
        function startChat(userId) {
            window.location.href = 'chat.php?user=' + userId;
        }
    </script>
</body>
</html>