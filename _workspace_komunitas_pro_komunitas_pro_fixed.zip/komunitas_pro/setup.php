<?php
/**
 * Setup Script - Komunitas Marketplace
 * 
 * Script ini akan membuat folder-folder yang diperlukan
 * dan melakukan setup awal
 */

echo "===========================================\n";
echo "Setup Script - Komunitas Marketplace\n";
echo "===========================================\n\n";

// Folders to create
$folders = [
    'uploads',
    'uploads/profiles',
    'uploads/posts',
    'uploads/products',
    'uploads/proofs',
    'assets',
    'assets/css',
    'assets/js',
    'assets/sounds',
    'api',
    'admin',
    'admin/includes',
    'includes'
];

echo "Creating folders...\n";
foreach ($folders as $folder) {
    if (!is_dir($folder)) {
        if (mkdir($folder, 0755, true)) {
            echo "✓ Created: $folder\n";
        } else {
            echo "✗ Failed to create: $folder\n";
        }
    } else {
        echo "- Already exists: $folder\n";
    }
}

echo "\n";

// Create default avatar placeholder
$defaultAvatar = 'uploads/profiles/default-avatar.png';
if (!file_exists($defaultAvatar)) {
    echo "Creating default avatar placeholder...\n";
    
    // Create a simple colored square as placeholder
    $img = imagecreatetruecolor(200, 200);
    $bgColor = imagecolorallocate($img, 52, 152, 219); // Blue color
    imagefill($img, 0, 0, $bgColor);
    
    // Add text
    $textColor = imagecolorallocate($img, 255, 255, 255);
    $text = "USER";
    imagestring($img, 5, 75, 90, $text, $textColor);
    
    if (imagepng($img, $defaultAvatar)) {
        echo "✓ Created default avatar\n";
    } else {
        echo "✗ Failed to create default avatar\n";
    }
    imagedestroy($img);
} else {
    echo "- Default avatar already exists\n";
}

echo "\n";

// Create .htaccess for uploads folder
$uploadsHtaccess = 'uploads/.htaccess';
if (!file_exists($uploadsHtaccess)) {
    echo "Creating uploads .htaccess...\n";
    $htaccessContent = "# Prevent PHP execution in uploads folder\n";
    $htaccessContent .= "<FilesMatch &quot;\\.php$&quot;>\n";
    $htaccessContent .= "    Order allow,deny\n";
    $htaccessContent .= "    Deny from all\n";
    $htaccessContent .= "</FilesMatch>\n";
    
    if (file_put_contents($uploadsHtaccess, $htaccessContent)) {
        echo "✓ Created uploads .htaccess\n";
    } else {
        echo "✗ Failed to create uploads .htaccess\n";
    }
} else {
    echo "- Uploads .htaccess already exists\n";
}

echo "\n";

// Check PHP extensions
echo "Checking PHP extensions...\n";
$requiredExtensions = ['pdo', 'pdo_mysql', 'gd', 'json', 'mbstring'];
$missingExtensions = [];

foreach ($requiredExtensions as $ext) {
    if (extension_loaded($ext)) {
        echo "✓ $ext is installed\n";
    } else {
        echo "✗ $ext is NOT installed\n";
        $missingExtensions[] = $ext;
    }
}

echo "\n";

// Check permissions
echo "Checking folder permissions...\n";
$checkFolders = ['uploads', 'uploads/profiles', 'uploads/posts', 'uploads/products', 'uploads/proofs'];
foreach ($checkFolders as $folder) {
    if (is_writable($folder)) {
        echo "✓ $folder is writable\n";
    } else {
        echo "✗ $folder is NOT writable (run: chmod -R 755 $folder)\n";
    }
}

echo "\n";
echo "===========================================\n";
echo "Setup Summary\n";
echo "===========================================\n\n";

if (empty($missingExtensions)) {
    echo "✓ All required PHP extensions are installed\n";
} else {
    echo "✗ Missing PHP extensions: " . implode(', ', $missingExtensions) . "\n";
    echo "  Please install missing extensions before proceeding\n";
}

echo "\n";
echo "Next Steps:\n";
echo "1. Import database.sql to MySQL\n";
echo "2. Edit config.php with your database credentials\n";
echo "3. Update SITE_URL in config.php\n";
echo "4. Access your website in browser\n";
echo "5. Login with admin/admin123\n";
echo "6. Change admin password immediately!\n";
echo "\n";
echo "For detailed instructions, see INSTALL.md\n";
echo "\n";
echo "===========================================\n";
echo "Setup Complete!\n";
echo "===========================================\n";