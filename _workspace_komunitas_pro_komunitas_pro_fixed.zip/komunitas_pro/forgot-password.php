<?php
session_start();
require_once 'config.php';

if (isset($_SESSION['user_id'])) {
    redirect('index.php');
}

$conn = getDBConnection();
$error = '';
$success = '';

// Proses permintaan reset password
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = sanitizeInput($_POST['email']);
    
    if (empty($email)) {
        $error = 'Email wajib diisi!';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Format email tidak valid!';
    } else {
        // Cek apakah email ada di database
        $stmt = $conn->prepare("SELECT id, username FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        
        if ($user) {
            // Generate token reset password
            $token = bin2hex(random_bytes(32));
            $expires_at = date('Y-m-d H:i:s', strtotime('+1 hour'));
            
            // Simpan token ke database
            $stmt = $conn->prepare("INSERT INTO password_resets (user_id, token, expires_at) VALUES (?, ?, ?)");
            $stmt->execute([$user['id'], $token, $expires_at]);
            
            // Kirim email (simulasi)
            $reset_link = SITE_URL . "/reset-password.php?token=" . $token;
            
            // Di production, gunakan PHPMailer atau library email lainnya
            // Untuk sekarang, kita tampilkan link reset di halaman
            
            $success = "Link reset password telah dikirim ke email Anda. <a href='$reset_link'>Klik di sini untuk reset password</a> (Link ini hanya berlaku 1 jam)";
            
            // Simpan pesan untuk ditampilkan di halaman login
            $_SESSION['reset_message'] = 'Link reset password telah dikirim ke email Anda.';
            
        } else {
            $error = 'Email tidak terdaftar!';
        }
    }
}

$page_title = 'Lupa Password';
//include 'includes/header.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/unified.css">
    <link rel="stylesheet" href="assets/css/dark-mode.css">
</head>
<body class="auth-page">
<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header text-center">
                    <h4>Lupa Password</h4>
                </div>
                <div class="card-body">
                    <?php if ($error): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                    <?php endif; ?>
                    
                    <?php if ($success): ?>
                        <div class="alert alert-success"><?php echo $success; ?></div>
                    <?php else: ?>
                        <p class="text-center mb-4">Masukkan email Anda dan kami akan mengirimkan link untuk mereset password Anda.</p>
                        
                        <form method="POST">
                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                            
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary">Kirim Link Reset</button>
                            </div>
                        </form>
                        
                        <div class="text-center mt-3">
                            <p>Ingat password Anda? <a href="login.php">Login di sini</a></p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php //include 'includes/footer.php'; ?>
<script src="assets/js/dark-mode.js"></script>
</body>
</html>