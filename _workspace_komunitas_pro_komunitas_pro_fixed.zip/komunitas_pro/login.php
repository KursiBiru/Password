<?php
require_once 'config.php';

// Redirect if already logged in
if (isLoggedIn()) {
    redirect('index.php');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid CSRF token';
    //} elseif (!validateCaptcha($_POST['captcha'] ?? '')) {
    //    $error = 'Invalid captcha code';
    } else {
        $username = sanitizeInput($_POST['username']);
        $password = $_POST['password'];
        
        $conn = getDBConnection();
        $stmt = $conn->prepare("SELECT * FROM users WHERE (username = ? OR email = ?) AND is_banned = 0");
        $stmt->execute([$username, $username]);
        $user = $stmt->fetch();
        
        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['is_admin'] = $user['is_admin'];
            
            // Update last login
            $stmt = $conn->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
            $stmt->execute([$user['id']]);
            
            if ($user['is_admin']) {
                redirect('admin/index.php');
            } else {
                redirect('index.php');
            }
        } else {
            $error = 'Username atau password salah';
        }
    }
}

$csrfToken = generateCSRFToken();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/unified.css">
    <link rel="stylesheet" href="assets/css/dark-mode.css">
</head>
<body class="auth-page">
    <div class="auth-container">
        <div class="auth-box">
            <div class="auth-header">
                <h1><?php echo SITE_NAME; ?></h1>
                <p>Masuk ke akun Anda</p>
            </div>
            
            <?php if ($error): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <form method="POST" action="" class="auth-form">
                <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
                
                <div class="form-group">
                    <label for="username">Username atau Email</label>
                    <input type="text" id="username" name="username" required class="form-control">
                </div>
                
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required class="form-control">
                </div>
                
                <div class="form-group">
                    <label for="captcha">Kode Captcha</label>
                    <div class="captcha-container">
                        <img src="captcha.php" alt="Captcha" id="captcha-image" class="captcha-image">
                        <button type="button" onclick="refreshCaptcha()" class="btn-refresh">↻</button>
                    </div>
                    <input type="text" id="captcha" name="captcha" required class="form-control" placeholder="Masukkan kode di atas">
                </div>
                
                <button type="submit" class="btn btn-primary btn-block">Masuk</button>
            </form>
            
            <div class="auth-footer">
                <p>Belum punya akun? <a href="register.php">Daftar sekarang</a></p>
                <p><a href="forgot-password.php">Lupa password?</a></p>
            </div>
            
            <div class="youtube-suggestion">
                <p>💡 Ingin belajar lebih banyak? Subscribe YouTube <a href="https://youtube.com/@kursibiru" target="_blank"><strong>kursibiru</strong></a></p>
            </div>
        </div>
    </div>
    
    <script>
        function refreshCaptcha() {
            document.getElementById('captcha-image').src = 'captcha.php?' + Date.now();
        }
    </script>
    <script src="assets/js/dark-mode.js"></script>
</body>
</html>