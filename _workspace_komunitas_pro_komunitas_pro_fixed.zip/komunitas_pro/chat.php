<?php
require_once 'config.php';
requireLogin();

$user = getCurrentUser();
$conn = getDBConnection();

// Get chat partner if specified
$chatPartnerId = $_GET['user'] ?? null;
$chatPartner = null;

if ($chatPartnerId) {
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$chatPartnerId]);
    $chatPartner = $stmt->fetch();
}

// Get all conversations
$stmt = $conn->prepare("
    SELECT DISTINCT 
        CASE 
            WHEN m.sender_id = ? THEN m.receiver_id 
            ELSE m.sender_id 
        END as partner_id,
        u.username, u.full_name, u.profile_photo,
        (SELECT message FROM messages 
         WHERE (sender_id = ? AND receiver_id = partner_id) 
            OR (sender_id = partner_id AND receiver_id = ?)
         ORDER BY created_at DESC LIMIT 1) as last_message,
        (SELECT created_at FROM messages 
         WHERE (sender_id = ? AND receiver_id = partner_id) 
            OR (sender_id = partner_id AND receiver_id = ?)
         ORDER BY created_at DESC LIMIT 1) as last_message_time,
        (SELECT COUNT(*) FROM messages 
         WHERE sender_id = partner_id AND receiver_id = ? AND is_read = 0) as unread_count
    FROM messages m
    JOIN users u ON u.id = CASE 
        WHEN m.sender_id = ? THEN m.receiver_id 
        ELSE m.sender_id 
    END
    WHERE m.sender_id = ? OR m.receiver_id = ?
    ORDER BY last_message_time DESC
");
$stmt->execute([
    $user['id'], $user['id'], $user['id'], 
    $user['id'], $user['id'], $user['id'], 
    $user['id'], $user['id'], $user['id']
]);
$conversations = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/unified.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <div class="container">
        <div class="chat-container">
            <!-- Conversations List -->
            <div class="chat-sidebar">
                <div class="chat-sidebar-header">
                    <h2>Pesan</h2>
                    <button class="btn-icon" onclick="openNewChatModal()">
                        <i class="fas fa-edit"></i>
                    </button>
                </div>
                
                <div class="chat-search">
                    <input type="text" placeholder="Cari percakapan..." class="form-control" id="chatSearch">
                </div>
                
                <div class="conversations-list">
                    <?php if (empty($conversations)): ?>
                        <div class="empty-state">
                            <i class="fas fa-comments"></i>
                            <p>Belum ada percakapan</p>
                        </div>
                    <?php else: ?>
                        <?php foreach ($conversations as $conv): ?>
                            <a href="chat.php?user=<?php echo $conv['partner_id']; ?>" 
                               class="conversation-item <?php echo $chatPartnerId == $conv['partner_id'] ? 'active' : ''; ?>">
                                <img src="uploads/profiles/<?php echo htmlspecialchars($conv['profile_photo']); ?>" 
                                     alt="Profile" class="avatar">
                                <div class="conversation-info">
                                    <h4><?php echo htmlspecialchars($conv['full_name']); ?></h4>
                                    <p class="last-message"><?php echo htmlspecialchars(substr($conv['last_message'], 0, 50)); ?></p>
                                </div>
                                <div class="conversation-meta">
                                    <span class="time"><?php echo timeAgo($conv['last_message_time']); ?></span>
                                    <?php if ($conv['unread_count'] > 0): ?>
                                        <span class="unread-badge"><?php echo $conv['unread_count']; ?></span>
                                    <?php endif; ?>
                                </div>
                            </a>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Chat Window -->
            <div class="chat-window">
                <?php if ($chatPartner): ?>
                    <div class="chat-header">
                        <img src="uploads/profiles/<?php echo htmlspecialchars($chatPartner['profile_photo']); ?>" 
                             alt="Profile" class="avatar">
                        <div class="chat-header-info">
                            <h3><?php echo htmlspecialchars($chatPartner['full_name']); ?></h3>
                            <span class="status">@<?php echo htmlspecialchars($chatPartner['username']); ?></span>
                        </div>
                        <a href="profile.php?id=<?php echo $chatPartner['id']; ?>" class="btn btn-sm">
                            <i class="fas fa-user"></i> Lihat Profil
                        </a>
                    </div>
                    
                    <div class="chat-messages" id="chatMessages">
                        <!-- Messages will be loaded here -->
                    </div>
                    
                    <div class="chat-input">
                        <form id="sendMessageForm">
                            <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                            <input type="hidden" name="receiver_id" value="<?php echo $chatPartner['id']; ?>">
                            <input type="text" name="message" id="messageInput" 
                                   placeholder="Ketik pesan..." class="form-control" required>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-paper-plane"></i>
                            </button>
                        </form>
                    </div>
                <?php else: ?>
                    <div class="chat-empty">
                        <i class="fas fa-comments"></i>
                        <h3>Pilih percakapan untuk memulai chat</h3>
                        <p>Atau mulai percakapan baru dengan pengguna lain</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- New Chat Modal -->
    <div id="newChatModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeNewChatModal()">&times;</span>
            <h2>Percakapan Baru</h2>
            
            <div class="form-group">
                <input type="text" id="userSearch" placeholder="Cari pengguna..." class="form-control">
            </div>
            
            <div id="userSearchResults" class="user-search-results">
                <!-- Search results will appear here -->
            </div>
        </div>
    </div>
    
    <?php include 'includes/footer.php'; ?>
    
    <script src="assets/js/main.js"></script>
    <script>
        const currentUserId = <?php echo $user['id']; ?>;
        const chatPartnerId = <?php echo $chatPartnerId ?? 'null'; ?>;
        
        // Load messages
        function loadMessages() {
            if (!chatPartnerId) return;
            
            fetch(`api/get-messages.php?partner_id=${chatPartnerId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        displayMessages(data.messages);
                    }
                });
        }
        
        function displayMessages(messages) {
            const container = document.getElementById('chatMessages');
            container.innerHTML = '';
            
            messages.forEach(msg => {
                const div = document.createElement('div');
                div.className = `message ${msg.sender_id == currentUserId ? 'sent' : 'received'}`;
                div.innerHTML = `
                    <div class="message-content">
                        <p>${escapeHtml(msg.message)}</p>
                        <span class="message-time">${formatTime(msg.created_at)}</span>
                    </div>
                `;
                container.appendChild(div);
            });
            
            container.scrollTop = container.scrollHeight;
        }
        
        // Send message
        document.getElementById('sendMessageForm')?.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            
            fetch('api/send-message.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    document.getElementById('messageInput').value = '';
                    loadMessages();
                } else {
                    alert(data.message);
                }
            });
        });
        
        // Auto-refresh messages
        if (chatPartnerId) {
            loadMessages();
            setInterval(loadMessages, 3000);
        }
        
        // Search users
        let searchTimeout;
        document.getElementById('userSearch')?.addEventListener('input', function() {
            clearTimeout(searchTimeout);
            const query = this.value;
            
            if (query.length < 2) {
                document.getElementById('userSearchResults').innerHTML = '';
                return;
            }
            
            searchTimeout = setTimeout(() => {
                fetch(`api/search-users.php?q=${encodeURIComponent(query)}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            displayUserResults(data.users);
                        }
                    });
            }, 300);
        });
        
        function displayUserResults(users) {
            const container = document.getElementById('userSearchResults');
            container.innerHTML = '';
            
            if (users.length === 0) {
                container.innerHTML = '<p class="text-muted">Tidak ada hasil</p>';
                return;
            }
            
            users.forEach(user => {
                const div = document.createElement('div');
                div.className = 'user-result-item';
                div.innerHTML = `
                    <img src="uploads/profiles/${user.profile_photo}" alt="Profile" class="avatar">
                    <div class="user-info">
                        <h4>${escapeHtml(user.full_name)}</h4>
                        <p>@${escapeHtml(user.username)}</p>
                    </div>
                    <button class="btn btn-sm" onclick="startChat(${user.id})">Chat</button>
                `;
                container.appendChild(div);
            });
        }
        
        function startChat(userId) {
            window.location.href = `chat.php?user=${userId}`;
        }
        
        function openNewChatModal() {
            document.getElementById('newChatModal').style.display = 'block';
        }
        
        function closeNewChatModal() {
            document.getElementById('newChatModal').style.display = 'none';
        }
        
        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
        
        function formatTime(datetime) {
            const date = new Date(datetime);
            const now = new Date();
            const diff = now - date;
            
            if (diff < 60000) return 'Baru saja';
            if (diff < 3600000) return Math.floor(diff / 60000) + ' menit lalu';
            if (diff < 86400000) return Math.floor(diff / 3600000) + ' jam lalu';
            
            return date.toLocaleDateString('id-ID', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
        }
    </script>
</body>
</html>