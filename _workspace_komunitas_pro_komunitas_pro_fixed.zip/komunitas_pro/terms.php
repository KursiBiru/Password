<?php
require_once 'config.php';
$isLoggedIn = isLoggedIn();
if ($isLoggedIn) {
    $user = getCurrentUser();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Syarat & Ketentuan - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/unified.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php if ($isLoggedIn): ?>
        <?php include 'includes/header.php'; ?>
    <?php endif; ?>
    
    <div class="container">
        <div style="max-width: 800px; margin: 40px auto; background: white; padding: 40px; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
            <h1 style="color: #3498db; margin-bottom: 20px;">Syarat & Ketentuan</h1>
            <p style="color: #7f8c8d; margin-bottom: 30px;">Terakhir diperbarui: <?php echo date('d F Y'); ?></p>
            
            <section style="margin-bottom: 30px;">
                <h2 style="color: #2c3e50; margin-bottom: 15px;">1. Penerimaan Ketentuan</h2>
                <p style="line-height: 1.8; color: #555;">
                    Dengan mengakses dan menggunakan <?php echo SITE_NAME; ?>, Anda menyetujui untuk terikat oleh syarat dan ketentuan ini. 
                    Jika Anda tidak setuju dengan bagian mana pun dari ketentuan ini, Anda tidak boleh menggunakan layanan kami.
                </p>
            </section>
            
            <section style="margin-bottom: 30px;">
                <h2 style="color: #2c3e50; margin-bottom: 15px;">2. Akun Pengguna</h2>
                <p style="line-height: 1.8; color: #555;">
                    <strong>2.1 Pendaftaran:</strong> Anda harus memberikan informasi yang akurat dan lengkap saat mendaftar.<br>
                    <strong>2.2 Keamanan:</strong> Anda bertanggung jawab untuk menjaga kerahasiaan akun dan password Anda.<br>
                    <strong>2.3 Tanggung Jawab:</strong> Anda bertanggung jawab atas semua aktivitas yang terjadi di akun Anda.
                </p>
            </section>
            
            <section style="margin-bottom: 30px;">
                <h2 style="color: #2c3e50; margin-bottom: 15px;">3. Konten Pengguna</h2>
                <p style="line-height: 1.8; color: #555;">
                    <strong>3.1 Kepemilikan:</strong> Anda mempertahankan kepemilikan atas konten yang Anda posting.<br>
                    <strong>3.2 Lisensi:</strong> Dengan memposting konten, Anda memberikan kami lisensi untuk menggunakan, menampilkan, dan mendistribusikan konten tersebut.<br>
                    <strong>3.3 Larangan:</strong> Dilarang memposting konten yang melanggar hukum, mengandung SARA, pornografi, atau melanggar hak orang lain.
                </p>
            </section>
            
            <section style="margin-bottom: 30px;">
                <h2 style="color: #2c3e50; margin-bottom: 15px;">4. Transaksi dan Pembayaran</h2>
                <p style="line-height: 1.8; color: #555;">
                    <strong>4.1 Wallet:</strong> Semua transaksi dilakukan melalui sistem wallet internal.<br>
                    <strong>4.2 Deposit:</strong> Deposit dapat dilakukan melalui transfer manual atau payment gateway yang tersedia.<br>
                    <strong>4.3 Withdrawal:</strong> Penarikan dana dikenakan biaya <?php echo WITHDRAWAL_FEE_PERCENT; ?>% dari jumlah yang ditarik.<br>
                    <strong>4.4 Minimum Withdrawal:</strong> Jumlah minimum penarikan adalah <?php echo formatCurrency(MIN_WITHDRAWAL_AMOUNT); ?>.
                </p>
            </section>
            
            <section style="margin-bottom: 30px;">
                <h2 style="color: #2c3e50; margin-bottom: 15px;">5. Jual Beli Produk</h2>
                <p style="line-height: 1.8; color: #555;">
                    <strong>5.1 Penjual:</strong> Penjual bertanggung jawab atas keakuratan deskripsi produk dan pengiriman produk.<br>
                    <strong>5.2 Pembeli:</strong> Pembeli harus memastikan detail produk sebelum melakukan pembelian.<br>
                    <strong>5.3 Sengketa:</strong> Kami menyediakan mediasi untuk menyelesaikan sengketa antara pembeli dan penjual.
                </p>
            </section>
            
            <section style="margin-bottom: 30px;">
                <h2 style="color: #2c3e50; margin-bottom: 15px;">6. Larangan Penggunaan</h2>
                <p style="line-height: 1.8; color: #555;">
                    Anda dilarang untuk:<br>
                    • Menggunakan platform untuk aktivitas ilegal<br>
                    • Melakukan spam atau mengirim pesan yang tidak diinginkan<br>
                    • Mencoba mengakses akun pengguna lain tanpa izin<br>
                    • Mengganggu atau merusak layanan kami<br>
                    • Melakukan penipuan atau aktivitas yang merugikan pengguna lain
                </p>
            </section>
            
            <section style="margin-bottom: 30px;">
                <h2 style="color: #2c3e50; margin-bottom: 15px;">7. Penangguhan dan Penghentian</h2>
                <p style="line-height: 1.8; color: #555;">
                    Kami berhak untuk menangguhkan atau menghentikan akun Anda jika Anda melanggar syarat dan ketentuan ini, 
                    tanpa pemberitahuan sebelumnya dan tanpa kewajiban untuk memberikan pengembalian dana.
                </p>
            </section>
            
            <section style="margin-bottom: 30px;">
                <h2 style="color: #2c3e50; margin-bottom: 15px;">8. Batasan Tanggung Jawab</h2>
                <p style="line-height: 1.8; color: #555;">
                    <?php echo SITE_NAME; ?> tidak bertanggung jawab atas kerugian langsung, tidak langsung, insidental, 
                    atau konsekuensial yang timbul dari penggunaan atau ketidakmampuan menggunakan layanan kami.
                </p>
            </section>
            
            <section style="margin-bottom: 30px;">
                <h2 style="color: #2c3e50; margin-bottom: 15px;">9. Perubahan Ketentuan</h2>
                <p style="line-height: 1.8; color: #555;">
                    Kami berhak untuk mengubah syarat dan ketentuan ini sewaktu-waktu. Perubahan akan berlaku segera setelah 
                    dipublikasikan di website. Penggunaan layanan setelah perubahan berarti Anda menyetujui ketentuan yang baru.
                </p>
            </section>
            
            <section style="margin-bottom: 30px;">
                <h2 style="color: #2c3e50; margin-bottom: 15px;">10. Hukum yang Berlaku</h2>
                <p style="line-height: 1.8; color: #555;">
                    Syarat dan ketentuan ini diatur oleh dan ditafsirkan sesuai dengan hukum Republik Indonesia.
                </p>
            </section>
            
            <section style="margin-bottom: 30px;">
                <h2 style="color: #2c3e50; margin-bottom: 15px;">11. Kontak</h2>
                <p style="line-height: 1.8; color: #555;">
                    Jika Anda memiliki pertanyaan tentang Syarat & Ketentuan ini, silakan hubungi kami di:<br>
                    <strong>Email:</strong> <?php echo SITE_EMAIL; ?>
                </p>
            </section>
        </div>
    </div>
    
    <?php if ($isLoggedIn): ?>
        <?php include 'includes/footer.php'; ?>
    <?php endif; ?>
</body>
</html>