<?php
require_once 'config.php';
requireLogin();

$user = getCurrentUser();
$conn = getDBConnection();

// Get filters
$postType = $_GET['type'] ?? 'all';
$language = $_GET['lang'] ?? 'all';
$category = $_GET['category'] ?? 'all';
$search = $_GET['search'] ?? '';

// Build query
$query = "SELECT p.*, u.username, u.full_name, u.profile_photo,
          (SELECT COUNT(*) FROM likes WHERE post_id = p.id) as like_count,
          (SELECT COUNT(*) FROM comments WHERE post_id = p.id) as comment_count,
          (SELECT COUNT(*) FROM shares WHERE post_id = p.id) as share_count,
          (SELECT COUNT(*) FROM likes WHERE post_id = p.id AND user_id = ?) as user_liked
          FROM posts p
          JOIN users u ON p.user_id = u.id
          WHERE p.status = 'active'";

$params = [$user['id']];

if ($postType !== 'all') {
    $query .= " AND p.post_type = ?";
    $params[] = $postType;
}

if ($language !== 'all') {
    $query .= " AND p.language = ?";
    $params[] = $language;
}

if ($category !== 'all' && $postType === 'product') {
    $query .= " AND p.product_category = ?";
    $params[] = $category;
}

if (!empty($search)) {
    $query .= " AND (p.title LIKE ? OR p.content LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

$query .= " ORDER BY p.created_at DESC LIMIT 50";

$stmt = $conn->prepare($query);
$stmt->execute($params);
$posts = $stmt->fetchAll();

// Get categories for filter
$categoriesStmt = $conn->query("SELECT DISTINCT product_category FROM posts WHERE post_type = 'product' AND product_category IS NOT NULL");
$categories = $categoriesStmt->fetchAll();
$flashMessage = getFlashMessage();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Beranda - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/unified.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <div class="container">
        <?php if (isset($flashMessage)): ?>
            <div class="alert alert-<?php echo $flashMessage['type']; ?>">
                <?php echo $flashMessage['message']; ?>
            </div>
        <?php endif; ?>
        <div class="main-content">
            <!-- Sidebar -->
            <aside class="sidebar">
                <div class="sidebar-section">
                    <h3>Filter</h3>
                    <form method="GET" action="" id="filter-form">
                        <div class="form-group">
                            <label>Tipe Postingan</label>
                            <select name="type" class="form-control" onchange="this.form.submit()">
                                <option value="all" <?php echo $postType === 'all' ? 'selected' : ''; ?>>Semua</option>
                                <option value="community" <?php echo $postType === 'community' ? 'selected' : ''; ?>>Komunitas</option>
                                <option value="product" <?php echo $postType === 'product' ? 'selected' : ''; ?>>Produk</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label>Bahasa</label>
                            <select name="lang" class="form-control" onchange="this.form.submit()">
                                <option value="all" <?php echo $language === 'all' ? 'selected' : ''; ?>>Semua</option>
                                <option value="id" <?php echo $language === 'id' ? 'selected' : ''; ?>>Indonesia</option>
                                <option value="en" <?php echo $language === 'en' ? 'selected' : ''; ?>>English</option>
                            </select>
                        </div>
                        
                        <?php if ($postType === 'product'): ?>
                        <div class="form-group">
                            <label>Kategori</label>
                            <select name="category" class="form-control" onchange="this.form.submit()">
                                <option value="all">Semua Kategori</option>
                                <?php foreach ($categories as $cat): ?>
                                    <option value="<?php echo htmlspecialchars($cat['product_category']); ?>" 
                                            <?php echo $category === $cat['product_category'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($cat['product_category']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <?php endif; ?>
                    </form>
                </div>
                
                <div class="sidebar-section youtube-box">
                    <h3>📺 Belajar Lebih Banyak</h3>
                    <p>Subscribe channel YouTube kami untuk tutorial dan tips menarik!</p>
                    <a href="https://youtube.com/@kursibiru" target="_blank" class="btn btn-danger btn-block">
                        <i class="fab fa-youtube"></i> Subscribe kursibiru
                    </a>
                </div>
            </aside>
            
            <!-- Feed -->
            <div class="feed">
                <!-- Create Post -->
                <div class="create-post-box">
                    <div class="create-post-header">
                        <img src="uploads/profiles/<?php echo htmlspecialchars($user['profile_photo']); ?>" alt="Profile" class="avatar">
                        <input type="text" placeholder="Apa yang ingin Anda bagikan?" class="form-control" onclick="openCreatePostModal()">
                    </div>
                    <div class="create-post-actions">
                        <button onclick="openCreatePostModal('community')" class="btn-action">
                            <i class="fas fa-edit"></i> Posting
                        </button>
                        <button onclick="openCreatePostModal('product')" class="btn-action">
                            <i class="fas fa-shopping-bag"></i> Jual Produk
                        </button>
                    </div>
                </div>
                
                <!-- Posts -->
                <?php if (empty($posts)): ?>
                    <div class="empty-state">
                        <i class="fas fa-inbox"></i>
                        <p>Belum ada postingan</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($posts as $post): ?>
                        <div class="post-card" data-post-id="<?php echo $post['id']; ?>">
                            <div class="post-header">
                                <img src="uploads/profiles/<?php echo htmlspecialchars($post['profile_photo']); ?>" alt="Profile" class="avatar">
                                <div class="post-info">
                                    <h4><a href="profile.php?id=<?php echo $post['user_id']; ?>"><?php echo htmlspecialchars($post['full_name']); ?></a></h4>
                                    <span class="post-time"><?php echo timeAgo($post['created_at']); ?></span>
                                </div>
                                <?php if ($post['user_id'] == $user['id']): ?>
                                <div class="post-menu">
                                    <button class="btn-menu" onclick="togglePostMenu(<?php echo $post['id']; ?>)">⋮</button>
                                    <div class="post-menu-dropdown" id="menu-<?php echo $post['id']; ?>">
                                        <a href="edit-post.php?id=<?php echo $post['id']; ?>">Edit</a>
                                        <a href="post-detail.php?id=<?php echo $post['id']; ?>">Lihat Postinggan</a>
                                        <a href="#" onclick="deletePost(<?php echo $post['id']; ?>)">Hapus</a>
                                    </div>
                                </div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="post-content">
                                <h3><?php echo htmlspecialchars($post['title']); ?></h3>
                                <p><?php echo nl2br(htmlspecialchars($post['content'])); ?></p>
                                
                                <?php if ($post['post_type'] === 'product'): ?>
                                    <div class="product-info">
                                        <span class="product-price"><?php echo formatCurrency($post['product_price']); ?></span>
                                        <span class="product-category"><?php echo htmlspecialchars($post['product_category']); ?></span>
                                        <span class="product-type"><?php echo $post['product_type'] === 'digital' ? 'Digital' : 'Fisik'; ?></span>
                                    </div>
                                <?php endif; ?>
                                
                                <?php if (!empty($post['images'])): ?>
                                    <?php $images = json_decode($post['images'], true); ?>
                                    <?php if (is_array($images) && count($images) > 0): ?>
                                        <div class="post-images">
                                            <?php foreach ($images as $image): ?>
                                                <img src="uploads/posts/<?php echo htmlspecialchars($image); ?>" alt="Post image">
                                            <?php endforeach; ?>
                                        </div>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                            
                            <div class="post-stats">
                                <span><?php echo $post['like_count']; ?> suka</span>
                                <span><?php echo $post['comment_count']; ?> komentar</span>
                                <span><?php echo $post['share_count']; ?> bagikan</span>
                            </div>
                            
                            <div class="post-actions">
                                <button class="btn-action <?php echo $post['user_liked'] ? 'active' : ''; ?>" onclick="toggleLike(<?php echo $post['id']; ?>)">
                                    <i class="fas fa-heart"></i> Suka
                                </button>
                                <button class="btn-action" onclick="showComments(<?php echo $post['id']; ?>)">
                                    <i class="fas fa-comment"></i> Komentar
                                </button>
                                <button class="btn-action" onclick="sharePost(<?php echo $post['id']; ?>)">
                                    <i class="fas fa-share"></i> Bagikan
                                </button>
                                <?php if ($post['post_type'] === 'product'): ?>
                                    <button class="btn-action btn-buy" onclick="buyProduct(<?php echo $post['id']; ?>)">
                                        <i class="fas fa-shopping-cart"></i> Beli
                                    </button>
                                <?php endif; ?>
                            </div>
                            
                            <div class="post-comments" id="comments-<?php echo $post['id']; ?>" style="display: none;">
                                <!-- Comments will be loaded here -->
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            
            <!-- Right Sidebar -->
            <aside class="sidebar-right">
                <div class="sidebar-section">
                    <h3>Trending</h3>
                    <div class="trending-list">
                        <p class="text-muted">Belum ada trending</p>
                    </div>
                </div>
            </aside>
        </div>
    </div>
    
    <!-- Create Post Modal -->
    <div id="createPostModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeCreatePostModal()">&times;</span>
            <h2 id="modalTitle">Buat Postingan</h2>
            <form id="createPostForm" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                <input type="hidden" name="post_type" id="post_type" value="community">
                
                <div class="form-group">
                    <label for="title">Judul</label>
                    <input type="text" id="title" name="title" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="content">Konten</label>
                    <textarea id="content" name="content" class="form-control" rows="5" required></textarea>
                </div>
                
                <div class="form-group">
                    <label for="language">Bahasa</label>
                    <select id="language" name="language" class="form-control">
                        <option value="id">Indonesia</option>
                        <option value="en">English</option>
                    </select>
                </div>
                
                <div id="productFields" style="display: none;">
                    <div class="form-group">
                        <label for="product_price">Harga</label>
                        <input type="number" id="product_price" name="product_price" class="form-control" min="0">
                    </div>
                    
                    <div class="form-group">
                        <label for="product_category">Kategori</label>
                        <input type="text" id="product_category" name="product_category" class="form-control">
                    </div>
                    
                    <div class="form-group">
                        <label for="product_type">Tipe Produk</label>
                        <select id="product_type" name="product_type" class="form-control">
                            <option value="physical">Fisik</option>
                            <option value="digital">Digital</option>
                        </select>
                    </div>
                    
                    <div class="form-group" id="digitalFileGroup" style="display: none;">
                        <label for="product_file">File Digital</label>
                        <input type="file" id="product_file" name="product_file" class="form-control">
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="images">Gambar (Opsional)</label>
                    <input type="file" id="images" name="images[]" class="form-control" multiple accept="image/*">
                </div>
                
                <button type="submit" class="btn btn-primary">Posting</button>
            </form>
        </div>
    </div>
    
    <?php include 'includes/footer.php'; ?>
    
    <script src="assets/js/main.js"></script>
    <script src="assets/js/posts.js"></script>
</body>
</html>