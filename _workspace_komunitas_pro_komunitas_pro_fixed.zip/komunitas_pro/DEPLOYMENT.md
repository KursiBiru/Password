# Panduan Deployment ke Production

## Checklist Pre-Deployment

### 1. Security
- [ ] Ganti password admin default
- [ ] Update semua credentials (database, API keys)
- [ ] Enable HTTPS/SSL
- [ ] Set `display_errors = Off` di php.ini
- [ ] Set `error_reporting = E_ALL & ~E_DEPRECATED & ~E_STRICT`
- [ ] Enable firewall
- [ ] Restrict database access
- [ ] Set proper file permissions (644 for files, 755 for folders)
- [ ] Remove atau protect file setup.php

### 2. Configuration
- [ ] Update SITE_URL di config.php
- [ ] Update database credentials
- [ ] Configure email settings
- [ ] Setup Midtrans production keys
- [ ] Configure backup schedule
- [ ] Setup monitoring

### 3. Performance
- [ ] Enable OPcache
- [ ] Enable Gzip compression
- [ ] Optimize images
- [ ] Minify CSS/JS (optional)
- [ ] Setup CDN (optional)
- [ ] Configure caching

### 4. Database
- [ ] Optimize database tables
- [ ] Add indexes where needed
- [ ] Setup automated backups
- [ ] Test database connection
- [ ] Check database size limits

## Deployment Steps

### Step 1: Backup
```bash
# Backup database
mysqldump -u username -p database_name > backup_$(date +%Y%m%d).sql

# Backup files
tar -czf files_backup_$(date +%Y%m%d).tar.gz /path/to/website
```

### Step 2: Upload Files
```bash
# Via FTP/SFTP
# Upload all files to server

# Via Git (recommended)
git clone https://github.com/yourusername/komunitas-marketplace.git
cd komunitas-marketplace
```

### Step 3: Set Permissions
```bash
# Set folder permissions
chmod -R 755 /path/to/website
chmod -R 755 uploads/

# Set file permissions
find /path/to/website -type f -exec chmod 644 {} \;
find /path/to/website -type d -exec chmod 755 {} \;

# Make uploads writable
chmod -R 755 uploads/
```

### Step 4: Configure
```bash
# Edit config.php
nano config.php

# Update:
# - DB_HOST, DB_USER, DB_PASS, DB_NAME
# - SITE_URL
# - Error reporting settings
```

### Step 5: Database Setup
```bash
# Import database
mysql -u username -p database_name < database.sql

# Or via phpMyAdmin
# Import database.sql through web interface
```

### Step 6: Test
- [ ] Test homepage
- [ ] Test login/register
- [ ] Test posting
- [ ] Test chat
- [ ] Test wallet
- [ ] Test admin panel
- [ ] Test all forms
- [ ] Test file uploads
- [ ] Test notifications

### Step 7: SSL Setup
```bash
# Using Let's Encrypt (recommended)
certbot --apache -d yourdomain.com -d www.yourdomain.com

# Or use cPanel AutoSSL
# Or install SSL certificate manually
```

### Step 8: Monitoring Setup
```bash
# Setup error logging
# Setup uptime monitoring
# Setup performance monitoring
# Setup security monitoring
```

## Post-Deployment

### 1. Verify
- [ ] All pages load correctly
- [ ] HTTPS is working
- [ ] Forms submit properly
- [ ] File uploads work
- [ ] Email notifications work
- [ ] Payment gateway works
- [ ] Admin panel accessible
- [ ] Database connections stable

### 2. Optimize
- [ ] Enable caching
- [ ] Optimize database queries
- [ ] Compress static assets
- [ ] Setup CDN
- [ ] Configure server caching

### 3. Monitor
- [ ] Check error logs daily
- [ ] Monitor server resources
- [ ] Track user activity
- [ ] Monitor security alerts
- [ ] Check backup status

## Maintenance Schedule

### Daily
- Check error logs
- Monitor uptime
- Check backup status

### Weekly
- Review user reports
- Check security logs
- Update content
- Optimize database

### Monthly
- Update software
- Security audit
- Performance review
- Backup verification
- Clean old data

## Rollback Plan

If something goes wrong:

### Step 1: Identify Issue
- Check error logs
- Check database
- Check file permissions
- Check configuration

### Step 2: Restore Backup
```bash
# Restore database
mysql -u username -p database_name < backup_YYYYMMDD.sql

# Restore files
tar -xzf files_backup_YYYYMMDD.tar.gz -C /path/to/website
```

### Step 3: Verify
- Test all functionality
- Check data integrity
- Verify user access

## Performance Optimization

### PHP Configuration
```ini
; php.ini optimizations
memory_limit = 256M
max_execution_time = 300
upload_max_filesize = 10M
post_max_size = 10M
opcache.enable = 1
opcache.memory_consumption = 128
opcache.max_accelerated_files = 10000
```

### Apache Configuration
```apache
# Enable compression
<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/html text/plain text/xml text/css text/javascript application/javascript
</IfModule>

# Enable caching
<IfModule mod_expires.c>
    ExpiresActive On
    ExpiresByType image/jpg "access plus 1 year"
    ExpiresByType image/jpeg "access plus 1 year"
    ExpiresByType image/gif "access plus 1 year"
    ExpiresByType image/png "access plus 1 year"
    ExpiresByType text/css "access plus 1 month"
    ExpiresByType application/javascript "access plus 1 month"
</IfModule>
```

### MySQL Optimization
```sql
-- Optimize tables
OPTIMIZE TABLE users, posts, comments, likes, transactions, messages, notifications;

-- Add indexes if needed
CREATE INDEX idx_created_at ON posts(created_at);
CREATE INDEX idx_user_id ON posts(user_id);
```

## Security Hardening

### 1. File Permissions
```bash
# Secure config.php
chmod 600 config.php

# Secure .htaccess
chmod 644 .htaccess

# Secure uploads
chmod 755 uploads/
```

### 2. Database Security
```sql
-- Create dedicated database user
CREATE USER 'webapp_user'@'localhost' IDENTIFIED BY 'strong_password';
GRANT SELECT, INSERT, UPDATE, DELETE ON database_name.* TO 'webapp_user'@'localhost';
FLUSH PRIVILEGES;
```

### 3. Server Security
```bash
# Disable directory listing
# Enable firewall
# Install fail2ban
# Setup intrusion detection
# Enable security headers
```

## Backup Strategy

### Automated Backup Script
```bash
#!/bin/bash
# backup.sh

DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/path/to/backups"
DB_NAME="komunitas_marketplace"
DB_USER="username"
DB_PASS="password"

# Backup database
mysqldump -u $DB_USER -p$DB_PASS $DB_NAME > $BACKUP_DIR/db_$DATE.sql

# Backup files
tar -czf $BACKUP_DIR/files_$DATE.tar.gz /path/to/website/uploads

# Delete old backups (keep last 30 days)
find $BACKUP_DIR -name "*.sql" -mtime +30 -delete
find $BACKUP_DIR -name "*.tar.gz" -mtime +30 -delete

echo "Backup completed: $DATE"
```

### Setup Cron Job
```bash
# Edit crontab
crontab -e

# Add backup job (runs daily at 2 AM)
0 2 * * * /path/to/backup.sh >> /var/log/backup.log 2>&1
```

## Troubleshooting Production Issues

### High Server Load
1. Check slow queries
2. Optimize database
3. Enable caching
4. Scale resources

### Database Connection Errors
1. Check connection limits
2. Optimize queries
3. Add connection pooling
4. Check server resources

### File Upload Issues
1. Check disk space
2. Check permissions
3. Check PHP limits
4. Check server configuration

## Support

For production support:
- Email: info@komunitas.com
- Documentation: README.md
- Video Tutorial: [@kursibiru](https://youtube.com/@kursibiru)

---

**Remember: Always test in staging before deploying to production!**