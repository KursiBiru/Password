<?php
require_once 'config.php';
requireLogin();

$user = getCurrentUser();
$conn = getDBConnection();

// Get transaction history
$stmt = $conn->prepare("SELECT * FROM transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT 50");
$stmt->execute([$user['id']]);
$transactions = $stmt->fetchAll();

// Handle deposit request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        setFlashMessage('danger', 'Invalid CSRF token');
    } else {
        $action = $_POST['action'];
        
        if ($action === 'deposit_manual') {
            $amount = floatval($_POST['amount']);
            
            if ($amount < 10000) {
                setFlashMessage('danger', 'Minimal deposit Rp 10.000');
            } else {
                // Generate unique code
                $uniqueCode = rand(100, 999);
                $totalAmount = $amount + $uniqueCode;
                
                // Handle proof upload
                $proofImage = null;
                if (isset($_FILES['proof_image']) && $_FILES['proof_image']['error'] === UPLOAD_ERR_OK) {
                    $upload = uploadFile($_FILES['proof_image'], 'proof');
                    if ($upload['success']) {
                        $proofImage = $upload['filename'];
                    }
                }
                
                $stmt = $conn->prepare("INSERT INTO transactions (user_id, transaction_type, amount, unique_code, net_amount, payment_method, proof_image, status) VALUES (?, 'deposit', ?, ?, ?, 'manual', ?, 'pending')");
                $stmt->execute([$user['id'], $totalAmount, $uniqueCode, $amount, $proofImage]);
                
                createNotification($user['id'], 'transaction', 'Deposit Pending', 'Deposit Anda sebesar ' . formatCurrency($totalAmount) . ' sedang diproses', 'wallet.php');
                
                setFlashMessage('success', 'Permintaan deposit berhasil dikirim. Total transfer: ' . formatCurrency($totalAmount));
                redirect('wallet.php');
            }
        } elseif ($action === 'withdraw') {
            $amount = floatval($_POST['amount']);
            $minWithdraw = MIN_WITHDRAWAL_AMOUNT;
            
            if ($amount < $minWithdraw) {
                setFlashMessage('danger', 'Minimal penarikan ' . formatCurrency($minWithdraw));
            } elseif ($amount > $user['wallet_balance']) {
                setFlashMessage('danger', 'Saldo tidak mencukupi');
            } else {
                $fee = $amount * (WITHDRAWAL_FEE_PERCENT / 100);
                $netAmount = $amount - $fee;
                
                // Deduct from wallet
                $stmt = $conn->prepare("UPDATE users SET wallet_balance = wallet_balance - ? WHERE id = ?");
                $stmt->execute([$amount, $user['id']]);
                
                // Create transaction
                $stmt = $conn->prepare("INSERT INTO transactions (user_id, transaction_type, amount, fee, net_amount, status) VALUES (?, 'withdrawal', ?, ?, ?, 'pending')");
                $stmt->execute([$user['id'], $amount, $fee, $netAmount]);
                
                createNotification($user['id'], 'transaction', 'Penarikan Diproses', 'Penarikan sebesar ' . formatCurrency($netAmount) . ' sedang diproses', 'wallet.php');
                
                setFlashMessage('success', 'Permintaan penarikan berhasil. Anda akan menerima ' . formatCurrency($netAmount) . ' (fee ' . WITHDRAWAL_FEE_PERCENT . '%)');
                redirect('wallet.php');
            }
        }
    }
}

$flashMessage = getFlashMessage();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wallet - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/unified.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <div class="container">
        <?php if ($flashMessage): ?>
            <div class="alert alert-<?php echo $flashMessage['type']; ?>">
                <?php echo $flashMessage['message']; ?>
            </div>
        <?php endif; ?>
        
        <div class="wallet-container">
            <h1><i class="fas fa-wallet"></i> Wallet Saya</h1>
            
            <!-- Balance Card -->
            <div class="balance-card">
                <div class="balance-info">
                    <span class="balance-label">Saldo Tersedia</span>
                    <h2 class="balance-amount"><?php echo formatCurrency($user['wallet_balance']); ?></h2>
                </div>
                <div class="balance-actions">
                    <button class="btn btn-success" onclick="openDepositModal()">
                        <i class="fas fa-plus"></i> Deposit
                    </button>
                    <button class="btn btn-primary" onclick="openWithdrawModal()">
                        <i class="fas fa-arrow-up"></i> Tarik Dana
                    </button>
                </div>
            </div>
            
            <!-- Quick Stats -->
            <div class="wallet-stats">
                <div class="stat-card">
                    <i class="fas fa-arrow-down text-success"></i>
                    <div>
                        <span class="stat-label">Total Deposit</span>
                        <?php
                        $stmt = $conn->prepare("SELECT SUM(net_amount) as total FROM transactions WHERE user_id = ? AND transaction_type = 'deposit' AND status = 'completed'");
                        $stmt->execute([$user['id']]);
                        $totalDeposit = $stmt->fetch()['total'] ?? 0;
                        ?>
                        <span class="stat-value"><?php echo formatCurrency($totalDeposit); ?></span>
                    </div>
                </div>
                
                <div class="stat-card">
                    <i class="fas fa-arrow-up text-danger"></i>
                    <div>
                        <span class="stat-label">Total Penarikan</span>
                        <?php
                        $stmt = $conn->prepare("SELECT SUM(amount) as total FROM transactions WHERE user_id = ? AND transaction_type = 'withdrawal' AND status = 'completed'");
                        $stmt->execute([$user['id']]);
                        $totalWithdraw = $stmt->fetch()['total'] ?? 0;
                        ?>
                        <span class="stat-value"><?php echo formatCurrency($totalWithdraw); ?></span>
                    </div>
                </div>
                
                <div class="stat-card">
                    <i class="fas fa-shopping-cart text-primary"></i>
                    <div>
                        <span class="stat-label">Total Pembelian</span>
                        <?php
                        $stmt = $conn->prepare("SELECT SUM(amount) as total FROM transactions WHERE user_id = ? AND transaction_type = 'purchase' AND status = 'completed'");
                        $stmt->execute([$user['id']]);
                        $totalPurchase = $stmt->fetch()['total'] ?? 0;
                        ?>
                        <span class="stat-value"><?php echo formatCurrency($totalPurchase); ?></span>
                    </div>
                </div>
                
                <div class="stat-card">
                    <i class="fas fa-dollar-sign text-warning"></i>
                    <div>
                        <span class="stat-label">Total Penjualan</span>
                        <?php
                        $stmt = $conn->prepare("SELECT SUM(net_amount) as total FROM transactions WHERE user_id = ? AND transaction_type = 'sale' AND status = 'completed'");
                        $stmt->execute([$user['id']]);
                        $totalSale = $stmt->fetch()['total'] ?? 0;
                        ?>
                        <span class="stat-value"><?php echo formatCurrency($totalSale); ?></span>
                    </div>
                </div>
            </div>
            
            <!-- Transaction History -->
            <div class="transaction-history">
                <h2>Riwayat Transaksi</h2>
                
                <?php if (empty($transactions)): ?>
                    <div class="empty-state">
                        <i class="fas fa-receipt"></i>
                        <p>Belum ada transaksi</p>
                    </div>
                <?php else: ?>
                    <div class="transaction-list">
                        <?php foreach ($transactions as $transaction): ?>
                            <div class="transaction-item">
                                <div class="transaction-icon">
                                    <?php
                                    $iconClass = '';
                                    $iconColor = '';
                                    switch ($transaction['transaction_type']) {
                                        case 'deposit':
                                            $iconClass = 'fa-arrow-down';
                                            $iconColor = 'text-success';
                                            break;
                                        case 'withdrawal':
                                            $iconClass = 'fa-arrow-up';
                                            $iconColor = 'text-danger';
                                            break;
                                        case 'purchase':
                                            $iconClass = 'fa-shopping-cart';
                                            $iconColor = 'text-primary';
                                            break;
                                        case 'sale':
                                            $iconClass = 'fa-dollar-sign';
                                            $iconColor = 'text-warning';
                                            break;
                                    }
                                    ?>
                                    <i class="fas <?php echo $iconClass; ?> <?php echo $iconColor; ?>"></i>
                                </div>
                                <div class="transaction-details">
                                    <h4><?php echo ucfirst($transaction['transaction_type']); ?></h4>
                                    <span class="transaction-date"><?php echo date('d M Y H:i', strtotime($transaction['created_at'])); ?></span>
                                    <?php if ($transaction['unique_code']): ?>
                                        <span class="transaction-code">Kode Unik: <?php echo $transaction['unique_code']; ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="transaction-amount">
                                    <span class="amount <?php echo in_array($transaction['transaction_type'], ['deposit', 'sale']) ? 'text-success' : 'text-danger'; ?>">
                                        <?php echo in_array($transaction['transaction_type'], ['deposit', 'sale']) ? '+' : '-'; ?>
                                        <?php echo formatCurrency($transaction['amount']); ?>
                                    </span>
                                    <?php if ($transaction['fee'] > 0): ?>
                                        <span class="fee">Fee: <?php echo formatCurrency($transaction['fee']); ?></span>
                                    <?php endif; ?>
                                    <span class="status status-<?php echo $transaction['status']; ?>">
                                        <?php
                                        $statusText = [
                                            'pending' => 'Pending',
                                            'completed' => 'Selesai',
                                            'rejected' => 'Ditolak',
                                            'cancelled' => 'Dibatalkan'
                                        ];
                                        echo $statusText[$transaction['status']];
                                        ?>
                                    </span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Deposit Modal -->
    <div id="depositModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeDepositModal()">&times;</span>
            <h2>Deposit Dana</h2>
            
            <div class="deposit-methods">
                <button class="method-btn" onclick="showDepositMethod('auto')">
                    <i class="fas fa-credit-card"></i>
                    <span>Otomatis (Midtrans)</span>
                </button>
                <button class="method-btn" onclick="showDepositMethod('manual')">
                    <i class="fas fa-university"></i>
                    <span>Transfer Manual</span>
                </button>
            </div>
            
            <div id="autoDeposit" class="deposit-form" style="display: none;">
                <p class="text-muted">Fitur deposit otomatis dengan Midtrans akan segera tersedia.</p>
                <p class="text-muted">Silakan gunakan metode transfer manual untuk saat ini.</p>
            </div>
            
            <div id="manualDeposit" class="deposit-form" style="display: none;">
                <form method="POST" action="" enctype="multipart/form-data">
                    <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                    <input type="hidden" name="action" value="deposit_manual">
                    
                    <div class="form-group">
                        <label for="amount">Jumlah Deposit (Min. Rp 10.000)</label>
                        <input type="number" id="amount" name="amount" class="form-control" min="10000" step="1000" required>
                        <small class="form-text">Kode unik akan ditambahkan otomatis</small>
                    </div>
                    
                    <div class="bank-info">
                        <h4>Informasi Rekening</h4>
                        <p><strong>Bank:</strong> BCA</p>
                        <p><strong>No. Rekening:</strong> 1234567890</p>
                        <p><strong>Atas Nama:</strong> Komunitas Marketplace</p>
                    </div>
                    
                    <div class="form-group">
                        <label for="proof_image">Bukti Transfer</label>
                        <input type="file" id="proof_image" name="proof_image" class="form-control" accept="image/*" required>
                    </div>
                    
                    <button type="submit" class="btn btn-primary btn-block">Kirim Permintaan</button>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Withdraw Modal -->
    <div id="withdrawModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeWithdrawModal()">&times;</span>
            <h2>Tarik Dana</h2>
            
            <form method="POST" action="">
                <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                <input type="hidden" name="action" value="withdraw">
                
                <div class="form-group">
                    <label for="withdraw_amount">Jumlah Penarikan</label>
                    <input type="number" id="withdraw_amount" name="amount" class="form-control" 
                           min="<?php echo MIN_WITHDRAWAL_AMOUNT; ?>" 
                           max="<?php echo $user['wallet_balance']; ?>" 
                           step="1000" required>
                    <small class="form-text">
                        Min: <?php echo formatCurrency(MIN_WITHDRAWAL_AMOUNT); ?> | 
                        Saldo: <?php echo formatCurrency($user['wallet_balance']); ?> | 
                        Fee: <?php echo WITHDRAWAL_FEE_PERCENT; ?>%
                    </small>
                </div>
                
                <div class="withdraw-calculation">
                    <div class="calc-row">
                        <span>Jumlah Penarikan:</span>
                        <span id="withdrawAmount">Rp 0</span>
                    </div>
                    <div class="calc-row">
                        <span>Fee (<?php echo WITHDRAWAL_FEE_PERCENT; ?>%):</span>
                        <span id="withdrawFee">Rp 0</span>
                    </div>
                    <div class="calc-row total">
                        <span>Yang Diterima:</span>
                        <span id="withdrawNet">Rp 0</span>
                    </div>
                </div>
                
                <button type="submit" class="btn btn-primary btn-block">Tarik Dana</button>
            </form>
        </div>
    </div>
    
    <?php include 'includes/footer.php'; ?>
    
    <script src="assets/js/main.js"></script>
    <script>
        function openDepositModal() {
            document.getElementById('depositModal').style.display = 'block';
        }
        
        function closeDepositModal() {
            document.getElementById('depositModal').style.display = 'none';
        }
        
        function showDepositMethod(method) {
            document.getElementById('autoDeposit').style.display = method === 'auto' ? 'block' : 'none';
            document.getElementById('manualDeposit').style.display = method === 'manual' ? 'block' : 'none';
        }
        
        function openWithdrawModal() {
            document.getElementById('withdrawModal').style.display = 'block';
        }
        
        function closeWithdrawModal() {
            document.getElementById('withdrawModal').style.display = 'none';
        }
        
        // Calculate withdrawal
        document.getElementById('withdraw_amount')?.addEventListener('input', function() {
            const amount = parseFloat(this.value) || 0;
            const fee = amount * (<?php echo WITHDRAWAL_FEE_PERCENT; ?> / 100);
            const net = amount - fee;
            
            document.getElementById('withdrawAmount').textContent = formatCurrency(amount);
            document.getElementById('withdrawFee').textContent = formatCurrency(fee);
            document.getElementById('withdrawNet').textContent = formatCurrency(net);
        });
        
        function formatCurrency(amount) {
            return 'Rp ' + amount.toLocaleString('id-ID');
        }
    </script>
</body>
</html>