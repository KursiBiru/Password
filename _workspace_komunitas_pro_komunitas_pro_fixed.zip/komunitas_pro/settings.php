<?php
require_once 'config.php';
requireLogin();

$currentUser = getCurrentUser();
$userId = $_GET['id'] ?? $currentUser['id'];

$conn = getDBConnection();
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$userId]);
$user = $stmt->fetch();

if (!$user) {
    redirect('login.php');
}

$error = '';
$success = '';
// Proses update profil
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_profile'])) {
        $username = sanitizeInput($_POST['username']);
        $email = sanitizeInput($_POST['email']);
        $bio = sanitizeInput($_POST['bio']);
        $location = sanitizeInput($_POST['location']);
        $website = sanitizeInput($_POST['website']);
        
        // Validasi
        if (empty($username) || empty($email)) {
            $error = 'Username dan email wajib diisi!';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Format email tidak valid!';
        } else {
            // Cek apakah username/email sudah digunakan oleh user lain
            $stmt = $conn->prepare("SELECT id FROM users WHERE (username = ? OR email = ?) AND id != ?");
            $stmt->execute([$username, $email, $userId]);
            
            if ($stmt->fetch()) {
                $error = 'Username atau email sudah digunakan!';
            } else {
                // Update profil
                $stmt = $conn->prepare("UPDATE users SET username = ?, email = ?, bio = ?, location = ?, website = ? WHERE id = ?");
                if ($stmt->execute([$username, $email, $bio, $location, $website, $userId])) {
                    $success = 'Profil berhasil diperbarui!';
                    // Refresh data user
                    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
                    $stmt->execute([$userId]);
                    $user = $stmt->fetch();
                } else {
                    $error = 'Gagal memperbarui profil!';
                }
            }
        }
    }
    
    // Proses update foto profil
    if (isset($_POST['update_photo'])) {
        if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] === UPLOAD_ERR_OK) {
            $upload_result = uploadFile($_FILES['profile_image'], 'uploads/profiles/', ['jpg', 'jpeg', 'png', 'gif']);
            
            if ($upload_result['success']) {
                // Hapus foto lama jika ada
                if ($user['profile_image'] && file_exists($user['profile_image'])) {
                    unlink($user['profile_image']);
                }
                
                $stmt = $conn->prepare("UPDATE users SET profile_image = ? WHERE id = ?");
                if ($stmt->execute([$upload_result['file_path'], $userId])) {
                    $success = 'Foto profil berhasil diperbarui!';
                    $user['profile_image'] = $upload_result['file_path'];
                } else {
                    $error = 'Gagal menyimpan foto profil!';
                }
            } else {
                $error = $upload_result['message'];
            }
        }
    }
    
    // Proses update foto cover
    if (isset($_POST['update_cover'])) {
        if (isset($_FILES['cover_image']) && $_FILES['cover_image']['error'] === UPLOAD_ERR_OK) {
            $upload_result = uploadFile($_FILES['cover_image'], 'uploads/covers/', ['jpg', 'jpeg', 'png', 'gif']);
            
            if ($upload_result['success']) {
                // Hapus cover lama jika ada
                if ($user['cover_image'] && file_exists($user['cover_image'])) {
                    unlink($user['cover_image']);
                }
                
                $stmt = $conn->prepare("UPDATE users SET cover_image = ? WHERE id = ?");
                if ($stmt->execute([$upload_result['file_path'], $userId])) {
                    $success = 'Foto cover berhasil diperbarui!';
                    $user['cover_image'] = $upload_result['file_path'];
                } else {
                    $error = 'Gagal menyimpan foto cover!';
                }
            } else {
                $error = $upload_result['message'];
            }
        }
    }
    
    // Proses update privacy
    if (isset($_POST['update_privacy'])) {
        $profile_private = isset($_POST['profile_private']) ? 1 : 0;
        $show_email = isset($_POST['show_email']) ? 1 : 0;
        $allow_messages = isset($_POST['allow_messages']) ? 1 : 0;
        
        $stmt = $conn->prepare("UPDATE users SET profile_private = ?, show_email = ?, allow_messages = ? WHERE id = ?");
        if ($stmt->execute([$profile_private, $show_email, $allow_messages, $userId])) {
            $success = 'Pengaturan privasi berhasil diperbarui!';
            $user['profile_private'] = $profile_private;
            $user['show_email'] = $show_email;
            $user['allow_messages'] = $allow_messages;
        } else {
            $error = 'Gagal memperbarui pengaturan privasi!';
        }
    }
}

$page_title = 'Pengaturan Akun';
include 'includes/header.php';
?>
<?php include 'includes/header.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/unified.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="container mt-4">
    <div class="row">
        <div class="col-md-8 offset-md-2">
            <h1 class="mb-4">Pengaturan Akun</h1>
            
            <?php if ($error): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <!-- Nav tabs -->
            <ul class="nav nav-tabs mb-4" id="settingsTab" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button">Profil</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="photos-tab" data-bs-toggle="tab" data-bs-target="#photos" type="button">Foto</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="privacy-tab" data-bs-toggle="tab" data-bs-target="#privacy" type="button">Privasi</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="security-tab" data-bs-toggle="tab" data-bs-target="#security" type="button">Keamanan</button>
                </li>
            </ul>
            
            <!-- Tab content -->
            <div class="tab-content" id="settingsTabContent">
                <!-- Profile Tab -->
                <div class="tab-pane fade show active" id="profile" role="tabpanel">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">Informasi Profil</h5>
                        </div>
                        <div class="card-body">
                            <form method="POST">
                                <div class="mb-3">
                                    <label for="username" class="form-label">Username</label>
                                    <input type="text" class="form-control" id="username" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label for="email" class="form-label">Email</label>
                                    <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label for="bio" class="form-label">Bio</label>
                                    <textarea class="form-control" id="bio" name="bio" rows="3"><?php echo htmlspecialchars($user['bio'] ?? ''); ?></textarea>
                                </div>
                                <div class="mb-3">
                                    <label for="location" class="form-label">Lokasi</label>
                                    <input type="text" class="form-control" id="location" name="location" value="<?php echo htmlspecialchars($user['location'] ?? ''); ?>">
                                </div>
                                <div class="mb-3">
                                    <label for="website" class="form-label">Website</label>
                                    <input type="url" class="form-control" id="website" name="website" value="<?php echo htmlspecialchars($user['website'] ?? ''); ?>">
                                </div>
                                <button type="submit" name="update_profile" class="btn btn-primary">Perbarui Profil</button>
                            </form>
                        </div>
                    </div>
                </div>
                
                <!-- Photos Tab -->
                <div class="tab-pane fade" id="photos" role="tabpanel">
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="mb-0">Foto Profil</h5>
                        </div>
                        <div class="card-body">
                            <div class="text-center mb-3">
                                <img src="<?php echo $user['profile_photo'] ? $user['profile_photo'] : 'assets/img/default-avatar.png'; ?>" alt="Foto Profil" class="rounded-circle" width="150" height="150">
                            </div>
                            <form method="POST" enctype="multipart/form-data">
                                <div class="mb-3">
                                    <label for="profile_photo" class="form-label">Pilih Foto Profil Baru</label>
                                    <input type="file" class="form-control" id="profile_photo" name="profile_photo" accept="image/*" required>
                                </div>
                                <button type="submit" name="update_photo" class="btn btn-primary">Perbarui Foto Profil</button>
                            </form>
                        </div>
                    </div>
                    
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">Foto Cover</h5>
                        </div>
                        <div class="card-body">
                            <?php if ($user['cover_image']): ?>
                                <div class="mb-3">
                                    <img src="<?php echo $user['cover_image']; ?>" alt="Foto Cover" class="img-fluid rounded">
                                </div>
                            <?php endif; ?>
                            <form method="POST" enctype="multipart/form-data">
                                <div class="mb-3">
                                    <label for="cover_image" class="form-label">Pilih Foto Cover Baru</label>
                                    <input type="file" class="form-control" id="cover_image" name="cover_image" accept="image/*" required>
                                </div>
                                <button type="submit" name="update_cover" class="btn btn-primary">Perbarui Foto Cover</button>
                            </form>
                        </div>
                    </div>
                </div>
                
                <!-- Privacy Tab -->
                <div class="tab-pane fade" id="privacy" role="tabpanel">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">Pengaturan Privasi</h5>
                        </div>
                        <div class="card-body">
                            <form method="POST">
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="checkbox" id="profile_private" name="profile_private" <?php echo $user['profile_private'] ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="profile_private">
                                        Jadikan profil pribadi (hanya follower yang bisa melihat)
                                    </label>
                                </div>
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="checkbox" id="show_email" name="show_email" <?php echo $user['show_email'] ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="show_email">
                                        Tampilkan email di profil
                                    </label>
                                </div>
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="checkbox" id="allow_messages" name="allow_messages" <?php echo $user['allow_messages'] ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="allow_messages">
                                        Izinkan semua user mengirim pesan
                                    </label>
                                </div>
                                <button type="submit" name="update_privacy" class="btn btn-primary">Perbarui Privasi</button>
                            </form>
                        </div>
                    </div>
                </div>
                
                <!-- Security Tab -->
                <div class="tab-pane fade" id="security" role="tabpanel">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">Keamanan Akun</h5>
                        </div>
                        <div class="card-body">
                            <div class="mb-4">
                                <h6>Ganti Password</h6>
                                <p>Untuk keamanan akun Anda, disarankan untuk mengganti password secara berkala.</p>
                                <a href="change-password.php" class="btn btn-warning">Ganti Password</a>
                            </div>
                            <div class="mb-4">
                                <h6>Aktivitas Login</h6>
                                <p>Monitor aktivitas login terakhir Anda untuk keamanan akun.</p>
                                <small class="text-muted">Login terakhir: <?php echo $user['last_login'] ? date('d M Y H:i', strtotime($user['last_login'])) : 'Belum pernah login'; ?></small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
<script src="assets/js/main.js"></script>
</body>
</html>