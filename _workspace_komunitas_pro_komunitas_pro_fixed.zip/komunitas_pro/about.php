<?php
require_once 'config.php';
$isLoggedIn = isLoggedIn();
if ($isLoggedIn) {
    $user = getCurrentUser();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tentang Kami - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/unified.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php if ($isLoggedIn): ?>
        <?php include 'includes/header.php'; ?>
    <?php endif; ?>
    
    <div class="container">
        <div style="max-width: 800px; margin: 40px auto; background: white; padding: 40px; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
            <h1 style="color: #3498db; margin-bottom: 20px;">Tentang Kami</h1>
            
            <section style="margin-bottom: 30px;">
                <h2 style="color: #2c3e50; margin-bottom: 15px;">Selamat Datang di <?php echo SITE_NAME; ?></h2>
                <p style="line-height: 1.8; color: #555;">
                    <?php echo SITE_NAME; ?> adalah platform komunitas dan marketplace yang menggabungkan kekuatan media sosial dengan kemudahan bertransaksi. 
                    Kami menyediakan ruang bagi pengguna untuk berbagi konten, berinteraksi dengan komunitas, dan melakukan jual beli produk digital maupun fisik.
                </p>
            </section>
            
            <section style="margin-bottom: 30px;">
                <h2 style="color: #2c3e50; margin-bottom: 15px;">Visi Kami</h2>
                <p style="line-height: 1.8; color: #555;">
                    Menjadi platform terdepan yang menghubungkan komunitas dan memfasilitasi transaksi dengan aman, mudah, dan terpercaya.
                </p>
            </section>
            
            <section style="margin-bottom: 30px;">
                <h2 style="color: #2c3e50; margin-bottom: 15px;">Misi Kami</h2>
                <ul style="line-height: 1.8; color: #555;">
                    <li>Menyediakan platform yang user-friendly untuk berbagi dan berjualan</li>
                    <li>Membangun komunitas yang aktif dan saling mendukung</li>
                    <li>Menjamin keamanan transaksi dengan sistem wallet yang terpercaya</li>
                    <li>Memberikan pengalaman terbaik dalam berinteraksi dan bertransaksi online</li>
                </ul>
            </section>
            
            <section style="margin-bottom: 30px;">
                <h2 style="color: #2c3e50; margin-bottom: 15px;">Fitur Unggulan</h2>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-top: 20px;">
                    <div style="padding: 20px; background: #f8f9fa; border-radius: 8px; text-align: center;">
                        <i class="fas fa-users" style="font-size: 40px; color: #3498db; margin-bottom: 10px;"></i>
                        <h3 style="font-size: 16px; margin-bottom: 10px;">Komunitas Aktif</h3>
                        <p style="font-size: 14px; color: #666;">Berbagi dan berinteraksi dengan pengguna lain</p>
                    </div>
                    <div style="padding: 20px; background: #f8f9fa; border-radius: 8px; text-align: center;">
                        <i class="fas fa-shopping-bag" style="font-size: 40px; color: #2ecc71; margin-bottom: 10px;"></i>
                        <h3 style="font-size: 16px; margin-bottom: 10px;">Marketplace</h3>
                        <p style="font-size: 14px; color: #666;">Jual beli produk dengan mudah dan aman</p>
                    </div>
                    <div style="padding: 20px; background: #f8f9fa; border-radius: 8px; text-align: center;">
                        <i class="fas fa-wallet" style="font-size: 40px; color: #f39c12; margin-bottom: 10px;"></i>
                        <h3 style="font-size: 16px; margin-bottom: 10px;">Wallet System</h3>
                        <p style="font-size: 14px; color: #666;">Kelola keuangan dengan sistem wallet terintegrasi</p>
                    </div>
                    <div style="padding: 20px; background: #f8f9fa; border-radius: 8px; text-align: center;">
                        <i class="fas fa-comments" style="font-size: 40px; color: #e74c3c; margin-bottom: 10px;"></i>
                        <h3 style="font-size: 16px; margin-bottom: 10px;">Real-time Chat</h3>
                        <p style="font-size: 14px; color: #666;">Komunikasi langsung dengan pengguna lain</p>
                    </div>
                </div>
            </section>
            
            <section style="margin-bottom: 30px;">
                <h2 style="color: #2c3e50; margin-bottom: 15px;">Hubungi Kami</h2>
                <p style="line-height: 1.8; color: #555;">
                    <strong>Email:</strong> <?php echo SITE_EMAIL; ?><br>
                    <strong>Website:</strong> <?php echo SITE_URL; ?>
                </p>
            </section>
            
            <section style="background: #fff3cd; padding: 20px; border-radius: 8px; text-align: center;">
                <h3 style="margin-bottom: 10px;">Ingin Belajar Lebih Banyak?</h3>
                <p style="margin-bottom: 15px;">Subscribe channel YouTube kami untuk tutorial dan tips menarik!</p>
                <a href="https://youtube.com/@kursibiru" target="_blank" class="btn btn-danger">
                    <i class="fab fa-youtube"></i> Subscribe kursibiru
                </a>
            </section>
        </div>
    </div>
    
    <?php if ($isLoggedIn): ?>
        <?php include 'includes/footer.php'; ?>
    <?php endif; ?>
</body>
</html>