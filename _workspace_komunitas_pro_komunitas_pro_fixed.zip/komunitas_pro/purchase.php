<?php
require_once 'config.php';
requireLogin();

$currentUser = getCurrentUser();
$conn = getDBConnection();

// Get post ID (support both 'id' and 'post_id' parameters)
$postId = intval($_GET['id'] ?? $_GET['post_id'] ?? 0);

if (!$postId) {
    setFlashMessage('danger', 'Produk tidak ditemukan');
    redirect('index.php');
}

// Get product details
$stmt = $conn->prepare("
    SELECT p.*, u.username, u.full_name, u.profile_photo, u.id as seller_id
    FROM posts p
    JOIN users u ON p.user_id = u.id
    WHERE p.id = ? AND p.post_type = 'product' AND p.status = 'active'
");
$stmt->execute([$postId]);
$product = $stmt->fetch();

if (!$product) {
    setFlashMessage('danger', 'Produk tidak ditemukan atau tidak tersedia');
    redirect('index.php');
}

// Check if user is trying to buy their own product
if ($product['seller_id'] == $currentUser['id']) {
    setFlashMessage('danger', 'Anda tidak dapat membeli produk sendiri');
    redirect('index.php');
}

// Check if user already purchased this product
$stmt = $conn->prepare("SELECT id FROM purchases WHERE buyer_id = ? AND post_id = ? AND status = 'completed'");
$stmt->execute([$currentUser['id'], $postId]);
$alreadyPurchased = $stmt->fetch();

// Handle purchase
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$alreadyPurchased) {
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        setFlashMessage('danger', 'Invalid CSRF token');
    } else {
        $paymentMethod = $_POST['payment_method'] ?? 'wallet';
        
        if ($paymentMethod === 'wallet') {
            // Check if user has enough balance
            if ($currentUser['wallet_balance'] < $product['product_price']) {
                setFlashMessage('danger', 'Saldo tidak mencukupi. Silakan top up terlebih dahulu.');
            } else {
                try {
                    $conn->beginTransaction();
                    
                    // Deduct from buyer's wallet
                    $stmt = $conn->prepare("UPDATE users SET wallet_balance = wallet_balance - ? WHERE id = ?");
                    $stmt->execute([$product['product_price'], $currentUser['id']]);
                    
                    // Add to seller's wallet
                    $stmt = $conn->prepare("UPDATE users SET wallet_balance = wallet_balance + ? WHERE id = ?");
                    $stmt->execute([$product['product_price'], $product['seller_id']]);
                    
                    // Create transaction for buyer
                    $stmt = $conn->prepare("
                        INSERT INTO transactions (user_id, transaction_type, amount, fee, net_amount, payment_method, status, related_post_id)
                        VALUES (?, 'purchase', ?, 0, ?, 'wallet', 'completed', ?)
                    ");
                    $stmt->execute([$currentUser['id'], $product['product_price'], $product['product_price'], $postId]);
                    $buyerTransactionId = $conn->lastInsertId();
                    
                    // Create transaction for seller
                    $stmt = $conn->prepare("
                        INSERT INTO transactions (user_id, transaction_type, amount, fee, net_amount, payment_method, status, related_post_id)
                        VALUES (?, 'sale', ?, 0, ?, 'wallet', 'completed', ?)
                    ");
                    $stmt->execute([$product['seller_id'], $product['product_price'], $product['product_price'], $postId]);
                    
                    // Create purchase record
                    $stmt = $conn->prepare("
                        INSERT INTO purchases (buyer_id, seller_id, post_id, transaction_id, amount, status)
                        VALUES (?, ?, ?, ?, ?, 'completed')
                    ");
                    $stmt->execute([$currentUser['id'], $product['seller_id'], $postId, $buyerTransactionId, $product['product_price']]);
                    
                    // Create notifications
                    createNotification(
                        $currentUser['id'],
                        'purchase',
                        'Pembelian Berhasil',
                        'Anda telah membeli ' . $product['title'],
                        'purchase.php?id=' . $postId
                    );
                    
                    createNotification(
                        $product['seller_id'],
                        'sale',
                        'Produk Terjual',
                        $currentUser['full_name'] . ' membeli ' . $product['title'],
                        'wallet.php'
                    );
                    
                    $conn->commit();
                    
                    setFlashMessage('success', 'Pembelian berhasil! Anda dapat mengunduh produk sekarang.');
                    redirect('purchase.php?id=' . $postId);
                    
                } catch (Exception $e) {
                    $conn->rollBack();
                    setFlashMessage('danger', 'Terjadi kesalahan saat memproses pembelian');
                }
            }
        } else {
            setFlashMessage('info', 'Metode pembayaran lain akan segera tersedia');
        }
    }
}

$flashMessage = getFlashMessage();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($product['title']); ?> - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/unified.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .purchase-container {
            max-width: 1000px;
            margin: 0 auto;
            padding: 20px;
        }
        .product-detail {
            background: white;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .product-header {
            display: flex;
            gap: 30px;
            margin-bottom: 30px;
        }
        .product-images {
            flex: 1;
        }
        .product-main-image {
            width: 100%;
            border-radius: 10px;
            margin-bottom: 10px;
        }
        .product-thumbnails {
            display: flex;
            gap: 10px;
        }
        .product-thumbnails img {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border-radius: 5px;
            cursor: pointer;
            border: 2px solid transparent;
        }
        .product-thumbnails img:hover,
        .product-thumbnails img.active {
            border-color: #007bff;
        }
        .product-info {
            flex: 1;
        }
        .product-title {
            font-size: 28px;
            font-weight: bold;
            margin-bottom: 15px;
        }
        .product-price {
            font-size: 32px;
            font-weight: bold;
            color: #28a745;
            margin-bottom: 20px;
        }
        .product-meta {
            display: flex;
            gap: 20px;
            margin-bottom: 20px;
            padding-bottom: 20px;
            border-bottom: 1px solid #eee;
        }
        .product-meta-item {
            display: flex;
            align-items: center;
            gap: 5px;
            color: #666;
        }
        .seller-info {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        .seller-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
        }
        .seller-name {
            font-weight: bold;
        }
        .product-description {
            margin-bottom: 30px;
        }
        .product-description h3 {
            margin-bottom: 10px;
        }
        .purchase-section {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
        }
        .purchase-form {
            max-width: 500px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .payment-methods {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        .payment-method {
            display: flex;
            align-items: center;
            padding: 15px;
            background: white;
            border: 2px solid #ddd;
            border-radius: 5px;
            cursor: pointer;
        }
        .payment-method:hover {
            border-color: #007bff;
        }
        .payment-method input[type="radio"] {
            margin-right: 10px;
        }
        .payment-method.disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }
        .wallet-balance {
            background: #e7f3ff;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        .btn-purchase {
            width: 100%;
            padding: 15px;
            background: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
        }
        .btn-purchase:hover {
            background: #218838;
        }
        .btn-purchase:disabled {
            background: #ccc;
            cursor: not-allowed;
        }
        .already-purchased {
            background: #d4edda;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            margin-bottom: 20px;
        }
        .download-section {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .btn-download {
            display: inline-block;
            padding: 15px 30px;
            background: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
        }
        .btn-download:hover {
            background: #0056b3;
        }
        @media (max-width: 768px) {
            .product-header {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <div class="purchase-container">
        <?php if ($flashMessage): ?>
            <div class="alert alert-<?php echo $flashMessage['type']; ?>">
                <?php echo $flashMessage['message']; ?>
            </div>
        <?php endif; ?>
        
        <?php if ($alreadyPurchased): ?>
            <div class="already-purchased">
                <i class="fas fa-check-circle" style="font-size: 48px; color: #28a745; margin-bottom: 10px;"></i>
                <h2>Anda sudah membeli produk ini</h2>
                <p>Anda dapat mengunduh produk kapan saja</p>
            </div>
        <?php endif; ?>
        
        <div class="product-detail">
            <div class="product-header">
                <div class="product-images">
                    <?php 
                    $images = !empty($product['images']) ? json_decode($product['images'], true) : [];
                    $mainImage = !empty($images) ? $images[0] : 'default-product.png';
                    ?>
                    <img src="uploads/posts/<?php echo htmlspecialchars($mainImage); ?>" alt="Product" class="product-main-image" id="mainImage">
                    
                    <?php if (count($images) > 1): ?>
                        <div class="product-thumbnails">
                            <?php foreach ($images as $index => $image): ?>
                                <img src="uploads/posts/<?php echo htmlspecialchars($image); ?>" 
                                     alt="Thumbnail" 
                                     class="<?php echo $index === 0 ? 'active' : ''; ?>"
                                     onclick="changeMainImage('uploads/posts/<?php echo htmlspecialchars($image); ?>', this)">
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
                
                <div class="product-info">
                    <h1 class="product-title"><?php echo htmlspecialchars($product['title']); ?></h1>
                    
                    <div class="product-price">
                        Rp <?php echo number_format($product['product_price'], 0, ',', '.'); ?>
                    </div>
                    
                    <div class="product-meta">
                        <div class="product-meta-item">
                            <i class="fas fa-tag"></i>
                            <span><?php echo htmlspecialchars($product['product_category'] ?? 'Umum'); ?></span>
                        </div>
                        <div class="product-meta-item">
                            <i class="fas fa-box"></i>
                            <span><?php echo $product['product_type'] === 'digital' ? 'Produk Digital' : 'Produk Fisik'; ?></span>
                        </div>
                        <div class="product-meta-item">
                            <i class="fas fa-eye"></i>
                            <span><?php echo $product['views']; ?> views</span>
                        </div>
                    </div>
                    
                    <div class="seller-info">
                        <img src="uploads/profiles/<?php echo htmlspecialchars($product['profile_photo']); ?>" alt="Seller" class="seller-avatar">
                        <div>
                            <div class="seller-name"><?php echo htmlspecialchars($product['full_name']); ?></div>
                            <div style="font-size: 14px; color: #666;">@<?php echo htmlspecialchars($product['username']); ?></div>
                        </div>
                        <a href="profile.php?id=<?php echo $product['seller_id']; ?>" class="btn btn-sm btn-outline-primary" style="margin-left: auto;">
                            Lihat Profil
                        </a>
                    </div>
                </div>
            </div>
            
            <div class="product-description">
                <h3>Deskripsi Produk</h3>
                <p><?php echo nl2br(htmlspecialchars($product['content'])); ?></p>
            </div>
            
            <?php if (!$alreadyPurchased): ?>
                <div class="purchase-section">
                    <h3>Beli Produk Ini</h3>
                    
                    <div class="wallet-balance">
                        <strong>Saldo Wallet Anda:</strong> Rp <?php echo number_format($currentUser['wallet_balance'], 0, ',', '.'); ?>
                        <?php if ($currentUser['wallet_balance'] < $product['product_price']): ?>
                            <div style="color: #dc3545; margin-top: 5px;">
                                <i class="fas fa-exclamation-triangle"></i> Saldo tidak mencukupi. 
                                <a href="wallet.php">Top up sekarang</a>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <form method="POST" class="purchase-form">
                        <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                        
                        <div class="form-group">
                            <label>Metode Pembayaran</label>
                            <div class="payment-methods">
                                <label class="payment-method">
                                    <input type="radio" name="payment_method" value="wallet" checked>
                                    <div>
                                        <strong>Wallet</strong>
                                        <div style="font-size: 14px; color: #666;">Bayar menggunakan saldo wallet</div>
                                    </div>
                                </label>
                                
                                <label class="payment-method disabled">
                                    <input type="radio" name="payment_method" value="midtrans" disabled>
                                    <div>
                                        <strong>Midtrans</strong>
                                        <div style="font-size: 14px; color: #666;">Segera hadir</div>
                                    </div>
                                </label>
                            </div>
                        </div>
                        
                        <button type="submit" class="btn-purchase" <?php echo $currentUser['wallet_balance'] < $product['product_price'] ? 'disabled' : ''; ?>>
                            <i class="fas fa-shopping-cart"></i> Beli Sekarang
                        </button>
                    </form>
                </div>
            <?php else: ?>
                <div class="download-section">
                    <h3>Download Produk</h3>
                    <?php if ($product['product_type'] === 'digital' && !empty($product['product_file'])): ?>
                        <p>Klik tombol di bawah untuk mengunduh produk digital Anda:</p>
                        <a href="api/download-product.php?id=<?php echo $postId; ?>" class="btn-download">
                            <i class="fas fa-download"></i> Download Produk
                        </a>
                    <?php else: ?>
                        <p>Terima kasih atas pembelian Anda! Penjual akan segera menghubungi Anda untuk pengiriman produk.</p>
                        <a href="chat.php?user=<?php echo $product['seller_id']; ?>" class="btn-download">
                            <i class="fas fa-comment"></i> Chat Penjual
                        </a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <?php include 'includes/footer.php'; ?>
    
    <script>
        function changeMainImage(src, element) {
            document.getElementById('mainImage').src = src;
            document.querySelectorAll('.product-thumbnails img').forEach(img => {
                img.classList.remove('active');
            });
            element.classList.add('active');
        }
    </script>
</body>
</html>