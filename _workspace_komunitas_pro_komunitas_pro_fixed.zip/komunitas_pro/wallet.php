<?php
require_once 'config.php';
requireLogin();

$user = getCurrentUser();
$conn = getDBConnection();

// Get transaction history
$stmt = $conn->prepare("SELECT * FROM transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT 50");
$stmt->execute([$user['id']]);
$transactions = $stmt->fetchAll();

// Get purchase history
$stmt = $conn->prepare("
    SELECT p.*, po.title as product_title, u.username as seller_name 
    FROM purchases p 
    JOIN posts po ON p.post_id = po.id 
    JOIN users u ON p.seller_id = u.id 
    WHERE p.buyer_id = ? 
    ORDER BY p.created_at DESC 
    LIMIT 20
");
$stmt->execute([$user['id']]);
$purchases = $stmt->fetchAll();

// Handle deposit request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        setFlashMessage('danger', 'Invalid CSRF token');
    } else {
        $action = $_POST['action'];
        
        if ($action === 'deposit_manual') {
            $amount = floatval($_POST['amount']);
            
            if ($amount < 10000) {
                setFlashMessage('danger', 'Minimal deposit Rp 10.000');
            } else {
                // Generate unique code
                $uniqueCode = rand(100, 999);
                $totalAmount = $amount + $uniqueCode;
                
                // Handle proof upload
                $proofImage = '';
                if (isset($_FILES['proof']) && $_FILES['proof']['error'] === UPLOAD_ERR_OK) {
                    $upload = uploadFile($_FILES['proof'], 'uploads/proofs/', ['jpg', 'jpeg', 'png']);
                    if ($upload['success']) {
                        $proofImage = $upload['filename'];
                    }
                }
                
                $stmt = $conn->prepare("INSERT INTO transactions (user_id, transaction_type, amount, unique_code, net_amount, payment_method, proof_image, status) VALUES (?, 'deposit', ?, ?, ?, 'manual', ?, 'pending')");
                $stmt->execute([$user['id'], $totalAmount, $uniqueCode, $amount, $proofImage]);
                
                createNotification($user['id'], 'transaction', 'Deposit Pending', 'Deposit Anda sebesar ' . formatCurrency($totalAmount) . ' sedang diproses', 'wallet.php');
                
                setFlashMessage('success', 'Permintaan deposit berhasil dikirim. Total transfer: ' . formatCurrency($totalAmount));
                redirect('wallet.php');
            }
        } elseif ($action === 'withdraw') {
            $amount = floatval($_POST['amount']);
            $minWithdraw = MIN_WITHDRAWAL_AMOUNT;
            
            if ($amount < $minWithdraw) {
                setFlashMessage('danger', 'Minimal penarikan Rp ' . number_format($minWithdraw, 0, ',', '.'));
            } elseif ($amount > $user['wallet_balance']) {
                setFlashMessage('danger', 'Saldo tidak mencukupi');
            } else {
                $fee = $amount * (WITHDRAWAL_FEE_PERCENT / 100);
                $netAmount = $amount - $fee;
                
                // Deduct from wallet
                $stmt = $conn->prepare("UPDATE users SET wallet_balance = wallet_balance - ? WHERE id = ?");
                $stmt->execute([$amount, $user['id']]);
                
                // Create transaction
                $stmt = $conn->prepare("INSERT INTO transactions (user_id, transaction_type, amount, fee, net_amount, status) VALUES (?, 'withdrawal', ?, ?, ?, 'pending')");
                $stmt->execute([$user['id'], $amount, $fee, $netAmount]);
                
                createNotification($user['id'], 'transaction', 'Penarikan Diproses', 'Penarikan sebesar ' . formatCurrency($netAmount) . ' sedang diproses', 'wallet.php');
                
                setFlashMessage('success', 'Permintaan penarikan berhasil. Anda akan menerima ' . formatCurrency($netAmount) . ' (fee ' . WITHDRAWAL_FEE_PERCENT . '%)');
                redirect('wallet.php');
            }
        }
    }
}

$page_title = 'Dompet Digital';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/unified.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<?php include 'includes/header.php'; ?>

<div class="container mt-4">
    <div class="wallet-container">
        <!-- Balance Card -->
        <div class="balance-card">
            <div class="balance-header">
                <h2>Saldo Anda</h2>
                <span class="balance-amount"><?php echo formatCurrency($user['wallet_balance']); ?></span>
            </div>
            <div class="balance-actions">
                <button class="btn btn-success" onclick="showDepositModal()">
                    <i class="fas fa-plus"></i> Top Up
                </button>
                <button class="btn btn-danger" onclick="showWithdrawModal()">
                    <i class="fas fa-minus"></i> Tarik
                </button>
            </div>
        </div>

        <!-- Statistics -->
        <div class="stats-grid">
            <div class="stat-card">
                <i class="fas fa-arrow-down text-success"></i>
                <div>
                    <span class="stat-label">Total Deposit</span>
                    <?php
                    $stmt = $conn->prepare("SELECT SUM(net_amount) as total FROM transactions WHERE user_id = ? AND transaction_type = 'deposit' AND status = 'completed'");
                    $stmt->execute([$user['id']]);
                    $totalDeposit = $stmt->fetch()['total'] ?? 0;
                    ?>
                    <span class="stat-value"><?php echo formatCurrency($totalDeposit); ?></span>
                </div>
            </div>

            <div class="stat-card">
                <i class="fas fa-arrow-up text-danger"></i>
                <div>
                    <span class="stat-label">Total Penarikan</span>
                    <?php
                    $stmt = $conn->prepare("SELECT SUM(amount) as total FROM transactions WHERE user_id = ? AND transaction_type = 'withdrawal' AND status = 'completed'");
                    $stmt->execute([$user['id']]);
                    $totalWithdraw = $stmt->fetch()['total'] ?? 0;
                    ?>
                    <span class="stat-value"><?php echo formatCurrency($totalWithdraw); ?></span>
                </div>
            </div>

            <div class="stat-card">
                <i class="fas fa-shopping-cart text-primary"></i>
                <div>
                    <span class="stat-label">Total Pembelian</span>
                    <?php
                    $stmt = $conn->prepare("SELECT SUM(amount) as total FROM transactions WHERE user_id = ? AND transaction_type = 'purchase' AND status = 'completed'");
                    $stmt->execute([$user['id']]);
                    $totalPurchase = $stmt->fetch()['total'] ?? 0;
                    ?>
                    <span class="stat-value"><?php echo formatCurrency($totalPurchase); ?></span>
                </div>
            </div>

            <div class="stat-card">
                <i class="fas fa-dollar-sign text-warning"></i>
                <div>
                    <span class="stat-label">Total Penjualan</span>
                    <?php
                    $stmt = $conn->prepare("SELECT SUM(net_amount) as total FROM transactions WHERE user_id = ? AND transaction_type = 'sale' AND status = 'completed'");
                    $stmt->execute([$user['id']]);
                    $totalSale = $stmt->fetch()['total'] ?? 0;
                    ?>
                    <span class="stat-value"><?php echo formatCurrency($totalSale); ?></span>
                </div>
            </div>
        </div>

        <!-- Purchase History -->
        <div class="purchase-history mt-4">
            <h2>Riwayat Pembelian</h2>
            
            <?php if (empty($purchases)): ?>
                <div class="empty-state">
                    <i class="fas fa-shopping-bag"></i>
                    <p>Belum ada pembelian</p>
                </div>
            <?php else: ?>
                <div class="purchase-list">
                    <?php foreach ($purchases as $purchase): ?>
                        <div class="purchase-item">
                            <div class="purchase-info">
                                <h5><?php echo htmlspecialchars($purchase['product_title']); ?></h5>
                                <p class="text-muted">Penjual: <?php echo htmlspecialchars($purchase['seller_name']); ?></p>
                                <small class="text-muted"><?php echo date('d M Y H:i', strtotime($purchase['created_at'])); ?></small>
                            </div>
                            <div class="purchase-amount">
                                <strong>Rp <?php echo number_format($purchase['amount'], 0, ',', '.'); ?></strong>
                                <br>
                                <span class="status-badge status-<?php echo $purchase['confirmation_status']; ?>">
                                    <?php 
                                    $status_labels = [
                                        'pending' => 'Menunggu Konfirmasi',
                                        'buyer_confirmed' => 'Menunggu Konfirmasi Penjual',
                                        'seller_confirmed' => 'Menunggu Konfirmasi Admin',
                                        'admin_confirmed' => 'Selesai',
                                        'completed' => 'Selesai'
                                    ];
                                    echo $status_labels[$purchase['confirmation_status']] ?? $purchase['confirmation_status'];
                                    ?>
                                </span>
                            </div>
                            <div class="purchase-actions">
                                <?php if ($purchase['confirmation_status'] === 'pending'): ?>
                                    <a href="confirm-purchase.php?id=<?php echo $purchase['id']; ?>" class="btn btn-primary btn-sm">
                                        <i class="fas fa-check"></i> Konfirmasi
                                    </a>
                                <?php elseif ($purchase['confirmation_status'] === 'buyer_confirmed'): ?>
                                    <span class="text-muted">Menunggu penjual konfirmasi</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Transaction History -->
        <div class="transaction-history mt-4">
            <h2>Riwayat Transaksi</h2>
            
            <?php if (empty($transactions)): ?>
                <div class="empty-state">
                    <i class="fas fa-receipt"></i>
                    <p>Belum ada transaksi</p>
                </div>
            <?php else: ?>
                <div class="transaction-list">
                    <?php foreach ($transactions as $transaction): ?>
                        <div class="transaction-item">
                            <div class="transaction-icon">
                                <?php
                                $iconClass = '';
                                $iconColor = '';
                                switch ($transaction['transaction_type']) {
                                    case 'deposit':
                                        $iconClass = 'fa-arrow-down';
                                        $iconColor = 'text-success';
                                        break;
                                    case 'withdrawal':
                                        $iconClass = 'fa-arrow-up';
                                        $iconColor = 'text-danger';
                                        break;
                                    case 'purchase':
                                        $iconClass = 'fa-shopping-cart';
                                        $iconColor = 'text-primary';
                                        break;
                                    case 'sale':
                                        $iconClass = 'fa-dollar-sign';
                                        $iconColor = 'text-warning';
                                        break;
                                    default:
                                        $iconClass = 'fa-exchange-alt';
                                        $iconColor = 'text-info';
                                }
                                ?>
                                <i class="fas <?php echo $iconClass; ?> <?php echo $iconColor; ?>"></i>
                            </div>
                            <div class="transaction-details">
                                <h5><?php echo ucfirst($transaction['transaction_type']); ?></h5>
                                <p class="text-muted"><?php echo date('d M Y H:i', strtotime($transaction['created_at'])); ?></p>
                                <?php if ($transaction['payment_method']): ?>
                                    <small>Metode: <?php echo ucfirst($transaction['payment_method']); ?></small>
                                <?php endif; ?>
                            </div>
                            <div class="transaction-amount">
                                <?php
                                $amountClass = '';
                                $prefix = '';
                                if ($transaction['transaction_type'] === 'deposit' || $transaction['transaction_type'] === 'sale') {
                                    $amountClass = 'text-success';
                                    $prefix = '+';
                                } else {
                                    $amountClass = 'text-danger';
                                    $prefix = '-';
                                }
                                ?>
                                <span class="<?php echo $amountClass; ?>">
                                    <?php echo $prefix . formatCurrency($transaction['amount']); ?>
                                </span>
                                <br>
                                <span class="status-badge status-<?php echo $transaction['status']; ?>">
                                    <?php echo ucfirst($transaction['status']); ?>
                                </span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Deposit Modal -->
<div id="depositModal" class="modal" style="display: none;">
    <div class="modal-content">
        <div class="modal-header">
            <h5>Top Up Saldo</h5>
            <button type="button" onclick="closeDepositModal()">&times;</button>
        </div>
        <div class="modal-body">
            <form method="POST" enctype="multipart/form-data">
                <?php echo generateCSRFToken(); ?>
                <input type="hidden" name="action" value="deposit_manual">
                
                <div class="form-group">
                    <label for="amount">Jumlah Deposit</label>
                    <input type="number" class="form-control" id="amount" name="amount" min="10000" step="1000" required>
                    <small class="text-muted">Minimal Rp 10.000</small>
                </div>
                
                <div class="form-group">
                    <label for="proof">Upload Bukti Transfer</label>
                    <input type="file" class="form-control" id="proof" name="proof" accept="image/*" required>
                    <small class="text-muted">Upload bukti transfer (JPG/PNG)</small>
                </div>
                
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i>
                    Transfer ke rekening:<br>
                    <strong>BCA - 1234567890 (PT. Komunitas Digital)</strong><br>
                    <small> sertakan 3 digit angka unik saat transfer</small>
                </div>
                
                <button type="submit" class="btn btn-success w-100">Kirim Permintaan</button>
            </form>
        </div>
    </div>
</div>

<!-- Withdraw Modal -->
<div id="withdrawModal" class="modal" style="display: none;">
    <div class="modal-content">
        <div class="modal-header">
            <h5>Tarik Saldo</h5>
            <button type="button" onclick="closeWithdrawModal()">&times;</button>
        </div>
        <div class="modal-body">
            <form method="POST">
                <?php echo generateCSRFToken(); ?>
                <input type="hidden" name="action" value="withdraw">
                
                <div class="form-group">
                    <label for="withdrawAmount">Jumlah Penarikan</label>
                    <input type="number" class="form-control" id="withdrawAmount" name="amount" min="<?php echo MIN_WITHDRAWAL_AMOUNT; ?>" max="<?php echo $user['wallet_balance']; ?>" step="1000" required>
                    <small class="text-muted">Minimal Rp <?php echo number_format(MIN_WITHDRAWAL_AMOUNT, 0, ',', '.'); ?></small>
                </div>
                
                <div class="form-group">
                    <label>Rekening Tujuan</label>
                    <input type="text" class="form-control" value="<?php echo htmlspecialchars($user['bank_account'] ?? ''); ?>" readonly>
                    <small class="text-muted">Update rekening di halaman profil</small>
                </div>
                
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle"></i>
                    Fee penarikan: <?php echo WITHDRAWAL_FEE_PERCENT; ?>%<br>
                    <small>Anda akan menerima: <span id="netAmount">Rp 0</span></small>
                </div>
                
                <button type="submit" class="btn btn-danger w-100">Tarik Saldo</button>
            </form>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
<script>
function showDepositModal() {
    document.getElementById('depositModal').style.display = 'flex';
}

function closeDepositModal() {
    document.getElementById('depositModal').style.display = 'none';
}

function showWithdrawModal() {
    document.getElementById('withdrawModal').style.display = 'flex';
}

function closeWithdrawModal() {
    document.getElementById('withdrawModal').style.display = 'none';
}

// Calculate net amount for withdrawal
document.getElementById('withdrawAmount').addEventListener('input', function() {
    const amount = parseFloat(this.value) || 0;
    const fee = amount * (<?php echo WITHDRAWAL_FEE_PERCENT; ?> / 100);
    const netAmount = amount - fee;
    document.getElementById('netAmount').textContent = 'Rp ' + netAmount.toLocaleString('id-ID');
});

// Close modals when clicking outside
window.onclick = function(event) {
    if (event.target.classList.contains('modal')) {
        event.target.style.display = 'none';
    }
}
</script>
<script src="assets/js/main.js"></script>
</body>
</html>