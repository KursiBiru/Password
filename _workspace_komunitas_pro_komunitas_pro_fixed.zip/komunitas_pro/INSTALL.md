# Panduan Instalasi Lengkap - Komunitas Marketplace

## Persiapan

### 1. Persyaratan Sistem
Pastikan server Anda memenuhi persyaratan berikut:
- PHP 7.4 atau lebih tinggi
- MySQL 5.7 atau lebih tinggi
- Apache/Nginx dengan mod_rewrite enabled
- PHP Extensions:
  - PDO
  - PDO_MySQL
  - GD Library
  - JSON
  - mbstring
  - OpenSSL

### 2. Cek PHP Extensions
Jalankan perintah berikut untuk mengecek extensions:
```bash
php -m
```

Pastikan extensions berikut terinstall:
- pdo
- pdo_mysql
- gd
- json
- mbstring
- openssl

## Instalasi di Localhost (XAMPP/WAMP)

### Step 1: Download dan Extract
1. Download source code
2. Extract ke folder `htdocs` (XAMPP) atau `www` (WAMP)
3. Rename folder menjadi `komunitas`

### Step 2: Buat Database
1. Buka phpMyAdmin (http://localhost/phpmyadmin)
2. Klik "New" untuk membuat database baru
3. Nama database: `komunitas_marketplace`
4. Collation: `utf8mb4_unicode_ci`
5. Klik "Create"

### Step 3: Import Database
1. Pilih database `komunitas_marketplace`
2. Klik tab "Import"
3. Klik "Choose File" dan pilih `database.sql`
4. Scroll ke bawah dan klik "Go"
5. Tunggu hingga proses selesai

### Step 4: Konfigurasi
1. Buka file `config.php`
2. Edit pengaturan database:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', ''); // Kosongkan untuk XAMPP
define('DB_NAME', 'komunitas_marketplace');
```

3. Edit URL website:
```php
define('SITE_URL', 'http://localhost/komunitas');
```

### Step 5: Setup Folder Upload
1. Pastikan folder `uploads` ada
2. Buat subfolder:
   - uploads/profiles
   - uploads/posts
   - uploads/products
   - uploads/proofs

3. Set permission (Windows: tidak perlu, Linux/Mac: jalankan):
```bash
chmod -R 755 uploads/
```

### Step 6: Copy Default Avatar
Copy file `default-avatar.png` ke folder `uploads/profiles/`

### Step 7: Akses Website
Buka browser dan akses:
```
http://localhost/komunitas
```

## Instalasi di Hosting (cPanel)

### Step 1: Upload Files
1. Login ke cPanel
2. Buka "File Manager"
3. Navigasi ke folder `public_html`
4. Upload semua file (bisa dalam bentuk ZIP)
5. Extract file ZIP

### Step 2: Buat Database
1. Di cPanel, buka "MySQL Databases"
2. Buat database baru (misal: `username_komunitas`)
3. Buat user database (misal: `username_admin`)
4. Set password yang kuat
5. Tambahkan user ke database dengan "All Privileges"

### Step 3: Import Database
1. Buka "phpMyAdmin" di cPanel
2. Pilih database yang baru dibuat
3. Klik tab "Import"
4. Upload file `database.sql`
5. Klik "Go"

### Step 4: Konfigurasi
1. Edit file `config.php` melalui File Manager atau FTP
2. Update pengaturan database:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'username_admin'); // Ganti dengan user database Anda
define('DB_PASS', 'password_anda'); // Ganti dengan password database
define('DB_NAME', 'username_komunitas'); // Ganti dengan nama database
```

3. Update URL:
```php
define('SITE_URL', 'https://yourdomain.com');
```

### Step 5: Set Permission
1. Set permission folder `uploads` menjadi 755
2. Set permission semua subfolder di `uploads` menjadi 755

### Step 6: SSL Certificate (Opsional tapi Direkomendasikan)
1. Di cPanel, buka "SSL/TLS Status"
2. Aktifkan AutoSSL atau install Let's Encrypt
3. Update `config.php` untuk menggunakan HTTPS

### Step 7: Test Website
Akses website Anda:
```
https://yourdomain.com
```

## Login Pertama Kali

### Akun Admin Default
- Username: `admin`
- Email: `admin@komunitas.com`
- Password: `admin123`

**PENTING:** Segera ganti password setelah login pertama!

### Cara Ganti Password Admin
1. Login sebagai admin
2. Klik menu user di kanan atas
3. Pilih "Pengaturan"
4. Ganti password
5. Simpan

## Konfigurasi Lanjutan

### 1. Email Configuration (Opsional)
Untuk fitur email (reset password, notifikasi):
1. Edit `config.php`
2. Tambahkan konfigurasi SMTP
3. Gunakan service seperti Gmail SMTP atau SendGrid

### 2. Midtrans Configuration (Opsional)
Untuk deposit otomatis:
1. Daftar di https://midtrans.com
2. Dapatkan Server Key dan Client Key
3. Login ke Admin Panel
4. Buka Settings
5. Isi Midtrans credentials
6. Pilih mode (Sandbox untuk testing, Production untuk live)

### 3. Backup Otomatis
Setup cron job untuk backup database:
```bash
0 2 * * * mysqldump -u username -p'password' komunitas_marketplace > /path/to/backup/db_$(date +\%Y\%m\%d).sql
```

### 4. Performance Optimization
1. Enable OPcache di PHP
2. Enable Gzip compression
3. Optimize images sebelum upload
4. Use CDN untuk static assets (opsional)

## Troubleshooting

### Error: "Database connection failed"
**Solusi:**
1. Cek kredensial database di `config.php`
2. Pastikan MySQL service berjalan
3. Cek apakah database sudah dibuat
4. Cek apakah user memiliki akses ke database

### Error: "Permission denied" saat upload
**Solusi:**
1. Set permission folder uploads: `chmod -R 755 uploads/`
2. Pastikan PHP memiliki akses write ke folder
3. Cek ownership folder (harus sama dengan web server user)

### CAPTCHA tidak muncul
**Solusi:**
1. Pastikan GD Library terinstall: `php -m | grep gd`
2. Restart web server
3. Clear browser cache

### Error 500 Internal Server Error
**Solusi:**
1. Cek error log: `tail -f /var/log/apache2/error.log`
2. Cek file `.htaccess`
3. Pastikan mod_rewrite enabled
4. Cek PHP error log

### Session tidak tersimpan
**Solusi:**
1. Cek permission folder session PHP
2. Pastikan session.save_path writable
3. Cek PHP configuration

### Upload file gagal
**Solusi:**
1. Cek `upload_max_filesize` di php.ini
2. Cek `post_max_size` di php.ini
3. Cek permission folder uploads
4. Cek disk space

## Maintenance

### Backup Rutin
1. **Database:** Backup setiap hari
2. **Files:** Backup setiap minggu
3. **Simpan backup di lokasi terpisah**

### Update Rutin
1. Update PHP ke versi terbaru
2. Update MySQL/MariaDB
3. Update dependencies
4. Monitor security advisories

### Monitoring
1. Monitor disk space
2. Monitor database size
3. Monitor error logs
4. Monitor traffic

## Security Checklist

- [ ] Ganti password admin default
- [ ] Aktifkan HTTPS
- [ ] Set permission file yang benar
- [ ] Disable directory listing
- [ ] Enable firewall
- [ ] Update PHP dan MySQL
- [ ] Backup database rutin
- [ ] Monitor log files
- [ ] Gunakan strong password
- [ ] Enable two-factor authentication (jika tersedia)

## Support

Jika mengalami masalah:
1. Cek dokumentasi di README.md
2. Cek error log
3. Search di Google
4. Tanya di forum
5. Contact support: info@komunitas.com

## Video Tutorial

Untuk tutorial video lengkap, subscribe channel YouTube:
**[@kursibiru](https://youtube.com/@kursibiru)**

---

**Selamat! Website Anda sudah siap digunakan! 🎉**