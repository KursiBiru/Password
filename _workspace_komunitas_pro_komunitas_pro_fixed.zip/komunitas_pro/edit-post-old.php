<?php
session_start();
require_once 'config.php';
requireLogin();

$currentUser = getCurrentUser();
$conn = getDBConnection();

$user_id = $_SESSION['user_id'];
$post_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (!$post_id) {
    redirect('index.php');
}

// Ambil data post
$stmt = $conn->prepare("SELECT * FROM posts WHERE id = ? AND user_id = ?");
$stmt->execute([$post_id, $user_id]);
$post = $stmt->fetch();

if (!$post) {
    $_SESSION['error'] = 'Post tidak ditemukan atau Anda tidak memiliki izin untuk mengeditnya.';
    redirect('index.php');
}

$error = '';
$success = '';

// Proses update post
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = sanitizeInput($_POST['title']);
    $content = sanitizeInput($_POST['content']);
    $category_id = sanitizeInput($_POST['product_category']);
    //$tags = sanitizeInput($_POST['tags']);
    $price = isset($_POST['product_price']) ? (float)$_POST['product_price'] : 0;
    $is_product = isset($_POST['product_type']) ? 1 : 0;
    $allow_comments = isset($_POST['allow_comments']) ? 1 : 0;
    
    // Validasi
    if (empty($title) || empty($content)) {
        $error = 'Judul dan konten wajib diisi!';
    } else {
        // Update post
        $stmt = $conn->prepare("UPDATE posts SET title = ?, content = ?, product_category = ?, product_price = ?, product_type = ?, allow_comments = ?, updated_at = NOW() WHERE id = ?");
        
        if ($stmt->execute([$title, $content, $category_id, $price, $is_product, $allow_comments, $post_id])) {
            
            // Handle upload gambar baru
            if (isset($_FILES['images']) && !empty($_FILES['images']['name'][0])) {
                // Hapus gambar lama
                $stmt = $pdo->prepare("SELECT image_path FROM post_images WHERE post_id = ?");
                $stmt->execute([$post_id]);
                $old_images = $stmt->fetchAll();
                
                foreach ($old_images as $old_image) {
                    if (file_exists($old_image['image_path'])) {
                        unlink($old_image['image_path']);
                    }
                }
                
                // Hapus record gambar lama
                $stmt = $conn->prepare("DELETE FROM post_images WHERE post_id = ?");
                $stmt->execute([$post_id]);
                
                // Upload gambar baru
                $image_paths = [];
                $total_images = count($_FILES['images']['name']);
                
                for ($i = 0; $i < $total_images; $i++) {
                    if ($_FILES['images']['error'][$i] === UPLOAD_ERR_OK) {
                        $file = [
                            'name' => $_FILES['images']['name'][$i],
                            'type' => $_FILES['images']['type'][$i],
                            'tmp_name' => $_FILES['images']['tmp_name'][$i],
                            'error' => $_FILES['images']['error'][$i],
                            'size' => $_FILES['images']['size'][$i]
                        ];
                        
                        $upload_result = uploadFile($file, 'uploads/posts/', ['jpg', 'jpeg', 'png', 'gif']);
                        
                        if ($upload_result['success']) {
                            $image_paths[] = $upload_result['file_path'];
                        }
                    }
                }
                
                // Insert gambar baru
                if (!empty($image_paths)) {
                    $stmt = $conn->prepare("INSERT INTO post_images (post_id, image_path) VALUES (?, ?)");
                    foreach ($image_paths as $image_path) {
                        $stmt->execute([$post_id, $image_path]);
                    }
                }
            }
            
            $success = 'Post berhasil diperbarui!';
            // Refresh data post
            $stmt = $conn->prepare("SELECT * FROM posts WHERE id = ?");
            $stmt->execute([$post_id]);
            $post = $stmt->fetch();
        } else {
            $error = 'Gagal memperbarui post!';
        }
    }
}

// Ambil kategori
//$categories = $conn->query("SELECT product_category FROM posts")->fetchAll();
// Ambil gambar post
/*$stmt = $conn->prepare("SELECT * FROM post_images WHERE post_id = ?");
$stmt->execute([$post_id]);
$post_images = $stmt->fetchAll();*/

$page_title = 'Edit Post';

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/unified.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<?php include 'includes/header.php'; ?>
<div class="container mt-4">
    <div class="row">
        <div class="col-md-8 offset-md-2">
            <h1 class="mb-4">Edit Post</h1>
            
            <?php if ($error): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <div class="card">
                <div class="card-body">
                    <form method="POST" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label for="title" class="form-label">Judul</label>
                            <input type="text" class="form-control" id="title" name="title" value="<?php echo htmlspecialchars($post['title']); ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="content" class="form-label">Konten</label>
                            <textarea class="form-control" id="content" name="content" rows="6" required><?php echo htmlspecialchars($post['content']); ?></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label for="product_category" class="form-label">Kategori</label>
                            <input type="text" class="form-control" id="product_category" name="product_category" value="<?php echo htmlspecialchars($post['product_category']); ?>" required>
                        </div>
                        <!--
                        <div class="mb-3">
                            <label for="tags" class="form-label">Tags (pisahkan dengan koma)</label>
                            <input type="text" class="form-control" id="tags" name="tags" value="<?php //echo htmlspecialchars($post['tags']); ?>" placeholder="contoh: teknologi, programming, web">
                        </div>
                        -->
                        <div class="mb-3">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="product_type" name="digital" <?php echo $post['product_type'] ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="product_type">
                                    Ini adalah produk digital
                                </label>
                            </div>
                        </div>
                        
                        <div class="mb-3" id="price_group" style="<?php echo $post['product_type'] ? '' : 'display: none;'; ?>">
                            <label for="product_price" class="form-label">Harga (Rp)</label>
                            <input type="number" class="form-control" id="product_price" name="product_price" value="<?php echo $post['product_price']; ?>" min="0" step="0.01">
                        </div>
                        
                        <div class="mb-3">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="allow_comments" name="allow_comments" <?php echo $post['allow_comments'] ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="allow_comments">
                                    Izinkan komentar
                                </label>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="images" class="form-label">Gambar (kosongkan jika tidak ingin mengubah)</label>
                            <input type="file" class="form-control" id="images" name="images[]" multiple accept="image/*">
                            <small class="form-text text-muted">Anda dapat memilih multiple gambar. Gambar lama akan diganti.</small>
                        </div>
                        
                        <?php if (!empty($post_images)): ?>
                            <div class="mb-3">
                                <label class="form-label">Gambar Saat Ini</label>
                                <div class="row">
                                    <?php foreach ($post_images as $image): ?>
                                        <div class="col-md-3 mb-2">
                                            <img src="<?php echo $image['image_path']; ?>" alt="Gambar Post" class="img-fluid rounded">
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        <?php endif; ?>
                        
                        <div class="d-flex justify-content-between">
                            <a href="index.php" class="btn btn-secondary">Batal</a>
                            <button type="submit" class="btn btn-primary">Update Post</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Toggle price field based on is_product checkbox
document.getElementById('product_type').addEventListener('change', function() {
    document.getElementById('price_group').style.display = this.checked ? '' : 'none';
});
</script>

<?php include 'includes/footer.php'; ?>
<script src="assets/js/main.js"></script>
</body>
</html>