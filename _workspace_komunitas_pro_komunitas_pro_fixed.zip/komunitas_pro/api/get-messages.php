<?php
require_once '../config.php';
requireLogin();

header('Content-Type: application/json');

$user = getCurrentUser();
$partnerId = $_GET['partner_id'] ?? null;

if (!$partnerId) {
    jsonResponse(['success' => false, 'message' => 'Partner ID required'], 400);
}

$conn = getDBConnection();

// Get messages
$stmt = $conn->prepare("
    SELECT m.*, u.username, u.full_name, u.profile_photo
    FROM messages m
    JOIN users u ON m.sender_id = u.id
    WHERE (m.sender_id = ? AND m.receiver_id = ?)
       OR (m.sender_id = ? AND m.receiver_id = ?)
    ORDER BY m.created_at ASC
");
$stmt->execute([$user['id'], $partnerId, $partnerId, $user['id']]);
$messages = $stmt->fetchAll();

// Mark messages as read
$stmt = $conn->prepare("UPDATE messages SET is_read = 1 WHERE sender_id = ? AND receiver_id = ?");
$stmt->execute([$partnerId, $user['id']]);

jsonResponse(['success' => true, 'messages' => $messages]);