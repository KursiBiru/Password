<?php
require_once '../config.php';
requireLogin();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'message' => 'Invalid request method'], 405);
}

$data = json_decode(file_get_contents('php://input'), true);
$postId = $data['post_id'] ?? null;

if (!$postId) {
    jsonResponse(['success' => false, 'message' => 'Post ID required'], 400);
}

$user = getCurrentUser();
$conn = getDBConnection();

// Check if user owns the post or is admin
$stmt = $conn->prepare("SELECT user_id FROM posts WHERE id = ?");
$stmt->execute([$postId]);
$post = $stmt->fetch();

if (!$post) {
    jsonResponse(['success' => false, 'message' => 'Post not found'], 404);
}

if ($post['user_id'] != $user['id'] && !$user['is_admin']) {
    jsonResponse(['success' => false, 'message' => 'Unauthorized'], 403);
}

// Delete post
$stmt = $conn->prepare("DELETE FROM posts WHERE id = ?");
if ($stmt->execute([$postId])) {
    jsonResponse(['success' => true, 'message' => 'Post deleted successfully']);
} else {
    jsonResponse(['success' => false, 'message' => 'Failed to delete post'], 500);
}