<?php
require_once '../config.php';
requireLogin();

header('Content-Type: application/json');

$user = getCurrentUser();
$conn = getDBConnection();

$page = $_GET['page'] ?? 1;
$limit = POSTS_PER_PAGE;
$offset = ($page - 1) * $limit;

$postType = $_GET['type'] ?? 'all';
$language = $_GET['lang'] ?? 'all';
$category = $_GET['category'] ?? 'all';

$query = "SELECT p.*, u.username, u.full_name, u.profile_photo,
          (SELECT COUNT(*) FROM likes WHERE post_id = p.id) as like_count,
          (SELECT COUNT(*) FROM comments WHERE post_id = p.id) as comment_count,
          (SELECT COUNT(*) FROM shares WHERE post_id = p.id) as share_count,
          (SELECT COUNT(*) FROM likes WHERE post_id = p.id AND user_id = ?) as user_liked
          FROM posts p
          JOIN users u ON p.user_id = u.id
          WHERE p.status = 'active'";

$params = [$user['id']];

if ($postType !== 'all') {
    $query .= " AND p.post_type = ?";
    $params[] = $postType;
}

if ($language !== 'all') {
    $query .= " AND p.language = ?";
    $params[] = $language;
}

if ($category !== 'all' && $postType === 'product') {
    $query .= " AND p.product_category = ?";
    $params[] = $category;
}

$query .= " ORDER BY p.created_at DESC LIMIT ? OFFSET ?";
$params[] = $limit;
$params[] = $offset;

$stmt = $conn->prepare($query);
$stmt->execute($params);
$posts = $stmt->fetchAll();

jsonResponse(['success' => true, 'posts' => $posts]);