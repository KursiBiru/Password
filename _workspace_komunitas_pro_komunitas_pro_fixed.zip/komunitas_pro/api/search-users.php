<?php
require_once '../config.php';
requireLogin();

header('Content-Type: application/json');

$query = $_GET['q'] ?? '';

if (strlen($query) < 2) {
    jsonResponse(['success' => false, 'message' => 'Query too short'], 400);
}

$conn = getDBConnection();
$searchTerm = "%$query%";

$stmt = $conn->prepare("
    SELECT id, username, full_name, profile_photo 
    FROM users 
    WHERE (username LIKE ? OR full_name LIKE ?) 
      AND id != ? 
      AND is_banned = 0
    LIMIT 10
");
$stmt->execute([$searchTerm, $searchTerm, $_SESSION['user_id']]);
$users = $stmt->fetchAll();

jsonResponse(['success' => true, 'users' => $users]);