<?php
require_once '../config.php';
requireLogin();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'message' => 'Invalid request method'], 405);
}

if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
    jsonResponse(['success' => false, 'message' => 'Invalid CSRF token'], 403);
}

$user = getCurrentUser();
$receiverId = $_POST['receiver_id'] ?? null;
$message = trim($_POST['message'] ?? '');

if (!$receiverId || empty($message)) {
    jsonResponse(['success' => false, 'message' => 'Receiver and message required'], 400);
}

$conn = getDBConnection();

// Check if receiver exists
$stmt = $conn->prepare("SELECT id FROM users WHERE id = ?");
$stmt->execute([$receiverId]);
if (!$stmt->fetch()) {
    jsonResponse(['success' => false, 'message' => 'Receiver not found'], 404);
}

// Insert message
$stmt = $conn->prepare("INSERT INTO messages (sender_id, receiver_id, message) VALUES (?, ?, ?)");
if ($stmt->execute([$user['id'], $receiverId, $message])) {
    // Create notification
    createNotification(
        $receiverId, 
        'message', 
        'Pesan Baru', 
        $user['full_name'] . ' mengirim pesan kepada Anda',
        'chat.php?user=' . $user['id']
    );
    
    jsonResponse(['success' => true, 'message' => 'Message sent']);
} else {
    jsonResponse(['success' => false, 'message' => 'Failed to send message'], 500);
}