<?php
require_once '../config.php';
requireLogin();

header('Content-Type: application/json');

$postId = $_GET['post_id'] ?? null;

if (!$postId) {
    jsonResponse(['success' => false, 'message' => 'Post ID required'], 400);
}

$conn = getDBConnection();

$stmt = $conn->prepare("
    SELECT c.*, u.username, u.full_name, u.profile_photo
    FROM comments c
    JOIN users u ON c.user_id = u.id
    WHERE c.post_id = ?
    ORDER BY c.created_at ASC
");
$stmt->execute([$postId]);
$comments = $stmt->fetchAll();

jsonResponse(['success' => true, 'comments' => $comments]);