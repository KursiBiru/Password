<?php
require_once '../config.php';
requireLogin();

header('Content-Type: application/json');

$user = getCurrentUser();
$conn = getDBConnection();

// Get unread notifications
$stmt = $conn->prepare("SELECT * FROM notifications WHERE user_id = ? AND is_read = 0 ORDER BY created_at DESC LIMIT 10");
$stmt->execute([$user['id']]);
$notifications = $stmt->fetchAll();

jsonResponse([
    'success' => true, 
    'notifications' => $notifications,
    'count' => count($notifications)
]);