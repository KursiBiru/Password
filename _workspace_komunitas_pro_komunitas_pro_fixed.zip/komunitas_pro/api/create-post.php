<?php
require_once '../config.php';
requireLogin();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'message' => 'Invalid request method'], 405);
}

if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
    jsonResponse(['success' => false, 'message' => 'Invalid CSRF token'], 403);
}

$user = getCurrentUser();
$conn = getDBConnection();

$title = sanitizeInput($_POST['title']);
$content = sanitizeInput($_POST['content']);
$postType = $_POST['post_type'] ?? 'community';
$language = $_POST['language'] ?? 'id';

// Validate
if (empty($title) || empty($content)) {
    jsonResponse(['success' => false, 'message' => 'Title and content required'], 400);
}

// Handle product fields
$productPrice = null;
$productCategory = null;
$productType = null;
$productFile = null;

if ($postType === 'product') {
    $productPrice = floatval($_POST['product_price'] ?? 0);
    $productCategory = sanitizeInput($_POST['product_category'] ?? '');
    $productType = $_POST['product_type'] ?? 'physical';
    
    if ($productPrice <= 0) {
        jsonResponse(['success' => false, 'message' => 'Invalid product price'], 400);
    }
    
    // Handle digital file upload
    if ($productType === 'digital' && isset($_FILES['product_file'])) {
        $upload = uploadFile($_FILES['product_file'], 'product');
        if ($upload['success']) {
            $productFile = $upload['filename'];
        }
    }
}

// Handle image uploads
$images = [];
if (isset($_FILES['images'])) {
    foreach ($_FILES['images']['tmp_name'] as $key => $tmp_name) {
        if ($_FILES['images']['error'][$key] === UPLOAD_ERR_OK) {
            $file = [
                'name' => $_FILES['images']['name'][$key],
                'type' => $_FILES['images']['type'][$key],
                'tmp_name' => $tmp_name,
                'error' => $_FILES['images']['error'][$key],
                'size' => $_FILES['images']['size'][$key]
            ];
            $upload = uploadFile($file, 'post');
            if ($upload['success']) {
                $images[] = $upload['filename'];
            }
        }
    }
}

$imagesJson = !empty($images) ? json_encode($images) : null;

// Insert post
$stmt = $conn->prepare("
    INSERT INTO posts (user_id, title, content, post_type, product_price, product_category, product_type, product_file, images, language)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
");

if ($stmt->execute([$user['id'], $title, $content, $postType, $productPrice, $productCategory, $productType, $productFile, $imagesJson, $language])) {
    jsonResponse(['success' => true, 'message' => 'Post created successfully']);
} else {
    jsonResponse(['success' => false, 'message' => 'Failed to create post'], 500);
}