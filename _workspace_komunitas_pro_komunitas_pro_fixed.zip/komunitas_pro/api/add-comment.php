<?php
require_once '../config.php';
requireLogin();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'message' => 'Invalid request method'], 405);
}

$data = json_decode(file_get_contents('php://input'), true);
$postId = $data['post_id'] ?? null;
$content = trim($data['content'] ?? '');
$parentId = $data['parent_id'] ?? null;

if (!$postId || empty($content)) {
    jsonResponse(['success' => false, 'message' => 'Post ID and content required'], 400);
}

$user = getCurrentUser();
$conn = getDBConnection();

// Insert comment
$stmt = $conn->prepare("INSERT INTO comments (post_id, user_id, parent_id, content) VALUES (?, ?, ?, ?)");
if ($stmt->execute([$postId, $user['id'], $parentId, $content])) {
    // Get post owner
    $stmt = $conn->prepare("SELECT user_id, title FROM posts WHERE id = ?");
    $stmt->execute([$postId]);
    $post = $stmt->fetch();
    
    // Create notification if not own post
    if ($post && $post['user_id'] != $user['id']) {
        createNotification(
            $post['user_id'],
            'comment',
            'Komentar Baru',
            $user['full_name'] . ' mengomentari postingan Anda: ' . $post['title'],
            'post-detail.php?id=' . $postId
        );
    }
    
    jsonResponse(['success' => true, 'message' => 'Comment added']);
} else {
    jsonResponse(['success' => false, 'message' => 'Failed to add comment'], 500);
}