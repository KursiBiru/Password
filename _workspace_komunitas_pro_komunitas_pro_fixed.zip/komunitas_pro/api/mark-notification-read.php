<?php
require_once '../config.php';
requireLogin();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'message' => 'Invalid request method'], 405);
}

$data = json_decode(file_get_contents('php://input'), true);
$notificationId = $data['notification_id'] ?? null;

if (!$notificationId) {
    jsonResponse(['success' => false, 'message' => 'Notification ID required'], 400);
}

$conn = getDBConnection();
$user = getCurrentUser();

$stmt = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?");
if ($stmt->execute([$notificationId, $user['id']])) {
    jsonResponse(['success' => true]);
} else {
    jsonResponse(['success' => false, 'message' => 'Failed to mark as read'], 500);
}