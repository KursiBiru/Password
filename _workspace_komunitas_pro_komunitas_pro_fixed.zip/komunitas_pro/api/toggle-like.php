<?php
require_once '../config.php';
requireLogin();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'message' => 'Invalid request method'], 405);
}

$data = json_decode(file_get_contents('php://input'), true);
$postId = $data['post_id'] ?? null;

if (!$postId) {
    jsonResponse(['success' => false, 'message' => 'Post ID required'], 400);
}

$user = getCurrentUser();
$conn = getDBConnection();

// Check if already liked
$stmt = $conn->prepare("SELECT id FROM likes WHERE post_id = ? AND user_id = ?");
$stmt->execute([$postId, $user['id']]);
$existingLike = $stmt->fetch();

if ($existingLike) {
    // Unlike
    $stmt = $conn->prepare("DELETE FROM likes WHERE post_id = ? AND user_id = ?");
    $stmt->execute([$postId, $user['id']]);
    $liked = false;
} else {
    // Like
    $stmt = $conn->prepare("INSERT INTO likes (post_id, user_id) VALUES (?, ?)");
    $stmt->execute([$postId, $user['id']]);
    $liked = true;
    
    // Get post owner
    $stmt = $conn->prepare("SELECT user_id, title FROM posts WHERE id = ?");
    $stmt->execute([$postId]);
    $post = $stmt->fetch();
    
    // Create notification if not own post
    if ($post && $post['user_id'] != $user['id']) {
        createNotification(
            $post['user_id'],
            'like',
            'Postingan Disukai',
            $user['full_name'] . ' menyukai postingan Anda: ' . $post['title'],
            'post-detail.php?id=' . $postId
        );
    }
}

// Get new like count
$stmt = $conn->prepare("SELECT COUNT(*) as count FROM likes WHERE post_id = ?");
$stmt->execute([$postId]);
$likeCount = $stmt->fetch()['count'];

jsonResponse([
    'success' => true, 
    'liked' => $liked,
    'like_count' => $likeCount
]);