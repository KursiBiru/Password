<?php
session_start();
require_once 'config.php';

if (isset($_SESSION['user_id'])) {
    redirect('index.php');
}

$conn = getDBConnection();
$token = isset($_GET['token']) ? sanitizeInput($_GET['token']) : '';

if (!$token) {
    redirect('login.php');
}

$error = '';
$success = '';

// Validasi token
$stmt = $conn->prepare("SELECT pr.*, u.email, u.username 
                       FROM password_resets pr 
                       JOIN users u ON pr.user_id = u.id 
                       WHERE pr.token = ? AND pr.expires_at > NOW() AND pr.used = 0");
$stmt->execute([$token]);
$reset_data = $stmt->fetch();

if (!$reset_data) {
    $_SESSION['error'] = 'Token reset password tidak valid atau telah kedaluwarsa.';
    redirect('login.php');
}

// Proses reset password
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password = $_POST['password'];
    $password_confirm = $_POST['password_confirm'];
    
    if (empty($password) || empty($password_confirm)) {
        $error = 'Semua field wajib diisi!';
    } elseif (strlen($password) < 6) {
        $error = 'Password minimal 6 karakter!';
    } elseif ($password !== $password_confirm) {
        $error = 'Password dan konfirmasi password tidak cocok!';
    } else {
        // Update password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
        
        if ($stmt->execute([$hashed_password, $reset_data['user_id']])) {
            // Tandai token sebagai sudah digunakan
            $stmt = $conn->prepare("UPDATE password_resets SET used = 1, used_at = NOW() WHERE id = ?");
            $stmt->execute([$reset_data['id']]);
            
            $success = 'Password berhasil direset. Anda dapat login dengan password baru.';
            
            // Redirect ke login setelah 3 detik
            header("refresh:3;url=login.php");
        } else {
            $error = 'Gagal mereset password!';
        }
    }
}

$page_title = 'Reset Password';
//include 'includes/header.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/unified.css">
    <link rel="stylesheet" href="assets/css/dark-mode.css">
</head>
<body class="auth-page">
<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header text-center">
                    <h4>Reset Password</h4>
                </div>
                <div class="card-body">
                    <?php if ($error): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                    <?php endif; ?>
                    
                    <?php if ($success): ?>
                        <div class="alert alert-success">
                            <?php echo $success; ?><br>
                            <small>Redirecting ke halaman login dalam 3 detik...</small>
                        </div>
                    <?php else: ?>
                        <p class="text-center mb-4">Reset password untuk akun <strong><?php echo htmlspecialchars($reset_data['username']); ?></strong></p>
                        
                        <form method="POST">
                            <div class="mb-3">
                                <label for="password" class="form-label">Password Baru</label>
                                <input type="password" class="form-control" id="password" name="password" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="password_confirm" class="form-label">Konfirmasi Password Baru</label>
                                <input type="password" class="form-control" id="password_confirm" name="password_confirm" required>
                            </div>
                            
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary">Reset Password</button>
                            </div>
                        </form>
                        
                        <div class="text-center mt-3">
                            <p>Ingat password Anda? <a href="login.php">Login di sini</a></p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php //include 'includes/footer.php'; ?>
<script src="assets/js/dark-mode.js"></script>
</body>
</html>