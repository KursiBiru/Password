<?php
require_once 'config.php';
$isLoggedIn = isLoggedIn();
if ($isLoggedIn) {
    $user = getCurrentUser();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kebijakan Privasi - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/unified.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php if ($isLoggedIn): ?>
        <?php include 'includes/header.php'; ?>
    <?php endif; ?>
    
    <div class="container">
        <div style="max-width: 800px; margin: 40px auto; background: white; padding: 40px; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
            <h1 style="color: #3498db; margin-bottom: 20px;">Kebijakan Privasi</h1>
            <p style="color: #7f8c8d; margin-bottom: 30px;">Terakhir diperbarui: <?php echo date('d F Y'); ?></p>
            
            <section style="margin-bottom: 30px;">
                <h2 style="color: #2c3e50; margin-bottom: 15px;">1. Informasi yang Kami Kumpulkan</h2>
                <p style="line-height: 1.8; color: #555;">
                    Kami mengumpulkan informasi yang Anda berikan secara langsung kepada kami, termasuk:<br><br>
                    <strong>1.1 Informasi Akun:</strong> Username, email, password, nama lengkap, nomor telepon, dan foto profil.<br>
                    <strong>1.2 Informasi Konten:</strong> Postingan, komentar, pesan, dan konten lain yang Anda buat atau bagikan.<br>
                    <strong>1.3 Informasi Transaksi:</strong> Riwayat transaksi, deposit, withdrawal, dan pembelian produk.<br>
                    <strong>1.4 Informasi Teknis:</strong> Alamat IP, jenis browser, sistem operasi, dan data penggunaan lainnya.
                </p>
            </section>
            
            <section style="margin-bottom: 30px;">
                <h2 style="color: #2c3e50; margin-bottom: 15px;">2. Bagaimana Kami Menggunakan Informasi</h2>
                <p style="line-height: 1.8; color: #555;">
                    Kami menggunakan informasi yang dikumpulkan untuk:<br><br>
                    • Menyediakan, memelihara, dan meningkatkan layanan kami<br>
                    • Memproses transaksi dan mengirim pemberitahuan terkait<br>
                    • Berkomunikasi dengan Anda tentang produk, layanan, dan promosi<br>
                    • Memantau dan menganalisis tren, penggunaan, dan aktivitas<br>
                    • Mendeteksi, mencegah, dan mengatasi masalah teknis dan keamanan<br>
                    • Mematuhi kewajiban hukum dan peraturan
                </p>
            </section>
            
            <section style="margin-bottom: 30px;">
                <h2 style="color: #2c3e50; margin-bottom: 15px;">3. Berbagi Informasi</h2>
                <p style="line-height: 1.8; color: #555;">
                    Kami tidak menjual informasi pribadi Anda. Kami dapat membagikan informasi dalam situasi berikut:<br><br>
                    <strong>3.1 Dengan Pengguna Lain:</strong> Informasi profil dan konten publik Anda dapat dilihat oleh pengguna lain.<br>
                    <strong>3.2 Dengan Penyedia Layanan:</strong> Kami dapat membagikan informasi dengan penyedia layanan pihak ketiga yang membantu kami mengoperasikan platform.<br>
                    <strong>3.3 Untuk Kepatuhan Hukum:</strong> Kami dapat mengungkapkan informasi jika diwajibkan oleh hukum atau untuk melindungi hak kami.
                </p>
            </section>
            
            <section style="margin-bottom: 30px;">
                <h2 style="color: #2c3e50; margin-bottom: 15px;">4. Keamanan Data</h2>
                <p style="line-height: 1.8; color: #555;">
                    Kami mengambil langkah-langkah keamanan yang wajar untuk melindungi informasi Anda dari akses, penggunaan, 
                    atau pengungkapan yang tidak sah. Ini termasuk:<br><br>
                    • Enkripsi data sensitif<br>
                    • Penggunaan CSRF token untuk mencegah serangan<br>
                    • Implementasi CAPTCHA untuk mencegah bot<br>
                    • Pemantauan aktivitas mencurigakan<br>
                    • Pembatasan akses ke informasi pribadi
                </p>
            </section>
            
            <section style="margin-bottom: 30px;">
                <h2 style="color: #2c3e50; margin-bottom: 15px;">5. Hak Anda</h2>
                <p style="line-height: 1.8; color: #555;">
                    Anda memiliki hak untuk:<br><br>
                    • Mengakses dan memperbarui informasi pribadi Anda<br>
                    • Menghapus akun Anda<br>
                    • Menolak penggunaan informasi Anda untuk tujuan tertentu<br>
                    • Meminta salinan data pribadi Anda<br>
                    • Mengajukan keluhan tentang pemrosesan data Anda
                </p>
            </section>
            
            <section style="margin-bottom: 30px;">
                <h2 style="color: #2c3e50; margin-bottom: 15px;">6. Cookies dan Teknologi Pelacakan</h2>
                <p style="line-height: 1.8; color: #555;">
                    Kami menggunakan cookies dan teknologi pelacakan serupa untuk:<br><br>
                    • Mengingat preferensi dan pengaturan Anda<br>
                    • Memahami bagaimana Anda menggunakan layanan kami<br>
                    • Meningkatkan pengalaman pengguna<br>
                    • Menganalisis tren dan pola penggunaan
                </p>
            </section>
            
            <section style="margin-bottom: 30px;">
                <h2 style="color: #2c3e50; margin-bottom: 15px;">7. Penyimpanan Data</h2>
                <p style="line-height: 1.8; color: #555;">
                    Kami menyimpan informasi Anda selama akun Anda aktif atau selama diperlukan untuk menyediakan layanan. 
                    Setelah Anda menghapus akun, kami akan menghapus atau mengasosiasikan informasi Anda, kecuali jika 
                    kami diwajibkan oleh hukum untuk menyimpannya.
                </p>
            </section>
            
            <section style="margin-bottom: 30px;">
                <h2 style="color: #2c3e50; margin-bottom: 15px;">8. Privasi Anak-anak</h2>
                <p style="line-height: 1.8; color: #555;">
                    Layanan kami tidak ditujukan untuk anak-anak di bawah usia 13 tahun. Kami tidak secara sengaja 
                    mengumpulkan informasi pribadi dari anak-anak di bawah 13 tahun.
                </p>
            </section>
            
            <section style="margin-bottom: 30px;">
                <h2 style="color: #2c3e50; margin-bottom: 15px;">9. Perubahan Kebijakan</h2>
                <p style="line-height: 1.8; color: #555;">
                    Kami dapat memperbarui kebijakan privasi ini dari waktu ke waktu. Kami akan memberi tahu Anda tentang 
                    perubahan dengan memposting kebijakan baru di halaman ini dan memperbarui tanggal "Terakhir diperbarui".
                </p>
            </section>
            
            <section style="margin-bottom: 30px;">
                <h2 style="color: #2c3e50; margin-bottom: 15px;">10. Hubungi Kami</h2>
                <p style="line-height: 1.8; color: #555;">
                    Jika Anda memiliki pertanyaan tentang Kebijakan Privasi ini, silakan hubungi kami di:<br>
                    <strong>Email:</strong> <?php echo SITE_EMAIL; ?>
                </p>
            </section>
        </div>
    </div>
    
    <?php if ($isLoggedIn): ?>
        <?php include 'includes/footer.php'; ?>
    <?php endif; ?>
</body>
</html>